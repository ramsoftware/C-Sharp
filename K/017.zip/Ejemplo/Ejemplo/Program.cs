﻿namespace Ejemplo;

class Program {
    static void Main() {
        Random Azar = new();

        //==============================
        //Leer los datos del archivo CSV
        //==============================
        DatosArchivo Datos = new();
        Datos.LeeXYdeCSV("Ejemplo1.csv");

        //Pasa los datos a dos listas: una de entrenamiento y otra de prueba
        List<double> Xentrena = [.. Datos.Xentrada];
        List<double> Yentrena = [.. Datos.Ysalidas];
        List<double> Xprueba = [];
        List<double> Yprueba = [];

        int PorcentajePrueba = 30;
        int Extrae = Xentrena.Count * PorcentajePrueba / 100;

        //Con los datos de entrada y salida (el dataset), ahora procede a normalizarlos
        double MinX = Xentrena.Min();
        double MaxX = Xentrena.Max();
        double MinY = Yentrena.Min();
        double MaxY = Yentrena.Max();

        for (int Cont = 0; Cont < Yentrena.Count; Cont++) {
            Xentrena[Cont] = (Xentrena[Cont] - MinX) / (MaxX - MinX);
            Yentrena[Cont] = (Yentrena[Cont] - MinY) / (MaxY - MinY);
        }

        //Genera las dos listas: de entrenamiento y prueba
        while (Xprueba.Count < Extrae) {
				int Pos = Azar.Next(Xentrena.Count);
				Xprueba.Add(Xentrena[Pos]);
				Yprueba.Add(Yentrena[Pos]);
				Xentrena.RemoveAt(Pos);
				Yentrena.RemoveAt(Pos);
			}

        //Entrena la red neuronal para que detecte el patrón
        int TotalEntradas = 1; //Número de entradas
        int NeuronasCapa0 = 7; //Total neuronas en la capa 0
        int NeuronasCapa1 = 7; //Total neuronas en la capa 1
        int NeuronasCapa2 = 1; //Total neuronas en la capa 2
        Perceptron RedNeuronal = new(Azar, TotalEntradas, NeuronasCapa0,
                                    NeuronasCapa1, NeuronasCapa2);

        //Esta será la única entrada externa al perceptrón, es decir, X
        List<double> Entrada = [0];

        //Esta será la salida esperada externa al perceptrón, es decir, Y
        List<double> SalidaEsperada = [0];

        //Ciclo que entrena la red neuronal
        bool SigueEntrenando = true;
        int Ciclo = 0;
        double Ajuste = double.MaxValue;
        while (SigueEntrenando) {
            Ciclo++;

            //Entrena la red neuronal
            for (int Cont = 0; Cont < Xentrena.Count; Cont++) {

                //Entrada y salida esperadas
                Entrada[0] = Xentrena[Cont];
                SalidaEsperada[0] = Yentrena[Cont];

                //Primero calcula la salida del perceptrón con esa entrada
                RedNeuronal.CalculaSalida(Entrada);

                //Luego entrena el perceptrón para ajustar los pesos y umbrales
                RedNeuronal.Entrena(Entrada, SalidaEsperada);
            }

            if (Ciclo % 200 == 0) {

                //Entrada y salida de prueba
                double Diferencia = 0;
					for (int Cont = 0; Cont < Xprueba.Count; Cont++) {
						Entrada[0] = Xprueba[Cont];

						//Calcula la salida del perceptrón con esa entrada
						RedNeuronal.CalculaSalida(Entrada);
						double Salida = RedNeuronal.Capas[2].Salidas[0];

						//Acumula el error
						Diferencia += (Salida - Yprueba[Cont]) * (Salida - Yprueba[Cont]);
					}

                //Compara con el ajuste anterior
                if (Diferencia <= Ajuste) {
                    Ajuste = Diferencia;
                    Console.WriteLine("Ciclos: " + Ciclo + " Nuevo Ajuste: " + Ajuste);
                }
                else {  //Si el ajuste anterior era menor, significa que ha
                        //comenzado un sobreajuste, luego detiene el entrenamiento
                    Console.WriteLine("Ciclos: " + Ciclo + " Desajuste: " + Diferencia);
                    SigueEntrenando = false;
                }
				}
        }

        Console.WriteLine("Entrada;Salida esperada;Salida perceptrón");

        for (int Cont = 0; Cont < Datos.Xentrada.Count; Cont++) {
            //Entradas y salidas esperadas
            Entrada[0] = (Datos.Xentrada[Cont]-MinX)/(MaxX-MinX);

            //Calcula la salida del perceptrón con esas entradas
            RedNeuronal.CalculaSalida(Entrada);
            double Salida = RedNeuronal.Capas[2].Salidas[0] * (MaxY - MinY) + MinY;

            //Imprime
            Console.WriteLine(Datos.Xentrada[Cont] + ";" + Datos.Ysalidas[Cont] + ";" + Salida);
        }
        Console.WriteLine("Finaliza el entrenamiento");
    }
}