﻿using System.Globalization;

namespace Ejemplo;

internal class DatosArchivo {
	//Los datos seleccionados para 
	//encontrar patrón de comportamiento
	public List<double> Xentrada;
	public List<double> Ysalidas;

	//Lee los valores X y Y.
	public void LeeXYdeCSV(string urlArchivo) {
		//Empieza a leer el archivo
		var Archivo = new StreamReader(urlArchivo);

		//Inicializa las listas
		Xentrada = [];
		Ysalidas = [];

		//Lee la linea de los dos datos numéricos
		string LineaDato;
		double valX, valY;
		Archivo.ReadLine();
		while ((LineaDato = Archivo.ReadLine()) != null) {
			int Coma = LineaDato.IndexOf(',');
			string Xc = LineaDato[..Coma];
			string Yc = LineaDato[(Coma + 1)..];
			valX = double.Parse(Xc, CultureInfo.InvariantCulture);
			valY = double.Parse(Yc, CultureInfo.InvariantCulture);
			Xentrada.Add(valX);
			Ysalidas.Add(valY);
		}
	}
}