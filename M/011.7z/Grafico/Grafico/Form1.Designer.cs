﻿namespace Grafico {
    partial class Form1 {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            numLineas = new NumericUpDown();
            lblNumLineas = new Label();
            numGiroZ = new NumericUpDown();
            numGiroY = new NumericUpDown();
            numGiroX = new NumericUpDown();
            lblGiroZ = new Label();
            lblGiroY = new Label();
            lblGiroX = new Label();
            groupBox1 = new GroupBox();
            lblYmaximo = new Label();
            lblYminimo = new Label();
            lblXmaximo = new Label();
            lblXminimo = new Label();
            numYmaximo = new NumericUpDown();
            numYminimo = new NumericUpDown();
            numXmaximo = new NumericUpDown();
            numXminimo = new NumericUpDown();
            label1 = new Label();
            lblProceso = new Label();
            txtEcuacion = new TextBox();
            txtProceso = new TextBox();
            btnProcesar = new Button();
            ((System.ComponentModel.ISupportInitialize)numLineas).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numGiroZ).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numGiroY).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numGiroX).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numYmaximo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numYminimo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numXmaximo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numXminimo).BeginInit();
            SuspendLayout();
            // 
            // numLineas
            // 
            numLineas.Location = new Point(147, 154);
            numLineas.Minimum = new decimal(new int[] { 30, 0, 0, 0 });
            numLineas.Name = "numLineas";
            numLineas.Size = new Size(71, 23);
            numLineas.TabIndex = 27;
            numLineas.TextAlign = HorizontalAlignment.Right;
            numLineas.Value = new decimal(new int[] { 50, 0, 0, 0 });
            numLineas.ValueChanged += numLineas_ValueChanged;
            // 
            // lblNumLineas
            // 
            lblNumLineas.AutoSize = true;
            lblNumLineas.ForeColor = SystemColors.ButtonFace;
            lblNumLineas.Location = new Point(12, 161);
            lblNumLineas.Name = "lblNumLineas";
            lblNumLineas.Size = new Size(119, 16);
            lblNumLineas.TabIndex = 26;
            lblNumLineas.Text = "Número de líneas";
            // 
            // numGiroZ
            // 
            numGiroZ.Location = new Point(147, 110);
            numGiroZ.Maximum = new decimal(new int[] { 360, 0, 0, 0 });
            numGiroZ.Name = "numGiroZ";
            numGiroZ.Size = new Size(71, 23);
            numGiroZ.TabIndex = 25;
            numGiroZ.TextAlign = HorizontalAlignment.Right;
            numGiroZ.Value = new decimal(new int[] { 224, 0, 0, 0 });
            numGiroZ.ValueChanged += numGiroZ_ValueChanged;
            // 
            // numGiroY
            // 
            numGiroY.Location = new Point(147, 66);
            numGiroY.Maximum = new decimal(new int[] { 360, 0, 0, 0 });
            numGiroY.Name = "numGiroY";
            numGiroY.Size = new Size(71, 23);
            numGiroY.TabIndex = 24;
            numGiroY.TextAlign = HorizontalAlignment.Right;
            numGiroY.Value = new decimal(new int[] { 25, 0, 0, 0 });
            numGiroY.ValueChanged += numGiroY_ValueChanged;
            // 
            // numGiroX
            // 
            numGiroX.Location = new Point(147, 22);
            numGiroX.Maximum = new decimal(new int[] { 360, 0, 0, 0 });
            numGiroX.Name = "numGiroX";
            numGiroX.Size = new Size(71, 23);
            numGiroX.TabIndex = 23;
            numGiroX.TextAlign = HorizontalAlignment.Right;
            numGiroX.Value = new decimal(new int[] { 56, 0, 0, 0 });
            numGiroX.ValueChanged += numGiroX_ValueChanged;
            // 
            // lblGiroZ
            // 
            lblGiroZ.AutoSize = true;
            lblGiroZ.ForeColor = SystemColors.ButtonFace;
            lblGiroZ.Location = new Point(12, 117);
            lblGiroZ.Name = "lblGiroZ";
            lblGiroZ.Size = new Size(67, 16);
            lblGiroZ.TabIndex = 22;
            lblGiroZ.Text = "Giro en Z";
            // 
            // lblGiroY
            // 
            lblGiroY.AutoSize = true;
            lblGiroY.ForeColor = SystemColors.ButtonFace;
            lblGiroY.Location = new Point(12, 73);
            lblGiroY.Name = "lblGiroY";
            lblGiroY.Size = new Size(67, 16);
            lblGiroY.TabIndex = 21;
            lblGiroY.Text = "Giro en Y";
            // 
            // lblGiroX
            // 
            lblGiroX.AutoSize = true;
            lblGiroX.ForeColor = SystemColors.ButtonFace;
            lblGiroX.Location = new Point(12, 29);
            lblGiroX.Name = "lblGiroX";
            lblGiroX.Size = new Size(67, 16);
            lblGiroX.TabIndex = 20;
            lblGiroX.Text = "Giro en X";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(lblYmaximo);
            groupBox1.Controls.Add(lblYminimo);
            groupBox1.Controls.Add(lblXmaximo);
            groupBox1.Controls.Add(lblXminimo);
            groupBox1.Controls.Add(numYmaximo);
            groupBox1.Controls.Add(numYminimo);
            groupBox1.Controls.Add(numXmaximo);
            groupBox1.Controls.Add(numXminimo);
            groupBox1.ForeColor = Color.White;
            groupBox1.Location = new Point(21, 221);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(218, 228);
            groupBox1.TabIndex = 28;
            groupBox1.TabStop = false;
            groupBox1.Text = "Valores X y Y en la ecuación";
            // 
            // lblYmaximo
            // 
            lblYmaximo.AutoSize = true;
            lblYmaximo.ForeColor = SystemColors.ButtonFace;
            lblYmaximo.Location = new Point(8, 180);
            lblYmaximo.Name = "lblYmaximo";
            lblYmaximo.Size = new Size(106, 16);
            lblYmaximo.TabIndex = 24;
            lblYmaximo.Text = "Valor Y máximo";
            // 
            // lblYminimo
            // 
            lblYminimo.AutoSize = true;
            lblYminimo.ForeColor = SystemColors.ButtonFace;
            lblYminimo.Location = new Point(8, 135);
            lblYminimo.Name = "lblYminimo";
            lblYminimo.Size = new Size(102, 16);
            lblYminimo.TabIndex = 23;
            lblYminimo.Text = "Valor Y mínimo";
            // 
            // lblXmaximo
            // 
            lblXmaximo.AutoSize = true;
            lblXmaximo.ForeColor = SystemColors.ButtonFace;
            lblXmaximo.Location = new Point(8, 91);
            lblXmaximo.Name = "lblXmaximo";
            lblXmaximo.Size = new Size(106, 16);
            lblXmaximo.TabIndex = 22;
            lblXmaximo.Text = "Valor X máximo";
            // 
            // lblXminimo
            // 
            lblXminimo.AutoSize = true;
            lblXminimo.ForeColor = SystemColors.ButtonFace;
            lblXminimo.Location = new Point(8, 45);
            lblXminimo.Name = "lblXminimo";
            lblXminimo.Size = new Size(102, 16);
            lblXminimo.TabIndex = 21;
            lblXminimo.Text = "Valor X mínimo";
            // 
            // numYmaximo
            // 
            numYmaximo.DecimalPlaces = 2;
            numYmaximo.Location = new Point(126, 180);
            numYmaximo.Minimum = new decimal(new int[] { 100, 0, 0, int.MinValue });
            numYmaximo.Name = "numYmaximo";
            numYmaximo.Size = new Size(74, 23);
            numYmaximo.TabIndex = 3;
            numYmaximo.TextAlign = HorizontalAlignment.Right;
            numYmaximo.Value = new decimal(new int[] { 10, 0, 0, 0 });
            numYmaximo.ValueChanged += numYmaximo_ValueChanged;
            // 
            // numYminimo
            // 
            numYminimo.DecimalPlaces = 2;
            numYminimo.Location = new Point(126, 135);
            numYminimo.Minimum = new decimal(new int[] { 100, 0, 0, int.MinValue });
            numYminimo.Name = "numYminimo";
            numYminimo.Size = new Size(74, 23);
            numYminimo.TabIndex = 2;
            numYminimo.TextAlign = HorizontalAlignment.Right;
            numYminimo.Value = new decimal(new int[] { 10, 0, 0, int.MinValue });
            numYminimo.ValueChanged += numYminimo_ValueChanged;
            // 
            // numXmaximo
            // 
            numXmaximo.DecimalPlaces = 2;
            numXmaximo.Location = new Point(126, 89);
            numXmaximo.Minimum = new decimal(new int[] { 100, 0, 0, int.MinValue });
            numXmaximo.Name = "numXmaximo";
            numXmaximo.Size = new Size(74, 23);
            numXmaximo.TabIndex = 1;
            numXmaximo.TextAlign = HorizontalAlignment.Right;
            numXmaximo.Value = new decimal(new int[] { 17, 0, 0, 0 });
            numXmaximo.ValueChanged += numXmaximo_ValueChanged;
            // 
            // numXminimo
            // 
            numXminimo.DecimalPlaces = 2;
            numXminimo.Location = new Point(126, 43);
            numXminimo.Minimum = new decimal(new int[] { 100, 0, 0, int.MinValue });
            numXminimo.Name = "numXminimo";
            numXminimo.Size = new Size(74, 23);
            numXminimo.TabIndex = 0;
            numXminimo.TextAlign = HorizontalAlignment.Right;
            numXminimo.Value = new decimal(new int[] { 6, 0, 0, int.MinValue });
            numXminimo.ValueChanged += numXminimo_ValueChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = SystemColors.ButtonFace;
            label1.Location = new Point(23, 788);
            label1.Name = "label1";
            label1.Size = new Size(72, 16);
            label1.TabIndex = 29;
            label1.Text = "Ecuación:";
            // 
            // lblProceso
            // 
            lblProceso.AutoSize = true;
            lblProceso.ForeColor = SystemColors.ButtonFace;
            lblProceso.Location = new Point(23, 854);
            lblProceso.Name = "lblProceso";
            lblProceso.Size = new Size(65, 16);
            lblProceso.TabIndex = 30;
            lblProceso.Text = "Proceso:";
            // 
            // txtEcuacion
            // 
            txtEcuacion.Location = new Point(121, 788);
            txtEcuacion.Name = "txtEcuacion";
            txtEcuacion.Size = new Size(851, 23);
            txtEcuacion.TabIndex = 31;
            txtEcuacion.Text = "sqr(X * X + Y * Y) + 3 * cos(Sqr(X * X + Y * Y)) + 5";
            // 
            // txtProceso
            // 
            txtProceso.Location = new Point(121, 854);
            txtProceso.Name = "txtProceso";
            txtProceso.Size = new Size(851, 23);
            txtProceso.TabIndex = 32;
            // 
            // btnProcesar
            // 
            btnProcesar.Location = new Point(121, 817);
            btnProcesar.Name = "btnProcesar";
            btnProcesar.Size = new Size(243, 26);
            btnProcesar.TabIndex = 33;
            btnProcesar.Text = "Procesar";
            btnProcesar.UseVisualStyleBackColor = true;
            btnProcesar.Click += btnProcesar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 16F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(1240, 893);
            Controls.Add(btnProcesar);
            Controls.Add(txtProceso);
            Controls.Add(txtEcuacion);
            Controls.Add(lblProceso);
            Controls.Add(label1);
            Controls.Add(groupBox1);
            Controls.Add(numLineas);
            Controls.Add(lblNumLineas);
            Controls.Add(numGiroZ);
            Controls.Add(numGiroY);
            Controls.Add(numGiroX);
            Controls.Add(lblGiroZ);
            Controls.Add(lblGiroY);
            Controls.Add(lblGiroX);
            DoubleBuffered = true;
            Font = new Font("Verdana", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Gráfico ecuación 3D";
            Paint += Form1_Paint;
            ((System.ComponentModel.ISupportInitialize)numLineas).EndInit();
            ((System.ComponentModel.ISupportInitialize)numGiroZ).EndInit();
            ((System.ComponentModel.ISupportInitialize)numGiroY).EndInit();
            ((System.ComponentModel.ISupportInitialize)numGiroX).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numYmaximo).EndInit();
            ((System.ComponentModel.ISupportInitialize)numYminimo).EndInit();
            ((System.ComponentModel.ISupportInitialize)numXmaximo).EndInit();
            ((System.ComponentModel.ISupportInitialize)numXminimo).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private NumericUpDown numLineas;
        private Label lblNumLineas;
        private NumericUpDown numGiroZ;
        private NumericUpDown numGiroY;
        private NumericUpDown numGiroX;
        private Label lblGiroZ;
        private Label lblGiroY;
        private Label lblGiroX;
        private GroupBox groupBox1;
        private Label lblYmaximo;
        private Label lblYminimo;
        private Label lblXmaximo;
        private Label lblXminimo;
        private NumericUpDown numYmaximo;
        private NumericUpDown numYminimo;
        private NumericUpDown numXmaximo;
        private NumericUpDown numXminimo;
        private Label label1;
        private Label lblProceso;
        private TextBox txtEcuacion;
        private TextBox txtProceso;
        private Button btnProcesar;
    }
}
