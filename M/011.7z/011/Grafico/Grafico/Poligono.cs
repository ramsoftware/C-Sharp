﻿namespace Grafico {
    internal class Poligono : IComparable {
        //Coordenadas de dibujo del polígono
        Point Punto1, Punto2, Punto3, Punto4;

        //Profundidad media de Z al girarse las coordenadas
        double Centro;

        //Color de relleno del polígono
        Color ColorZ;

        public Poligono(int X1, int Y1, int X2, int Y2, int X3, int Y3, int X4, int Y4, double Zg1, double Zg2, double Zg3, double Zg4, double Z1, double Z2, double Z3, double Z4, List<Color> colorList) {
            Punto1 = new(X1, Y1);
            Punto2 = new(X2, Y2);
            Punto3 = new(X3, Y3);
            Punto4 = new(X4, Y4);
            Centro = (Zg1 + Zg2 + Zg3 + Zg4) / 4;

            int TotalColores = colorList.Count;
            double PromedioZ = (Z1 + Z2 + Z3 + Z4 + 2) / 4;
            int ColorEscoge = (int) Math.Floor(TotalColores * PromedioZ);
            ColorZ = colorList[ColorEscoge];
        }

        //Usado para ordenar los polígonos
        //del más lejano al más cercano
        public int CompareTo(object obj) {
            Poligono OrdenCompara = obj as Poligono;
            if (OrdenCompara.Centro < Centro) return 1;
            if (OrdenCompara.Centro > Centro) return -1;
            return 0;
            //https://stackoverflow.com/questions/3309188/how-to-sort-a-listt-by-a-property-in-the-object
        }

        //Hace el gráfico del polígono
        public void Dibuja(Graphics Lienzo) {
            //Pone un color de fondo al polígono
            //para borrar lo que hay detrás
            Point[] ListaPuntos = [Punto1, Punto2, Punto3, Punto4];

            //Dibuja el polígono relleno y su perímetro
            Brush Relleno = new SolidBrush(ColorZ);
            Lienzo.FillPolygon(Relleno, ListaPuntos);
        }
    }
}
