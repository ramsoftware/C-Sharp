namespace Graficos
{
    //Proyecci�n 3D a 2D y giros. Figura centrada.
    public partial class Form1 : Form {

        //El cubo que se proyecta y gira
        Cubo Figura3D;

        //Tama�o de pantalla
        double ZPersona;
        int XpantallaIni, YpantallaIni, XpantallaFin, YpantallaFin;

        public Form1() {
            InitializeComponent();
            
            //Distancia del observador
            ZPersona = 5;
            
            //Tama�o de pantalla
            XpantallaIni = 20;
            YpantallaIni = 20;
            XpantallaFin = 500;
            YpantallaFin = 500;

            Figura3D = new Cubo();

            //Gira, proyecta y cuadra cada punto de la figura 3D
            Figura3D.GirarFigura(0, 0, 0, ZPersona, XpantallaIni, YpantallaIni, XpantallaFin, YpantallaFin);
        }

        private void Form1_Paint(object sender, PaintEventArgs e) {
            double AnguloX = Convert.ToDouble(numGiroX.Value);
            double AnguloY = Convert.ToDouble(numGiroY.Value);
            double AnguloZ = Convert.ToDouble(numGiroZ.Value);

            Graphics Lienzo = e.Graphics;

            //Dibuja el rect�ngulo que contiene la figura 3D
            Pen LapizMarco = new(Color.Blue, 1);
            Lienzo.DrawRectangle(LapizMarco, XpantallaIni, YpantallaIni, XpantallaFin - XpantallaIni, YpantallaFin - YpantallaIni);

            //Gira, proyecta y cuadra cada punto de la figura 3D
            Figura3D.GirarFigura(AnguloX, AnguloY, AnguloZ, ZPersona, XpantallaIni, YpantallaIni, XpantallaFin, YpantallaFin);

            //Dibuja la figura 3D
            Pen Lapiz3D = new(Color.Black, 1);
            Figura3D.Dibuja(Lienzo, Lapiz3D);
        }

        private void numGiroX_ValueChanged(object sender, EventArgs e) {
            Refresh();
        }

        private void numGiroY_ValueChanged(object sender, EventArgs e) {
            Refresh();
        }

        private void numGiroZ_ValueChanged(object sender, EventArgs e) {
            Refresh();
        }
    }
}
