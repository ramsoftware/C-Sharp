﻿namespace Graficos {
	internal class Cubo {
		//Un cubo tiene 8 coordenadas espaciales X, Y, Z
		private List<Punto> puntos;

		//Un cubo tiene 12 líneas de conexión
		private List<Conexion> conexiones;

		//Constructor
		public Cubo() {
			//Ejemplo de coordenadas espaciales X,Y,Z
			puntos = [
				new Punto(-0.5, -0.5, -0.5),
				new Punto(0.5, -0.5, -0.5),
				new Punto(0.5, 0.5, -0.5),
				new Punto(-0.5, 0.5, -0.5),
				new Punto(-0.5, -0.5, 0.5),
				new Punto(0.5, -0.5, 0.5),
				new Punto(0.5, 0.5, 0.5),
				new Punto(-0.5, 0.5, 0.5)
			];

			//Las 12 líneas para dibujar el cubo
			//punto inicial ---> punto final
			conexiones = [
				new Conexion(0, 1),
				new Conexion(1, 2),
				new Conexion(2, 3),
				new Conexion(3, 0),
				new Conexion(4, 5),
				new Conexion(5, 6),
				new Conexion(6, 7),
				new Conexion(7, 4),
				new Conexion(0, 4),
				new Conexion(1, 5),
				new Conexion(2, 6),
				new Conexion(3, 7)
			];
		}

		public void GirarFigura(double angX, double angY, double angZ, double ZPersona, int XpantallaIni, int YpantallaIni, int XpantallaFin, int YpantallaFin) {
			//Gira los 8 puntos
			for (int cont = 0; cont < puntos.Count; cont++) {
				puntos[cont].Giro(angX, angY, angZ);
				puntos[cont].Proyecta(ZPersona);
				puntos[cont].CuadraPantalla(XpantallaIni, YpantallaIni, XpantallaFin, YpantallaFin);
			}
		}

		//Dibuja el cubo
		public void Dibuja(Graphics lienzo, Pen lapiz) {
			for (int Cont = 0; Cont < conexiones.Count; Cont++) {
				int Inicio = conexiones[Cont].punto1;
				int Final = conexiones[Cont].punto2;
				lienzo.DrawLine(lapiz, puntos[Inicio].Xpantalla, puntos[Inicio].Ypantalla,
								   puntos[Final].Xpantalla, puntos[Final].Ypantalla);
			}
		}
	}
}

