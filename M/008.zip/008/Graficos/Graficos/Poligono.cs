﻿namespace Graficos {
    //Triángulo
    internal class Poligono {
        public int punto1, punto2, punto3;

        public Poligono(int punto1, int punto2, int punto3) {
            this.punto1 = punto1;
            this.punto2 = punto2;
            this.punto3 = punto3;
        }
    }
}
