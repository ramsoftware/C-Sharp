﻿namespace Graficos {
	internal class Objeto3D {
		//Coordenadas espaciales X, Y, Z
		private List<Punto> puntos;

		//Coordenadas del polígono (triángulo)
		private List<Poligono> poligonos;

		//Un cubo tiene 12 líneas de conexión
		private List<Conexion> conexiones;

		//Constructor
		public Objeto3D() {
			//Ejemplo de coordenadas espaciales X,Y,Z
			puntos = [
				new Punto( 0.00000000000,  0.361803,  0.5),
				new Punto( 0.00000000000,  0.361803, -0.5),
				new Punto( 0.00000000000, -0.361803,  0.5),
				new Punto( 0.00000000000, -0.361803, -0.5),
				new Punto( 0.361803,  0.5,  0.00000000000),
				new Punto( 0.361803, -0.5,  0.00000000000),
				new Punto(-0.361803,  0.5,  0.00000000000),
				new Punto(-0.361803, -0.5,  0.00000000000),
				new Punto( 0.5,  0.00000000000,  0.361803),
				new Punto( 0.5,  0.00000000000, -0.361803),
				new Punto(-0.5,  0.00000000000,  0.361803),
				new Punto(-0.5,  0.00000000000, -0.361803),

				//Coordenadas del cubo que contiene al icosaedro
				new Punto(-0.5, -0.5, -0.5),
				new Punto(0.5, -0.5, -0.5),
				new Punto(0.5, 0.5, -0.5),
				new Punto(-0.5, 0.5, -0.5),
				new Punto(-0.5, -0.5, 0.5),
				new Punto(0.5, -0.5, 0.5),
				new Punto(0.5, 0.5, 0.5),
				new Punto(-0.5, 0.5, 0.5)
			 ];


			//Los polígonos que dibujan el icosaedro
			poligonos = [
			 new Poligono(0, 6, 4),
				 new Poligono(0, 4, 8),
				 new Poligono(0, 8, 2),
				 new Poligono(0, 2, 10),
				 new Poligono(0, 10, 6),
				 new Poligono(1, 9, 4),
				 new Poligono(1, 4, 6),
				 new Poligono(1, 6, 11),
				 new Poligono(1, 11, 3),
				 new Poligono(1, 3, 9),
				 new Poligono(2, 8, 5),
				 new Poligono(2, 5, 7),
				 new Poligono(2, 7, 10),
				 new Poligono(3, 11, 7),
				 new Poligono(3, 7, 5),
				 new Poligono(3, 5, 9),
				 new Poligono(6, 10, 11),
				 new Poligono(5, 8, 9),
				 new Poligono(7, 11, 10),
				 new Poligono(4, 9, 8)
			];

			//Las 12 líneas para dibujar el cubo
			//punto inicial ---> punto final
			conexiones = [
				new Conexion(0+12, 1+12),
				new Conexion(1+12, 2+12),
				new Conexion(2+12, 3+12),
				new Conexion(3+12, 0+12),
				new Conexion(4+12, 5+12),
				new Conexion(5+12, 6+12),
				new Conexion(6+12, 7+12),
				new Conexion(7+12, 4+12),
				new Conexion(0+12, 4+12),
				new Conexion(1+12, 5+12),
				new Conexion(2+12, 6+12),
				new Conexion(3+12, 7+12)
			];
		}

		public void GirarFigura(double angX, double angY, double angZ, double ZPersona, int XpantallaIni, int YpantallaIni, int XpantallaFin, int YpantallaFin) {
			//Gira los 8 puntos
			for (int cont = 0; cont < puntos.Count; cont++) {
				puntos[cont].Giro(angX, angY, angZ);
				puntos[cont].Proyecta(ZPersona);
				puntos[cont].CuadraPantalla(XpantallaIni, YpantallaIni, XpantallaFin, YpantallaFin);
			}
		}

		//Dibuja el icosaedro
		public void Dibuja(Graphics lienzo, Pen lapizIcosaedro, Pen lapizCubo) {
			for (int Cont = 0; Cont < poligonos.Count; Cont++) {
				int puntoA = poligonos[Cont].punto1;
				int puntoB = poligonos[Cont].punto2;
				int puntoC = poligonos[Cont].punto3;
				lienzo.DrawLine(lapizIcosaedro, puntos[puntoA].Xpantalla, puntos[puntoA].Ypantalla,
								   puntos[puntoB].Xpantalla, puntos[puntoB].Ypantalla);
				lienzo.DrawLine(lapizIcosaedro, puntos[puntoA].Xpantalla, puntos[puntoA].Ypantalla,
								   puntos[puntoC].Xpantalla, puntos[puntoC].Ypantalla);
				lienzo.DrawLine(lapizIcosaedro, puntos[puntoC].Xpantalla, puntos[puntoC].Ypantalla,
								   puntos[puntoB].Xpantalla, puntos[puntoB].Ypantalla);
			}

			for (int Cont = 0; Cont < conexiones.Count; Cont++) {
				int Inicio = conexiones[Cont].punto1;
				int Final = conexiones[Cont].punto2;
				lienzo.DrawLine(lapizCubo, puntos[Inicio].Xpantalla, puntos[Inicio].Ypantalla,
								   puntos[Final].Xpantalla, puntos[Final].Ypantalla);
			}
		}
	}
}

