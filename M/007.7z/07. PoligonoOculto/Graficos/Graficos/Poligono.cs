﻿using System;
using System.Drawing;

namespace Graficos {
    internal class Poligono : IComparable {
        //Un polígono son cuatro(4) coordenadas espaciales
        public double X1, Y1, Z1, X2, Y2, Z2, X3, Y3, Z3, X4, Y4, Z4;

        //Las coordenadas de giro
        public double PosX1g, PosY1g, PosZ1g, PosX2g, PosY2g, PosZ2g, PosX3g, PosY3g, PosZ3g, PosX4g, PosY4g, PosZ4g;

        //Las coordenadas planas (segunda dimensión)
        public double X1sd, Y1sd, X2sd, Y2sd, X3sd, Y3sd, X4sd, Y4sd;

        //Las coordenadas en pantalla
        public int X1p, Y1p, X2p, Y2p, X3p, Y3p, X4p, Y4p;

        //Centro del polígono
        public double Centro;

        public Poligono(double X1, double Y1, double Z1, double X2, double Y2, double Z2, double X3, double Y3, double Z3, double X4, double Y4, double Z4) {
            this.X1 = X1; this.Y1 = Y1; this.Z1 = Z1;
            this.X2 = X2; this.Y2 = Y2; this.Z2 = Z2;
            this.X3 = X3; this.Y3 = Y3; this.Z3 = Z3;
            this.X4 = X4; this.Y4 = Y4; this.Z4 = Z4;
        }

        //Gira en XYZ
        public void Girar(double [,] Matriz) {
            PosX1g = X1 * Matriz[0,0] + Y1 * Matriz[1,0] + Z1 * Matriz[2,0];
            PosY1g = X1 * Matriz[0,1] + Y1 * Matriz[1,1] + Z1 * Matriz[2,1];
            PosZ1g = X1 * Matriz[0,2] + Y1 * Matriz[1,2] + Z1 * Matriz[2,2];

            PosX2g = X2 * Matriz[0,0] + Y2 * Matriz[1,0] + Z2 * Matriz[2,0];
            PosY2g = X2 * Matriz[0,1] + Y2 * Matriz[1,1] + Z2 * Matriz[2,1];
            PosZ2g = X2 * Matriz[0,2] + Y2 * Matriz[1,2] + Z2 * Matriz[2,2];

            PosX3g = X3 * Matriz[0,0] + Y3 * Matriz[1,0] + Z3 * Matriz[2,0];
            PosY3g = X3 * Matriz[0,1] + Y3 * Matriz[1,1] + Z3 * Matriz[2,1];
            PosZ3g = X3 * Matriz[0,2] + Y3 * Matriz[1,2] + Z3 * Matriz[2,2];

            PosX4g = X4 * Matriz[0,0] + Y4 * Matriz[1,0] + Z4 * Matriz[2,0];
            PosY4g = X4 * Matriz[0,1] + Y4 * Matriz[1,1] + Z4 * Matriz[2,1];
            PosZ4g = X4 * Matriz[0,2] + Y4 * Matriz[1,2] + Z4 * Matriz[2,2];

            Centro = (PosZ1g + PosZ2g + PosZ3g + PosZ4g) / 4;
        }

        //Convierte de 3D a 2D (segunda dimensión)
        public void Convierte3Da2D(double ZPersona) {
            X1sd = PosX1g * ZPersona / (ZPersona - PosZ1g);
            Y1sd = PosY1g * ZPersona / (ZPersona - PosZ1g);

            X2sd = PosX2g * ZPersona / (ZPersona - PosZ2g);
            Y2sd = PosY2g * ZPersona / (ZPersona - PosZ2g);

            X3sd = PosX3g * ZPersona / (ZPersona - PosZ3g);
            Y3sd = PosY3g * ZPersona / (ZPersona - PosZ3g);

            X4sd = PosX4g * ZPersona / (ZPersona - PosZ4g);
            Y4sd = PosY4g * ZPersona / (ZPersona - PosZ4g);
        }

        //Cuadra en pantalla física
        public void CuadraPantalla(double ConstanteX, double ConstanteY, double MinimoX, double MinimoY, int XPantallaIni, int YPantallaIni) {
            X1p = Convert.ToInt32(ConstanteX * (X1sd - MinimoX) + XPantallaIni);
            Y1p = Convert.ToInt32(ConstanteY * (Y1sd - MinimoY) + YPantallaIni);

            X2p = Convert.ToInt32(ConstanteX * (X2sd - MinimoX) + XPantallaIni);
            Y2p = Convert.ToInt32(ConstanteY * (Y2sd - MinimoY) + YPantallaIni);

            X3p = Convert.ToInt32(ConstanteX * (X3sd - MinimoX) + XPantallaIni);
            Y3p = Convert.ToInt32(ConstanteY * (Y3sd - MinimoY) + YPantallaIni);

            X4p = Convert.ToInt32(ConstanteX * (X4sd - MinimoX) + XPantallaIni);
            Y4p = Convert.ToInt32(ConstanteY * (Y4sd - MinimoY) + YPantallaIni);
        }

        //Hace el gráfico del polígono
        public void Dibuja(Graphics Lienzo, Pen Lapiz, Brush Relleno) {
            //Pone un color de fondo al polígono para borrar lo que hay detrás
            Point Punto1 = new Point(X1p, Y1p);
            Point Punto2 = new Point(X2p, Y2p);
            Point Punto3 = new Point(X3p, Y3p);
            Point Punto4 = new Point(X4p, Y4p);
            Point[] poligono = { Punto1, Punto2, Punto3, Punto4 };
            Lienzo.FillPolygon(Relleno, poligono);
            Lienzo.DrawPolygon(Lapiz, poligono);
        }

        //Usado para ordenar los polígonos del más lejano al más cercano
        //https://stackoverflow.com/questions/3309188/how-to-sort-a-listt-by-a-property-in-the-object
        public int CompareTo(object obj) {
            Poligono Comparar = obj as Poligono;
            if (Comparar.Centro < Centro) return 1;
            if (Comparar.Centro > Centro) return -1;
            return 0;
        }
    }
}
