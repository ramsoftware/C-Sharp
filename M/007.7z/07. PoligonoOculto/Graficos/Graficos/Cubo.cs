﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace Graficos {
    internal class Cubo {
        //Un cubo tiene 8 coordenadas espaciales X, Y, Z
        private List<Poligono> poligonos;

        //Constructor
        public Cubo() {
            poligonos = new List<Poligono>();

            //Polígonos que forman el cubo
            poligonos.Add(new Poligono(-0.5, 0.5, -0.5, 0.5, 0.5, -0.5, 0.5, -0.5, -0.5, -0.5, -0.5, -0.5));
            poligonos.Add(new Poligono(-0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, -0.5, 0.5, -0.5, -0.5, 0.5));

            poligonos.Add(new Poligono(-0.5, 0.5, -0.5, -0.5, 0.5, 0.5, -0.5, -0.5, 0.5, -0.5, -0.5, -0.5));
            poligonos.Add(new Poligono(0.5, 0.5, -0.5, 0.5, 0.5, 0.5, 0.5, -0.5, 0.5, 0.5, -0.5, -0.5));

            poligonos.Add(new Poligono(-0.5, 0.5, -0.5, 0.5, 0.5, -0.5, 0.5, 0.5, 0.5, -0.5, 0.5, 0.5));
            poligonos.Add(new Poligono(-0.5, -0.5, -0.5, 0.5, -0.5, -0.5, 0.5, -0.5, 0.5, -0.5, -0.5, 0.5));
        }

        public void GirarFigura(double angX, double angY, double angZ) {
            double angXr = angX * Math.PI / 180;
            double angYr = angY * Math.PI / 180;
            double angZr = angZ * Math.PI / 180;

            double CosX = Math.Cos(angXr);
            double SinX = Math.Sin(angXr);
            double CosY = Math.Cos(angYr);
            double SinY = Math.Sin(angYr);
            double CosZ = Math.Cos(angZr);
            double SinZ = Math.Sin(angZr);

            //Matriz de Rotación
            //https://en.wikipedia.org/wiki/Rotation_formalisms_in_three_dimensions
            double[,] Matriz = new double[3, 3] {
                { CosY * CosZ, -CosX * SinZ + SinX * SinY * CosZ, SinX * SinZ + CosX * SinY * CosZ},
                { CosY * SinZ, CosX * CosZ + SinX * SinY * SinZ, -SinX * CosZ + CosX * SinY * SinZ},
                {-SinY, SinX * CosY, CosX * CosY }
            };

            //Gira los 8 polígonos
            for (int cont = 0; cont < poligonos.Count; cont++) {
                poligonos[cont].Girar(Matriz);
            }
        }

        //Convierte de 3D a 2D las coordenadas giradas
        public void Convierte3Da2D(int ZPersona) {
            for (int cont = 0; cont < poligonos.Count; cont++) {
                poligonos[cont].Convierte3Da2D(ZPersona);
            }
        }

        //Convierte las coordenadas planas en coordenadas de pantalla
        public void CuadraPantalla(int XpantallaIni, int YpantallaIni, int XpantallaFin, int YpantallaFin) {
            //Los valores extremos de las coordenadas del cubo
            double MaximoX = 0.87931543769177811;
            double MinimoX = -0.87931543769177811;
            double MaximoY = 0.87931543769177811;
            double MinimoY = -0.87931543769177811;

            //Las constantes de transformación
            double ConstanteX = (XpantallaFin - XpantallaIni) / (MaximoX - MinimoX);
            double ConstanteY = (YpantallaFin - YpantallaIni) / (MaximoY - MinimoY);

            for (int cont = 0; cont < poligonos.Count; cont++) {
                poligonos[cont].CuadraPantalla(ConstanteX, ConstanteY, MinimoX, MinimoY, XpantallaIni, YpantallaIni);
            }

            //Ordena del polígono más alejado al más cercano, de esa manera los polígonos de adelante 
            //son visibles y los de atrás son borrados.
            poligonos.Sort();
        }


        //Dibuja el cubo
        public void Dibuja(Graphics lienzo, Pen lapiz, Brush relleno) {
            for (int cont = 0; cont < poligonos.Count; cont++) {
                poligonos[cont].Dibuja(lienzo, lapiz, relleno);
            }
        }
    }
}
