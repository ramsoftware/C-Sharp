﻿namespace Graficos {
    //Cada punto espacial es almacenado y convertido
    internal class Punto {
        private double X, Y, Z; //Coordenadas originales
        private double Xgiro, Ygiro, Zgiro; //Al girar los puntos
        public double PlanoX, PlanoY; //Proyección o sombra

        public Punto(double X, double Y, double Z) {
            this.X = X;
            this.Y = Y;
            this.Z = Z;
        }

        //Gira en X
        public void GiroX(double angulo) {
            double ang = angulo * Math.PI / 180;

            double[,] Matriz = new double[3, 3] {
                {1, 0, 0},
                {0, Math.Cos(ang), Math.Sin(ang)},
                {0, -Math.Sin(ang), Math.Cos(ang) }
            };

            AplicaMatrizGiro(Matriz);
        }

        //Gira en Y
        public void GiroY(double angulo) {
            double ang = angulo * Math.PI / 180;

            double[,] Matriz = new double[3, 3] {
                {Math.Cos(ang), 0, -Math.Sin(ang)},
                {0, 1, 0},
                {Math.Sin(ang), 0, Math.Cos(ang) }
            };

            AplicaMatrizGiro(Matriz);
        }

        //Gira en Z
        public void GiroZ(double angulo) {
            double ang = angulo * Math.PI / 180;

            double[,] Matriz = new double[3, 3] {
                {Math.Cos(ang), Math.Sin(ang), 0},
                {-Math.Sin(ang), Math.Cos(ang), 0},
                {0, 0, 1 }
            };

            AplicaMatrizGiro(Matriz);
        }

        //Aplica la matriz de giro 
        private void AplicaMatrizGiro(double[,] Matriz) {
            //Hace el giro
            Xgiro = X * Matriz[0, 0] + Y * Matriz[1, 0] + Z * Matriz[2, 0];
            Ygiro = X * Matriz[0, 1] + Y * Matriz[1, 1] + Z * Matriz[2, 1];
            Zgiro = X * Matriz[0, 2] + Y * Matriz[1, 2] + Z * Matriz[2, 2];
        }

        //Convierte de 3D a 2D (segunda dimensión)
        public void Proyecta(int ZPersona, ref double minimoX, ref double maximoX, ref double minimoY, ref double maximoY) {
            PlanoX = Xgiro * ZPersona / (ZPersona - Zgiro);
            PlanoY = Ygiro * ZPersona / (ZPersona - Zgiro);

            if (PlanoX < minimoX) minimoX = PlanoX;
            if (PlanoX > maximoX) maximoX = PlanoX;
            if (PlanoY < minimoY) minimoY = PlanoY;
            if (PlanoY > maximoY) maximoY = PlanoY;
        }
    }
}
