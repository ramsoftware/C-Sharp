﻿namespace Graficos {
    internal class Cubo {
        //Un cubo tiene 8 coordenadas espaciales X, Y, Z
        private List<Punto> puntos;

        //Un cubo tiene 12 líneas de conexión
        private List<Conexion> conexiones;

        //Constructor
        public Cubo(int ZPersona) {
            //Ejemplo de coordenadas espaciales X,Y,Z
            puntos = new List<Punto> {
                new Punto(50, 50, 50),
                new Punto(100, 50, 50),
                new Punto(100, 100, 50),
                new Punto(50, 100, 50),
                new Punto(50, 50, 100),
                new Punto(100, 50, 100),
                new Punto(100, 100, 100),
                new Punto(50, 100, 100)
            };

            //Las 12 líneas para dibujar el cubo
            //punto inicial ---> punto final
            conexiones = new List<Conexion> {
                new Conexion(0, 1),
                new Conexion(1, 2),
                new Conexion(2, 3),
                new Conexion(3, 0),
                new Conexion(4, 5),
                new Conexion(5, 6),
                new Conexion(6, 7),
                new Conexion(7, 4),
                new Conexion(0, 4),
                new Conexion(1, 5),
                new Conexion(2, 6),
                new Conexion(3, 7)
            };

            //Convierte de 3D a 2D
            for (int Cont = 0; Cont < puntos.Count; Cont++)
                puntos[Cont].Proyecta(ZPersona);
        }


        //Dibuja el cubo
        public void Dibuja(Graphics lienzo, Pen lapiz) {
            for (int Cont = 0; Cont < conexiones.Count; Cont++) {
                int Inicio = conexiones[Cont].punto1;
                int Final = conexiones[Cont].punto2;
                lienzo.DrawLine(lapiz, puntos[Inicio].PlanoX, puntos[Inicio].PlanoY,
                                   puntos[Final].PlanoX, puntos[Final].PlanoY);
            }
        }
    }
}
