namespace Graficos {
    //Proyecci�n 3D a 2D de una figura tridimensional: un cubo
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }

        //Pinta la proyecci�n
        private void Form1_Paint(object sender, PaintEventArgs e) {
            //Distancia de la persona (observador) al plano donde se
            //proyecta la "sombra" del cubo
            int ZPersona = 180;

            //Crea el objeto tridimensional
            Cubo Figura3D = new Cubo(ZPersona);

            //Dibuja el objeto tridimensional
            Graphics Lienzo = e.Graphics;
            Pen Lapiz = new Pen(Color.Blue, 3);
            Figura3D.Dibuja(Lienzo, Lapiz);
        }
    }
}
