﻿namespace Graficos {
    //Cada punto espacial es almacenado y convertido
    internal class Punto {
        private int X, Y, Z; //Coordenadas originales
        public int PlanoX, PlanoY; //Proyección o sombra

        public Punto(int X, int Y, int Z) {
            this.X = X;
            this.Y = Y;
            this.Z = Z;
        }

        //Convierte de 3D a 2D (segunda dimensión)
        public void Proyecta(int ZPersona) {
            PlanoX = X * ZPersona / (ZPersona - Z);
            PlanoY = Y * ZPersona / (ZPersona - Z);
        }
    }
}
