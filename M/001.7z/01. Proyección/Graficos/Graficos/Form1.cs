﻿//Proyección 3D a 2D de una figura tridimensional: un cubo
using System.Drawing;
using System.Windows.Forms;

namespace Graficos {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }

        //Pinta la proyección
        private void Form1_Paint(object sender, PaintEventArgs e) {
            Graphics Lienzo = e.Graphics;
            Pen Lapiz = new Pen(Color.Blue, 3);

            Cubo Figura3D = new Cubo();

            //Distancia de la persona (observador) al plano donde se proyecta la "sombra" del cubo
            int ZPersona = 180;
            Figura3D.Convierte3Da2D(ZPersona);
            Figura3D.Dibuja(Lienzo, Lapiz);
        }
    }
}