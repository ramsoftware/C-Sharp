﻿namespace Graficos
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Cubo Figura3D = new();
			Figura3D.CalculaExtremo(5);
		}
	}
}
