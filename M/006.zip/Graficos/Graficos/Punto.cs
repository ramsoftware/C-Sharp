﻿namespace Graficos {
	//Cada punto espacial es almacenado y convertido
	internal class Punto {
		private double X, Y, Z; //Coordenadas originales
		private double Xgiro, Ygiro, Zgiro; //Al girar los puntos
		public double PlanoX, PlanoY; //Proyección o sombra

		public Punto(double X, double Y, double Z) {
			this.X = X;
			this.Y = Y;
			this.Z = Z;
		}

		public void Giro(double angX, double angY, double angZ) {
			double angXr = angX * Math.PI / 180;
			double angYr = angY * Math.PI / 180;
			double angZr = angZ * Math.PI / 180;

			double CosX = Math.Cos(angXr);
			double SinX = Math.Sin(angXr);
			double CosY = Math.Cos(angYr);
			double SinY = Math.Sin(angYr);
			double CosZ = Math.Cos(angZr);
			double SinZ = Math.Sin(angZr);

			//Matriz de Rotación
			//https://en.wikipedia.org/wiki/Rotation_formalisms_in_three_dimensions
			double[,] Matriz = new double[3, 3] {
				{ CosY * CosZ, -CosX * SinZ + SinX * SinY * CosZ, SinX * SinZ + CosX * SinY * CosZ},
				{ CosY * SinZ, CosX * CosZ + SinX * SinY * SinZ, -SinX * CosZ + CosX * SinY * SinZ},
				{-SinY, SinX * CosY, CosX * CosY }
			};

			//Hace el giro
			Xgiro = X * Matriz[0, 0] + Y * Matriz[1, 0] + Z * Matriz[2, 0];
			Ygiro = X * Matriz[0, 1] + Y * Matriz[1, 1] + Z * Matriz[2, 1];
			Zgiro = X * Matriz[0, 2] + Y * Matriz[1, 2] + Z * Matriz[2, 2];
		}

		//Convierte de 3D a 2D (segunda dimensión)
		public void Proyecta(int ZPersona, ref double minimoX, ref double maximoX, ref double minimoY, ref double maximoY) {
			PlanoX = Xgiro * ZPersona / (ZPersona - Zgiro);
			PlanoY = Ygiro * ZPersona / (ZPersona - Zgiro);

			if (PlanoX < minimoX) minimoX = PlanoX;
			if (PlanoX > maximoX) maximoX = PlanoX;
			if (PlanoY < minimoY) minimoY = PlanoY;
			if (PlanoY > maximoY) maximoY = PlanoY;
		}
	}
}
