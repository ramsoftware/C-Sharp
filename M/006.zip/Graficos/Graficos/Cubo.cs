﻿namespace Graficos {
	internal class Cubo {
		//Un cubo tiene 8 coordenadas espaciales X, Y, Z
		private List<Punto> puntos;

		//Constructor
		public Cubo() {
			//Ejemplo de coordenadas espaciales X,Y,Z
			puntos = [
				new Punto(-0.5, -0.5, -0.5),
				new Punto(0.5, -0.5, -0.5),
				new Punto(0.5, 0.5, -0.5),
				new Punto(-0.5, 0.5, -0.5),
				new Punto(-0.5, -0.5, 0.5),
				new Punto(0.5, -0.5, 0.5),
				new Punto(0.5, 0.5, 0.5),
				new Punto(-0.5, 0.5, 0.5)
			];
		}

		//Calcula los extremos de las coordenadas del cubo al girar y proyectarse
		public void CalculaExtremo(int ZPersona) {
			double maximoX = double.MinValue;
			double minimoX = double.MaxValue;
			double maximoY = double.MinValue;
			double minimoY = double.MaxValue;

			//Va de punto en punto
			for (int Cont = 0; Cont < puntos.Count; Cont++) {

				//Va de angulo en angulo
				for (double angX = 0; angX <= 360; angX++)
					for (double angY = 0; angY <= 360; angY++)
						for (double angZ = 0; angZ <= 360; angZ++) {
							puntos[Cont].Giro(angX, angY, angZ);
							puntos[Cont].Proyecta(ZPersona, ref minimoX, ref maximoX, ref minimoY, ref maximoY);
						}
			}

			Console.WriteLine("Extremos son:");
			Console.WriteLine("MinimoX: " + minimoX.ToString());
			Console.WriteLine("MaximoX: " + maximoX.ToString());
			Console.WriteLine("MinimoY: " + minimoY.ToString());
			Console.WriteLine("MaximoY: " + maximoY.ToString());
		}
	}
}

