namespace Grafico {
    public partial class Form1 : Form {
        Graf3D graf3D;
        int XpantallaIni;
        int YpantallaIni;
        int XpantallaFin;
        int YpantallaFin;

        public Form1() {
            InitializeComponent();
            graf3D = new Graf3D();

            XpantallaIni = 300;
            YpantallaIni = 0;
            XpantallaFin = 1100;
            YpantallaFin = 800;

            graf3D.Inicializa(XpantallaIni, YpantallaIni, XpantallaFin, YpantallaFin);
            graf3D.Calcula();
        }

        private void Form1_Paint(object sender, PaintEventArgs e) {
            Graphics Lienzo = e.Graphics;

            Pen LapizMarco = new Pen(Color.Blue, 1);
            Lienzo.DrawRectangle(LapizMarco, XpantallaIni, YpantallaIni, XpantallaFin - XpantallaIni, YpantallaFin - YpantallaIni);

            Pen Lapiz = new(Color.Black, 1);

            //Hace l�neas de un solo sentido
            for (int Fila = 0; Fila < graf3D.MtPunto.Length; Fila++)
                for (int Columna = 0; Columna < graf3D.MtPunto.Length - 1; Columna++) {
                    int X1 = graf3D.MtPunto[Fila][Columna].Xp;
                    int Y1 = graf3D.MtPunto[Fila][Columna].Yp;

                    int X2 = graf3D.MtPunto[Fila][Columna + 1].Xp;
                    int Y2 = graf3D.MtPunto[Fila][Columna + 1].Yp;

                    Lienzo.DrawLine(Lapiz, X1, Y1, X2, Y2);
                }

            //hace las l�neas transversales generando el efecto de trama
            for (int Columna = 0; Columna < graf3D.MtPunto.Length; Columna++)
                for (int Fila = 0; Fila < graf3D.MtPunto.Length - 1; Fila++) {
                    int X1 = graf3D.MtPunto[Fila][Columna].Xp;
                    int Y1 = graf3D.MtPunto[Fila][Columna].Yp;

                    int X2 = graf3D.MtPunto[Fila + 1][Columna].Xp;
                    int Y2 = graf3D.MtPunto[Fila + 1][Columna].Yp;

                    Lienzo.DrawLine(Lapiz, X1, Y1, X2, Y2);
                }
        }

        private void numGiroX_ValueChanged(object sender, EventArgs e) {
            graf3D.setAnguloX((double)numGiroX.Value);
            graf3D.GiroProyectaCuadra();
            Refresh();
        }

        private void numGiroY_ValueChanged(object sender, EventArgs e) {
            graf3D.setAnguloY((double)numGiroY.Value);
            graf3D.GiroProyectaCuadra();
            Refresh();
        }

        private void numGiroZ_ValueChanged(object sender, EventArgs e) {
            graf3D.setAnguloZ((double)numGiroZ.Value);
            graf3D.GiroProyectaCuadra();
            Refresh();
        }

        private void numLineas_ValueChanged(object sender, EventArgs e) {
            graf3D.setNumLineas((int)numLineas.Value);
            graf3D.Calcula();
            graf3D.GiroProyectaCuadra();
            Refresh();
        }
    }
}
