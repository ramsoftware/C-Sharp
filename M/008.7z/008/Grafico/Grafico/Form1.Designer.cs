﻿namespace Grafico {
    partial class Form1 {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            numLineas = new NumericUpDown();
            lblNumLineas = new Label();
            numGiroZ = new NumericUpDown();
            numGiroY = new NumericUpDown();
            numGiroX = new NumericUpDown();
            lblGiroZ = new Label();
            lblGiroY = new Label();
            lblGiroX = new Label();
            ((System.ComponentModel.ISupportInitialize)numLineas).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numGiroZ).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numGiroY).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numGiroX).BeginInit();
            SuspendLayout();
            // 
            // numLineas
            // 
            numLineas.Location = new Point(166, 154);
            numLineas.Maximum = new decimal(new int[] { 70, 0, 0, 0 });
            numLineas.Minimum = new decimal(new int[] { 10, 0, 0, 0 });
            numLineas.Name = "numLineas";
            numLineas.Size = new Size(72, 23);
            numLineas.TabIndex = 27;
            numLineas.TextAlign = HorizontalAlignment.Right;
            numLineas.Value = new decimal(new int[] { 30, 0, 0, 0 });
            numLineas.ValueChanged += numLineas_ValueChanged;
            // 
            // lblNumLineas
            // 
            lblNumLineas.AutoSize = true;
            lblNumLineas.Location = new Point(12, 161);
            lblNumLineas.Name = "lblNumLineas";
            lblNumLineas.Size = new Size(119, 16);
            lblNumLineas.TabIndex = 26;
            lblNumLineas.Text = "Número de líneas";
            // 
            // numGiroZ
            // 
            numGiroZ.Location = new Point(166, 110);
            numGiroZ.Maximum = new decimal(new int[] { 360, 0, 0, 0 });
            numGiroZ.Name = "numGiroZ";
            numGiroZ.Size = new Size(72, 23);
            numGiroZ.TabIndex = 25;
            numGiroZ.TextAlign = HorizontalAlignment.Right;
            numGiroZ.Value = new decimal(new int[] { 45, 0, 0, 0 });
            numGiroZ.ValueChanged += numGiroZ_ValueChanged;
            // 
            // numGiroY
            // 
            numGiroY.Location = new Point(166, 66);
            numGiroY.Maximum = new decimal(new int[] { 360, 0, 0, 0 });
            numGiroY.Name = "numGiroY";
            numGiroY.Size = new Size(72, 23);
            numGiroY.TabIndex = 24;
            numGiroY.TextAlign = HorizontalAlignment.Right;
            numGiroY.Value = new decimal(new int[] { 45, 0, 0, 0 });
            numGiroY.ValueChanged += numGiroY_ValueChanged;
            // 
            // numGiroX
            // 
            numGiroX.Location = new Point(166, 22);
            numGiroX.Maximum = new decimal(new int[] { 360, 0, 0, 0 });
            numGiroX.Name = "numGiroX";
            numGiroX.Size = new Size(72, 23);
            numGiroX.TabIndex = 23;
            numGiroX.TextAlign = HorizontalAlignment.Right;
            numGiroX.Value = new decimal(new int[] { 45, 0, 0, 0 });
            numGiroX.ValueChanged += numGiroX_ValueChanged;
            // 
            // lblGiroZ
            // 
            lblGiroZ.AutoSize = true;
            lblGiroZ.Location = new Point(12, 117);
            lblGiroZ.Name = "lblGiroZ";
            lblGiroZ.Size = new Size(67, 16);
            lblGiroZ.TabIndex = 22;
            lblGiroZ.Text = "Giro en Z";
            // 
            // lblGiroY
            // 
            lblGiroY.AutoSize = true;
            lblGiroY.Location = new Point(12, 73);
            lblGiroY.Name = "lblGiroY";
            lblGiroY.Size = new Size(67, 16);
            lblGiroY.TabIndex = 21;
            lblGiroY.Text = "Giro en Y";
            // 
            // lblGiroX
            // 
            lblGiroX.AutoSize = true;
            lblGiroX.Location = new Point(12, 29);
            lblGiroX.Name = "lblGiroX";
            lblGiroX.Size = new Size(67, 16);
            lblGiroX.TabIndex = 20;
            lblGiroX.Text = "Giro en X";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 16F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1170, 829);
            Controls.Add(numLineas);
            Controls.Add(lblNumLineas);
            Controls.Add(numGiroZ);
            Controls.Add(numGiroY);
            Controls.Add(numGiroX);
            Controls.Add(lblGiroZ);
            Controls.Add(lblGiroY);
            Controls.Add(lblGiroX);
            DoubleBuffered = true;
            Font = new Font("Verdana", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Gráfico ecuación 3D";
            Paint += Form1_Paint;
            ((System.ComponentModel.ISupportInitialize)numLineas).EndInit();
            ((System.ComponentModel.ISupportInitialize)numGiroZ).EndInit();
            ((System.ComponentModel.ISupportInitialize)numGiroY).EndInit();
            ((System.ComponentModel.ISupportInitialize)numGiroX).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private NumericUpDown numLineas;
        private Label lblNumLineas;
        private NumericUpDown numGiroZ;
        private NumericUpDown numGiroY;
        private NumericUpDown numGiroX;
        private Label lblGiroZ;
        private Label lblGiroY;
        private Label lblGiroX;
    }
}
