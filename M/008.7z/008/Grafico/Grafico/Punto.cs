﻿namespace Grafico {
    internal class Punto {
        private double X, Y, Z; //Coordenadas originales
        private double Xg, Yg, Zg; //Coordenadas al girar
        private double PlanoX, PlanoY; //Proyección o sombra
        public int Xp, Yp; //En Pantalla

        public void Calcular(double X, double Y) {
            Ecuacion ecuacion = new();
            this.X = X;
            this.Y = Y;
            Z = ecuacion.Evaluar(X, Y);
            if (double.IsNaN(Z) || double.IsInfinity(Z))
                Z = 0;
        }

        //Retorna el valor de Z sin girar
        public double getZ() {
            return Z;
        }

        //Normaliza punto y luego lo ubica entre -0.5 y 0.5
        public void Normaliza(double MinX, double MinY, double MinZ,
                              double MaxX, double MaxY, double MaxZ) {
            X = (X - MinX) / (MaxX - MinX) - 0.5;
            Y = (Y - MinY) / (MaxY - MinY) - 0.5;
            Z = (Z - MinZ) / (MaxZ - MinZ) - 0.5;
        }

        //Gira el punto
        public void Giro(double[,] Mt) {
            Xg = X * Mt[0, 0] + Y * Mt[1, 0] + Z * Mt[2, 0];
            Yg = X * Mt[0, 1] + Y * Mt[1, 1] + Z * Mt[2, 1];
            Zg = X * Mt[0, 2] + Y * Mt[1, 2] + Z * Mt[2, 2];
        }

        //Convierte de 3D a 2D (segunda dimensión)
        public void Proyecta(double ZPersona) {
            PlanoX = Xg * ZPersona / (ZPersona - Zg);
            PlanoY = Yg * ZPersona / (ZPersona - Zg);
        }

        //Convierte 2D real a 2D pantalla
        public void Pantalla(int XpIni, int YpIni, int XpFin, int YpFin) {
            //Los valores extremos de las coordenadas del cubo
            double MaximoX = 0.87931543769177811;
            double MinimoX = -0.87931543769177811;
            double MaximoY = 0.87931543769177811;
            double MinimoY = -0.87931543769177811;

            //Las constantes de transformación
            double conX = (XpFin - XpIni) / (MaximoX - MinimoX);
            double conY = (YpFin - YpIni) / (MaximoY - MinimoY);

            //Cuadra en pantalla física
            Xp = Convert.ToInt32(conX * (PlanoX - MinimoX) + XpIni);
            Yp = Convert.ToInt32(conY * (PlanoY - MinimoY) + YpIni);
        }
    }
}
