﻿namespace Grafico {
    internal class Ecuacion {
        public double Evaluar(double X, double Y) {
            double Z = Math.Sqrt(X * X + Y * Y);
            Z += 3 * Math.Cos(Math.Sqrt(X * X + Y * Y)) + 5;
            return Z;
        }
    }
}
