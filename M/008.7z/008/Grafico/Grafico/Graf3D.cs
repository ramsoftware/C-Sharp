﻿namespace Grafico {
    class Graf3D {
        public Punto[][] MtPunto;

        double MinX, MinY, MaxX, MaxY, MinZ, MaxZ;
        double AnguloX, AnguloY, AnguloZ;
        double ZPersona;
        int NumLineas;
        int XpantallaIni, YpantallaIni, XpantallaFin, YpantallaFin;

        public void Inicializa(int XpantallaIni, int YpantallaIni, int XpantallaFin, int YpantallaFin) {
            //Valores
            MinX = -10;
            MinY = -10;
            MaxX = 10;
            MaxY = 10;
            NumLineas = 40;

            //Angulos de giro
            AnguloX = 45;
            AnguloY = 45;
            AnguloZ = 45;

            //Distancia de la persona al plano
            ZPersona = 5;

            //Tamaño de la pantalla
            this.XpantallaIni = XpantallaIni;
            this.YpantallaIni = YpantallaIni;
            this.XpantallaFin = XpantallaFin;
            this.YpantallaFin = YpantallaFin;
        }

        public void setAnguloX(double AnguloX) {
            this.AnguloX = AnguloX;
        }

        public void setAnguloY(double AnguloY) {
            this.AnguloY = AnguloY;
        }

        public void setAnguloZ(double AnguloZ) {
            this.AnguloZ = AnguloZ;
        }

        public void setNumLineas(int NumLineas) {
            this.NumLineas = NumLineas;
        }

        private void IniciaMatrizPuntos() {
            //Arreglo de arreglos
            MtPunto = new Punto[NumLineas][];
            for (int Fila = 0; Fila < MtPunto.Length; Fila++) {
                MtPunto[Fila] = new Punto[NumLineas];
                for (int Columna = 0; Columna < MtPunto[Fila].Length; Columna++) {
                    MtPunto[Fila][Columna] = new Punto();
                }
            }
        }

        private void CalculaXYZ() {
            //Calcula las coordenadas XYZ originales
            double IncrY = (MaxY - MinY) / NumLineas;
            double IncrX = (MaxX - MinX) / NumLineas;
            double X = MinX;
            double Y = MinY;

            for (int Fila = 0; Fila < NumLineas; Fila++) {
                X = MinX;
                for (int Columna = 0; Columna < NumLineas; Columna++) {
                    MtPunto[Fila][Columna].Calcular(X, Y);
                    X += IncrX;
                }
                Y += IncrY;
            }
        }

        private void ExtremosZ() {
            MinZ = double.MaxValue;
            MaxZ = double.MinValue;

            for (int Fila = 0; Fila < NumLineas; Fila++) {
                for (int Columna = 0; Columna < NumLineas; Columna++) {
                    //Los valores extremos de Z
                    if (MtPunto[Fila][Columna].getZ() < MinZ)
                        MinZ = MtPunto[Fila][Columna].getZ();

                    if (MtPunto[Fila][Columna].getZ() > MaxZ)
                        MaxZ = MtPunto[Fila][Columna].getZ();
                }
            }
        }

        private void NormalizaCalculos() {
            for (int Fila = 0; Fila < NumLineas; Fila++)
                for (int Columna = 0; Columna < NumLineas; Columna++)
                    MtPunto[Fila][Columna].Normaliza(MinX, MinY, MinZ, MaxX, MaxY, MaxZ);
        }

        public void Calcula() {
            IniciaMatrizPuntos();
            CalculaXYZ();
            ExtremosZ();
            NormalizaCalculos();
            GiroProyectaCuadra();
        }

        public void GiroProyectaCuadra() {
            //Genera la matriz de rotación
            double CosX = Math.Cos(AnguloX * Math.PI / 180);
            double SinX = Math.Sin(AnguloX * Math.PI / 180);
            double CosY = Math.Cos(AnguloY * Math.PI / 180);
            double SinY = Math.Sin(AnguloY * Math.PI / 180);
            double CosZ = Math.Cos(AnguloZ * Math.PI / 180);
            double SinZ = Math.Sin(AnguloZ * Math.PI / 180);

            //Matriz de Rotación
            //https://en.wikipedia.org/wiki/Rotation_formalisms_in_three_dimensions
            double[,] MtRota = new double[3, 3] {
{CosY*CosZ,-CosX*SinZ+SinX*SinY*CosZ,SinX*SinZ+CosX*SinY*CosZ},
{CosY*SinZ,CosX*CosZ+SinX*SinY*SinZ,-SinX*CosZ+CosX*SinY*SinZ},
{-SinY,SinX*CosY,CosX*CosY}
            };

            for (int Fila = 0; Fila < NumLineas; Fila++)
                for (int Columna = 0; Columna < NumLineas; Columna++) {
                    MtPunto[Fila][Columna].Giro(MtRota);
                    MtPunto[Fila][Columna].Proyecta(ZPersona);
                    MtPunto[Fila][Columna].Pantalla(XpantallaIni, YpantallaIni, XpantallaFin, YpantallaFin);
                }
        }
    }
}
