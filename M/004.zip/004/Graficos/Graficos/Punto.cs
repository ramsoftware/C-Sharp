﻿namespace Graficos {
    //Cada punto espacial es almacenado y convertido
    internal class Punto {
        private double X, Y, Z; //Coordenadas originales
        private double Xgiro, Ygiro, Zgiro; //Al girar los puntos
        private double PlanoX, PlanoY; //Proyección o sombra
        public int Xpantalla, Ypantalla; //Coordenadas en la pantalla

        public Punto(double X, double Y, double Z) {
            this.X = X;
            this.Y = Y;
            this.Z = Z;
        }

        //Gira en X
        public void GiroX(double AnguloRad) {
            double[,] Matriz = new double[3, 3] {
                {1, 0, 0},
                {0, Math.Cos(AnguloRad), Math.Sin(AnguloRad)},
                {0, -Math.Sin(AnguloRad), Math.Cos(AnguloRad) }
            };

            AplicaMatrizGiro(Matriz);
        }

        //Gira en Y
        public void GiroY(double AnguloRad) {
            double[,] Matriz = new double[3, 3] {
                {Math.Cos(AnguloRad), 0, -Math.Sin(AnguloRad)},
                {0, 1, 0},
                {Math.Sin(AnguloRad), 0, Math.Cos(AnguloRad) }
            };

            AplicaMatrizGiro(Matriz);
        }

        //Gira en Z
        public void GiroZ(double AnguloRad) {
            double[,] Matriz = new double[3, 3] {
                {Math.Cos(AnguloRad), Math.Sin(AnguloRad), 0},
                {-Math.Sin(AnguloRad), Math.Cos(AnguloRad), 0},
                {0, 0, 1 }
            };

            AplicaMatrizGiro(Matriz);
        }

        //Aplica la matriz de giro 
        private void AplicaMatrizGiro(double[,] Matriz) {
            //Hace el giro
            Xgiro = X * Matriz[0, 0] + Y * Matriz[1, 0] + Z * Matriz[2, 0];
            Ygiro = X * Matriz[0, 1] + Y * Matriz[1, 1] + Z * Matriz[2, 1];
            Zgiro = X * Matriz[0, 2] + Y * Matriz[1, 2] + Z * Matriz[2, 2];
        }

        //Convierte de 3D a 2D (segunda dimensión)
        public void Proyecta(int ZPersona) {
            PlanoX = Xgiro * ZPersona / (ZPersona - Zgiro);
            PlanoY = Ygiro * ZPersona / (ZPersona - Zgiro);
        }

        //Cuadra en pantalla
        public void CuadraPantalla(double convierteX, double convierteY, 
                                    double minimoX, double minimoY,
                                    int XpantallaIni, int XpantallaFin,
                                    int YpantallaIni, int YpantallaFin) {
            Xpantalla = Convert.ToInt32(convierteX * (PlanoX - minimoX) + XpantallaIni);
            Ypantalla = Convert.ToInt32(convierteY * (PlanoY - minimoY) + YpantallaIni);
        }
    }
}
