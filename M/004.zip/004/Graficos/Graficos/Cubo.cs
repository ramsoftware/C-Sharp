﻿namespace Graficos {
    internal class Cubo {
        //Un cubo tiene 8 coordenadas espaciales X, Y, Z
        private List<Punto> puntos;

        //Un cubo tiene 12 líneas de conexión
        private List<Conexion> conexiones;

        //Valores extremos
        private double minimoX, maximoX, minimoY, maximoY, convierteX, convierteY;

        //Despliegue en pantalla
        private int XpantallaIni, XpantallaFin, YpantallaIni, YpantallaFin;

        //Distancia del observador
        private int ZPersona;

        //Constructor
        public Cubo(int XpantallaIni, int XpantallaFin, int YpantallaIni, int YpantallaFin) {
            //Ejemplo de coordenadas espaciales X,Y,Z
            puntos = [
                 new Punto(-0.5, -0.5, -0.5),
                 new Punto(0.5, -0.5, -0.5),
                 new Punto(0.5, 0.5, -0.5),
                 new Punto(-0.5, 0.5, -0.5),
                 new Punto(-0.5, -0.5, 0.5),
                 new Punto(0.5, -0.5, 0.5),
                 new Punto(0.5, 0.5, 0.5),
                 new Punto(-0.5, 0.5, 0.5)
             ];

             //Las 12 líneas para dibujar el cubo
             //punto inicial ---> punto final
             conexiones = [
                 new Conexion(0, 1),
                 new Conexion(1, 2),
                 new Conexion(2, 3),
                 new Conexion(3, 0),
                 new Conexion(4, 5),
                 new Conexion(5, 6),
                 new Conexion(6, 7),
                 new Conexion(7, 4),
                 new Conexion(0, 4),
                 new Conexion(1, 5),
                 new Conexion(2, 6),
                 new Conexion(3, 7)
             ];

            this.XpantallaIni = XpantallaIni;
            this.XpantallaFin = XpantallaFin;
            this.YpantallaIni = YpantallaIni;
            this.YpantallaFin = YpantallaFin;
            this.ZPersona = 5;

            //Los valores extremos de las coordenadas del cubo
            this.maximoX = 0.785674201318386;
            this.minimoX = -0.785674201318386;
            this.maximoY = 0.785674201318386;
            this.minimoY = -0.785674201318386;

            //Las constantes de transformación
            convierteX = (XpantallaFin - XpantallaIni) / (maximoX - minimoX);
            convierteY = (YpantallaFin - YpantallaIni) / (maximoY - minimoY);
        }

        public void GiroX(int Angulo) {
            double Radian = Angulo * Math.PI / 180;
            for (int cont = 0; cont < puntos.Count; cont++) {
                puntos[cont].GiroX(Radian);
                puntos[cont].Proyecta(ZPersona);
                puntos[cont].CuadraPantalla(convierteX, convierteY,
                                    minimoX, minimoY,
                                    XpantallaIni, XpantallaFin,
                                    YpantallaIni, YpantallaFin);
            }
        }

        public void GiroY(int Angulo) {
            double Radian = Angulo * Math.PI / 180;
            for (int cont = 0; cont < puntos.Count; cont++) {
                puntos[cont].GiroY(Radian);
                puntos[cont].Proyecta(ZPersona);
                puntos[cont].CuadraPantalla(convierteX, convierteY,
                                    minimoX, minimoY,
                                    XpantallaIni, XpantallaFin,
                                    YpantallaIni, YpantallaFin);
            }
        }

        public void GiroZ(int Angulo) {
            double Radian = Angulo * Math.PI / 180;
            for (int cont = 0; cont < puntos.Count; cont++) {
                puntos[cont].GiroZ(Radian);
                puntos[cont].Proyecta(ZPersona);
                puntos[cont].CuadraPantalla(convierteX, convierteY,
                                    minimoX, minimoY,
                                    XpantallaIni, XpantallaFin,
                                    YpantallaIni, YpantallaFin);
            }
        }

        //Dibuja el cubo
        public void Dibuja(Graphics lienzo, Pen lapiz) {
            for (int Cont = 0; Cont < conexiones.Count; Cont++) {
                int Inicio = conexiones[Cont].punto1;
                int Final = conexiones[Cont].punto2;
                lienzo.DrawLine(lapiz, puntos[Inicio].Xpantalla, puntos[Inicio].Ypantalla,
                                   puntos[Final].Xpantalla, puntos[Final].Ypantalla);
            }
        }
    }
}

