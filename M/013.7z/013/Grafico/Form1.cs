namespace Grafico {
    public partial class Form1 : Form {
        //El objeto que se encarga de calcular
        //y cuadrar en pantalla la ecuaci�n polar
        Graf3D Grafico3D;

        //Evaluador de expresiones
        Evaluador4 Evaluador;

        //N�mero de l�neas a dibujar
        int NumLineas;

        public Form1() {
            InitializeComponent();
            Grafico3D = new Graf3D();

            Evaluador = new Evaluador4();
            Evaluador.Analizar(txtEcuacion.Text);

            NumLineas = 80;
            Grafico3D.CalculaEcuacion(NumLineas, Evaluador, (double)numXminimo.Value, (double)numXmaximo.Value);
        }

        private void numGiroX_ValueChanged(object sender, EventArgs e) {
            Refresh();
        }

        private void numGiroY_ValueChanged(object sender, EventArgs e) {
            Refresh();
        }

        private void numGiroZ_ValueChanged(object sender, EventArgs e) {
            Refresh();
        }

        private void Form1_Paint(object sender, PaintEventArgs e) {
            Graphics Lienzo = e.Graphics;
            Pen Lapiz = new(Color.Black, 1);
            Brush Relleno = new SolidBrush(Color.White);

            int AnguloX = Convert.ToInt32(numGiroX.Value);
            int AnguloY = Convert.ToInt32(numGiroY.Value);
            int AnguloZ = Convert.ToInt32(numGiroZ.Value);

            //Despu�s de los c�lculos, entonces aplica giros,
            //conversi�n a 2D y cuadrar en pantalla
            Grafico3D.CalculaGrafico(AnguloX, AnguloY, AnguloZ);
            Grafico3D.Dibuja(Lienzo, Lapiz, Relleno);
        }

        private void btnProcesar_Click(object sender, EventArgs e) {
            string Ecuacion = txtEcuacion.Text;
            int Sintaxis = Evaluador.Analizar(Ecuacion);

            if (Sintaxis > 0) {
                txtProceso.Text = Evaluador.MensajeError(Sintaxis);
            }
            else {
                txtProceso.Text = "Ecuaci�n correcta, procede a dibujar";
                Grafico3D.CalculaEcuacion(NumLineas, Evaluador, (double)numXminimo.Value, (double)numXmaximo.Value);
                Refresh();
            }
        }

        private void numXminimo_ValueChanged(object sender, EventArgs e) {
            if (numXminimo.Value >= numXmaximo.Value)
                numXminimo.Value = numXmaximo.Value - 1;
            Grafico3D.CalculaEcuacion(NumLineas, Evaluador, (double)numXminimo.Value, (double)numXmaximo.Value);
            Refresh();
        }

        private void numXmaximo_ValueChanged(object sender, EventArgs e) {
            if (numXmaximo.Value <= numXminimo.Value)
                numXmaximo.Value = numXminimo.Value + 1;
            Grafico3D.CalculaEcuacion(NumLineas, Evaluador, (double)numXminimo.Value, (double)numXmaximo.Value);
            Refresh();
        }
    }
}
