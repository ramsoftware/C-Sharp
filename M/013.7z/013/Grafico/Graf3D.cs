﻿namespace Grafico {
    class Graf3D {
        //Donde almacena los poligonos
        private List<Poligono> poligono;

        public void CalculaEcuacion(int numLineas, Evaluador4 Evalua) {
            //Inicia el listado de polígonos que forma la figura			 
            poligono = [];

            //Mínimos y máximos para normalizar
            double MinimoX = double.MaxValue;
            double MaximoX = double.MinValue;
            double MinimoY = double.MaxValue;
            double MaximoY = double.MinValue;
            double MinimoZ = double.MaxValue;
            double MaximoZ = double.MinValue;

            //Calcula cada polígono dependiendo de la ecuación
            double MinTheta = 0, MaxTheta = 360, MinPhi = 0, MaxPhi = 360;

            double IncTheta = (MaxTheta - MinTheta) / numLineas;
            double IncPhi = (MaxPhi - MinPhi) / numLineas;

            for (double Th = MinTheta; Th <= MaxTheta; Th += IncTheta)
                for (double Phi = MinPhi; Phi <= MaxPhi; Phi += IncPhi) {

                    //Calcula los 4 valores del eje Z del polígono

                    //PUNTO 1 DEL POLIGONO
                    double Theta1 = Th * Math.PI / 180;
                    double Phi1 = Phi * Math.PI / 180;

                    Evalua.DarValorVariable('p', Phi1);
                    Evalua.DarValorVariable('t', Theta1);
                    double R1 = Evalua.Evaluar();
                    if (double.IsNaN(R1) || double.IsInfinity(R1)) R1 = 0;

                    double X1 = R1 * Math.Cos(Phi1) * Math.Sin(Theta1);
                    double Y1 = R1 * Math.Sin(Phi1) * Math.Sin(Theta1);
                    double Z1 = R1 * Math.Cos(Theta1);

                    //PUNTO 2 DEL POLIGONO
                    double Theta2 = (Th + IncTheta) * Math.PI / 180;
                    double Phi2 = Phi * Math.PI / 180;
                    
                    Evalua.DarValorVariable('p', Phi2);
                    Evalua.DarValorVariable('t', Theta2);
                    double R2 = Evalua.Evaluar();
                    if (double.IsNaN(R2) || double.IsInfinity(R2)) R2 = 0;
                    
                    double X2 = R2 * Math.Cos(Phi2) * Math.Sin(Theta2);
                    double Y2 = R2 * Math.Sin(Phi2) * Math.Sin(Theta2);
                    double Z2 = R2 * Math.Cos(Theta2);

                    //PUNTO 3 DEL POLIGONO
                    double Theta3 = (Th + IncTheta) * Math.PI / 180;
                    double Phi3 = (Phi + IncPhi) * Math.PI / 180;
                    
                    Evalua.DarValorVariable('p', Phi3);
                    Evalua.DarValorVariable('t', Theta3);
                    double R3 = Evalua.Evaluar();
                    if (double.IsNaN(R3) || double.IsInfinity(R3)) R3 = 0;
                    
                    double X3 = R3 * Math.Cos(Phi3) * Math.Sin(Theta3);
                    double Y3 = R3 * Math.Sin(Phi3) * Math.Sin(Theta3);
                    double Z3 = R3 * Math.Cos(Theta3);

                    //PUNTO 4 DEL POLIGONO
                    double Theta4 = Th * Math.PI / 180;
                    double Phi4 = (Phi + IncPhi) * Math.PI / 180;
                    
                    Evalua.DarValorVariable('p', Phi4);
                    Evalua.DarValorVariable('t', Theta4);
                    double R4 = Evalua.Evaluar();
                    if (double.IsNaN(R4) || double.IsInfinity(R4)) R4 = 0;
                    
                    double X4 = R4 * Math.Cos(Phi4) * Math.Sin(Theta4);
                    double Y4 = R4 * Math.Sin(Phi4) * Math.Sin(Theta4);
                    double Z4 = R4 * Math.Cos(Theta4);

                    //VALORES EXTREMOS
                    if (X1 < MinimoX) MinimoX = X1;
                    if (X2 < MinimoX) MinimoX = X2;
                    if (X3 < MinimoX) MinimoX = X3;
                    if (X4 < MinimoX) MinimoX = X4;

                    if (Y1 < MinimoY) MinimoY = Y1;
                    if (Y2 < MinimoY) MinimoY = Y2;
                    if (Y3 < MinimoY) MinimoY = Y3;
                    if (Y4 < MinimoY) MinimoY = Y4;

                    if (Z1 < MinimoZ) MinimoZ = Z1;
                    if (Z2 < MinimoZ) MinimoZ = Z2;
                    if (Z3 < MinimoZ) MinimoZ = Z3;
                    if (Z4 < MinimoZ) MinimoZ = Z4;

                    if (X1 > MaximoX) MaximoX = X1;
                    if (X2 > MaximoX) MaximoX = X2;
                    if (X3 > MaximoX) MaximoX = X3;
                    if (X4 > MaximoX) MaximoX = X4;

                    if (Y1 > MaximoY) MaximoY = Y1;
                    if (Y2 > MaximoY) MaximoY = Y2;
                    if (Y3 > MaximoY) MaximoY = Y3;
                    if (Y4 > MaximoY) MaximoY = Y4;

                    if (Z1 > MaximoZ) MaximoZ = Z1;
                    if (Z2 > MaximoZ) MaximoZ = Z2;
                    if (Z3 > MaximoZ) MaximoZ = Z3;
                    if (Z4 > MaximoZ) MaximoZ = Z4;

                    //Añade un polígono a la lista
                    poligono.Add(new Poligono(X1, Y1, Z1,
                                                X2, Y2, Z2,
                                                X3, Y3, Z3,
                                                X4, Y4, Z4));
                }

            //Luego normaliza los puntos X,Y,Z
            //para que queden entre -0.5 y 0.5
            for (int cont = 0; cont < poligono.Count; cont++)
                poligono[cont].Normaliza(MinimoX, MinimoY, MinimoZ,
                                        MaximoX, MaximoY, MaximoZ);

        }

        public void CalculaGrafico(double AngX, double AngY, double AngZ) {
            int ZPersona = 5;
            int XpIni = 400;
            int YpIni = 0;
            int XpFin = 1200;
            int YpFin = 800;

            //Genera la matriz de rotación
            double CosX = Math.Cos(AngX * Math.PI / 180);
            double SinX = Math.Sin(AngX * Math.PI / 180);
            double CosY = Math.Cos(AngY * Math.PI / 180);
            double SinY = Math.Sin(AngY * Math.PI / 180);
            double CosZ = Math.Cos(AngZ * Math.PI / 180);
            double SinZ = Math.Sin(AngZ * Math.PI / 180);

            //Matriz de Rotación: https://en.wikipedia.org/wiki/Rotation_formalisms_in_three_dimensions
            double[,] Matriz = new double[3, 3] {
{CosY*CosZ,-CosX*SinZ+SinX*SinY*CosZ,SinX*SinZ+CosX*SinY*CosZ},
{CosY*SinZ,CosX*CosZ+SinX*SinY*SinZ,-SinX*CosZ+CosX*SinY*SinZ},
{-SinY,SinX*CosY,CosX*CosY}
            };

            //Los valores extremos al girar la figura en X, Y, Z
            //(de 0 a 360 grados), porque está contenida
            //en un cubo de 1*1*1
            double MaximoX = 0.87931543769177811;
            double MinimoX = -0.87931543769177811;
            double MaximoY = 0.87931543769177811;
            double MinimoY = -0.87931543769177811;

            //Las constantes de transformación
            double conX = (XpFin - XpIni) / (MaximoX - MinimoX);
            double conY = (YpFin - YpIni) / (MaximoY - MinimoY);

            //Gira los polígonos, proyecta a 2D y cuadra en pantalla
            for (int cont = 0; cont < poligono.Count; cont++)
                poligono[cont].CalculoPantalla(Matriz, ZPersona,
                                                conX, conY,
                                                MinimoX, MinimoY,
                                                XpIni, YpIni);

            //Ordena del polígono más alejado al más cercano,
            //de esa manera los polígonos de adelante son
            //visibles y los de atrás son borrados.
            poligono.Sort();
        }

        //Dibuja el polígono
        public void Dibuja(Graphics Lienzo, Pen Lapiz, Brush Relleno) {
            for (int Cont = 0; Cont < poligono.Count; Cont++)
                poligono[Cont].Dibuja(Lienzo, Lapiz, Relleno);
        }
    }
}
