﻿namespace Grafico {
    class Graf3D {
        //Donde almacena los poligonos
        private List<Poligono> poligono;

        public void CalculaEcuacion(int numLineas, Evaluador4 Evalua, double minX, double maxX) {
            //Inicia el listado de polígonos que forma la figura			 
            poligono = [];

            //Mínimos y máximos para normalizar
            double MinimoX = double.MaxValue;
            double MaximoX = double.MinValue;
            double MinimoY = double.MaxValue;
            double MaximoY = double.MinValue;
            double MinimoZ = double.MaxValue;
            double MaximoZ = double.MinValue;

            double IncAng = 360 / numLineas;
            double IncX = (maxX - minX) / numLineas;
            double radian = Math.PI / 180;

            //Usando la matriz de Giro en X, se toma cada punto
            //del gráfico 2D Y=F(X) y se hace girar en X
            for (double ang = 0; ang < 360; ang += IncAng)
                for (double X = minX; X <= maxX; X += IncX) {

                    //Primer punto
                    double X1 = X;
                    Evalua.DarValorVariable('x', X1);
                    double Y1 = Evalua.Evaluar();
                    if (double.IsNaN(Y1) || double.IsInfinity(Y1)) Y1 = 0;

                    //Hace giro
                    double X1g = X1;
                    double Y1g = Y1 * Math.Cos(ang * radian);
                    double Z1g = Y1 * Math.Sin(ang * radian);

                    //Segundo punto
                    double X2 = X + IncX;
                    Evalua.DarValorVariable('x', X2);
                    double Y2 = Evalua.Evaluar();
                    if (double.IsNaN(Y2) || double.IsInfinity(Y2)) Y2 = 0;

                    //Hace giro
                    double X2g = X2;
                    double Y2g = Y2 * Math.Cos(ang * radian);
                    double Z2g = Y2 * Math.Sin(ang * radian);

                    //Tercer punto ya girado
                    double X3g = X2;
                    double Y3g = Y2 * Math.Cos((ang + IncAng) * radian);
                    double Z3g = Y2 * Math.Sin((ang + IncAng) * radian);

                    //Cuarto punto ya girado
                    double X4g = X1;
                    double Y4g = Y1 * Math.Cos((ang + IncAng) * radian);
                    double Z4g = Y1 * Math.Sin((ang + IncAng) * radian);

                    //Obtener los valores extremos para poder normalizar
                    if (X1g < MinimoX) MinimoX = X1g;
                    if (X2g < MinimoX) MinimoX = X2g;
                    if (X3g < MinimoX) MinimoX = X3g;
                    if (X4g < MinimoX) MinimoX = X4g;

                    if (Y1g < MinimoY) MinimoY = Y1g;
                    if (Y2g < MinimoY) MinimoY = Y2g;
                    if (Y3g < MinimoY) MinimoY = Y3g;
                    if (Y4g < MinimoY) MinimoY = Y4g;

                    if (Z1g < MinimoZ) MinimoZ = Z1g;
                    if (Z2g < MinimoZ) MinimoZ = Z2g;
                    if (Z3g < MinimoZ) MinimoZ = Z3g;
                    if (Z4g < MinimoZ) MinimoZ = Z4g;

                    if (X1g > MaximoX) MaximoX = X1g;
                    if (X2g > MaximoX) MaximoX = X2g;
                    if (X3g > MaximoX) MaximoX = X3g;
                    if (X4g > MaximoX) MaximoX = X4g;

                    if (Y1g > MaximoY) MaximoY = Y1g;
                    if (Y2g > MaximoY) MaximoY = Y2g;
                    if (Y3g > MaximoY) MaximoY = Y3g;
                    if (Y4g > MaximoY) MaximoY = Y4g;

                    if (Z1g > MaximoZ) MaximoZ = Z1g;
                    if (Z2g > MaximoZ) MaximoZ = Z2g;
                    if (Z3g > MaximoZ) MaximoZ = Z3g;
                    if (Z4g > MaximoZ) MaximoZ = Z4g;

                    poligono.Add(new Poligono(X1g, Y1g, Z1g,
                                                X2g, Y2g, Z2g,
                                                X3g, Y3g, Z3g,
                                                X4g, Y4g, Z4g));
                }

            //Luego normaliza los puntos X,Y,Z
            //para que queden entre -0.5 y 0.5
            for (int cont = 0; cont < poligono.Count; cont++)
                poligono[cont].Normaliza(MinimoX, MinimoY, MinimoZ,
                                          MaximoX, MaximoY, MaximoZ);

        }

        public void CalculaGrafico(double AngX, double AngY, double AngZ) {
            int ZPersona = 5;
            int XpIni = 400;
            int YpIni = 0;
            int XpFin = 1200;
            int YpFin = 800;

            //Genera la matriz de rotación
            double CosX = Math.Cos(AngX * Math.PI / 180);
            double SinX = Math.Sin(AngX * Math.PI / 180);
            double CosY = Math.Cos(AngY * Math.PI / 180);
            double SinY = Math.Sin(AngY * Math.PI / 180);
            double CosZ = Math.Cos(AngZ * Math.PI / 180);
            double SinZ = Math.Sin(AngZ * Math.PI / 180);

            //Matriz de Rotación: https://en.wikipedia.org/wiki/Rotation_formalisms_in_three_dimensions
            double[,] Matriz = new double[3, 3] {
{CosY*CosZ,-CosX*SinZ+SinX*SinY*CosZ,SinX*SinZ+CosX*SinY*CosZ},
{CosY*SinZ,CosX*CosZ+SinX*SinY*SinZ,-SinX*CosZ+CosX*SinY*SinZ},
{-SinY,SinX*CosY,CosX*CosY}
            };

            //Los valores extremos al girar la figura en X, Y, Z
            //(de 0 a 360 grados), porque está contenida
            //en un cubo de 1*1*1
            double MaximoX = 0.87931543769177811;
            double MinimoX = -0.87931543769177811;
            double MaximoY = 0.87931543769177811;
            double MinimoY = -0.87931543769177811;

            //Las constantes de transformación
            double conX = (XpFin - XpIni) / (MaximoX - MinimoX);
            double conY = (YpFin - YpIni) / (MaximoY - MinimoY);

            //Gira los polígonos, proyecta a 2D y cuadra en pantalla
            for (int cont = 0; cont < poligono.Count; cont++)
                poligono[cont].CalculoPantalla(Matriz, ZPersona,
                                                conX, conY,
                                                MinimoX, MinimoY,
                                                XpIni, YpIni);

            //Ordena del polígono más alejado al más cercano,
            //de esa manera los polígonos de adelante son
            //visibles y los de atrás son borrados.
            poligono.Sort();
        }

        //Dibuja el polígono
        public void Dibuja(Graphics Lienzo, Pen Lapiz, Brush Relleno) {
            for (int Cont = 0; Cont < poligono.Count; Cont++)
                poligono[Cont].Dibuja(Lienzo, Lapiz, Relleno);
        }
    }
}
