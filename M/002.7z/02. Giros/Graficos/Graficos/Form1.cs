﻿//Proyección 3D a 2D. Uso de giros en X, Y, Z pero tan sólo en uno
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Graficos {
    public partial class Form1 : Form {
        //El cubo que se proyecta y gira
        Cubo Figura3D;

        public Form1() {
            InitializeComponent();
            
            Figura3D = new Cubo();
            Figura3D.AplicaGiro(0, 0);
        }

        private void numGiroX_ValueChanged(object sender, System.EventArgs e) {
            //Se anulan los dos valores de los otros ángulos
            numGiroY.Value = 0;
            numGiroZ.Value = 0;

            //Sólo puede girar en un ángulo
            int AnguloX = Convert.ToInt32(numGiroX.Value);
            Figura3D.AplicaGiro(0, AnguloX); //O es giro en X
            Refresh();
        }

        private void numGiroY_ValueChanged(object sender, EventArgs e) {
            numGiroX.Value = 0;
            numGiroZ.Value = 0;
            int AnguloY = Convert.ToInt32(numGiroY.Value);
            Figura3D.AplicaGiro(1, AnguloY); //1 es giro en Y
            Refresh();
        }

        private void numGiroZ_ValueChanged(object sender, EventArgs e) {
            numGiroX.Value = 0;
            numGiroY.Value = 0;
            int AnguloZ = Convert.ToInt32(numGiroZ.Value);
            Figura3D.AplicaGiro(2, AnguloZ); //2 es giro en Z
            Refresh();
        }

        //Pinta la proyección
        private void Form1_Paint(object sender, PaintEventArgs e) {
            Graphics Lienzo = e.Graphics;
            Pen Lapiz = new Pen(Color.Blue, 3);

            int ZPersona = 180;
            Figura3D.Convierte3Da2D(ZPersona);
            Figura3D.Dibuja(Lienzo, Lapiz);
        }
    }
}