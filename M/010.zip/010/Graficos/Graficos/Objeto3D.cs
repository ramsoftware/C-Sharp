﻿namespace Graficos {
    internal class Objeto3D {
        //Coordenadas espaciales X, Y, Z
        private List<Punto> puntos;

        //Coordenadas del polígono (triángulo)
        private List<Poligono> poligonos;

        //Constructor
        public Objeto3D() {
            //Ejemplo de coordenadas espaciales X,Y,Z
            puntos = [
                new Punto( 0.00000000000,  0.361803,  0.5),
                new Punto( 0.00000000000,  0.361803, -0.5),
                new Punto( 0.00000000000, -0.361803,  0.5),
                new Punto( 0.00000000000, -0.361803, -0.5),
                new Punto( 0.361803,  0.5,  0.00000000000),
                new Punto( 0.361803, -0.5,  0.00000000000),
                new Punto(-0.361803,  0.5,  0.00000000000),
                new Punto(-0.361803, -0.5,  0.00000000000),
                new Punto( 0.5,  0.00000000000,  0.361803),
                new Punto( 0.5,  0.00000000000, -0.361803),
                new Punto(-0.5,  0.00000000000,  0.361803),
                new Punto(-0.5,  0.00000000000, -0.361803),
             ];


            //Los polígonos que dibujan el icosaedro
            poligonos = [
                 new Poligono(0, 6, 4),
                 new Poligono(0, 4, 8),
                 new Poligono(0, 8, 2),
                 new Poligono(0, 2, 10),
                 new Poligono(0, 10, 6),
                 new Poligono(1, 9, 4),
                 new Poligono(1, 4, 6),
                 new Poligono(1, 6, 11),
                 new Poligono(1, 11, 3),
                 new Poligono(1, 3, 9),
                 new Poligono(2, 8, 5),
                 new Poligono(2, 5, 7),
                 new Poligono(2, 7, 10),
                 new Poligono(3, 11, 7),
                 new Poligono(3, 7, 5),
                 new Poligono(3, 5, 9),
                 new Poligono(6, 10, 11),
                 new Poligono(5, 8, 9),
                 new Poligono(7, 11, 10),
                 new Poligono(4, 9, 8)
            ];
        }

        public void GirarFigura(double angX, double angY, double angZ, double ZPersona, int XpantallaIni, int YpantallaIni, int XpantallaFin, int YpantallaFin) {
            //Para la matriz de rotación
            double CosX = Math.Cos(angX);
            double SinX = Math.Sin(angX);
            double CosY = Math.Cos(angY);
            double SinY = Math.Sin(angY);
            double CosZ = Math.Cos(angZ);
            double SinZ = Math.Sin(angZ);

            //Matriz de Rotación
            //https://en.wikipedia.org/wiki/Rotation_formalisms_in_three_dimensions
            double[,] Matriz = new double[3, 3] {
                { CosY * CosZ, -CosX * SinZ + SinX * SinY * CosZ, SinX * SinZ + CosX * SinY * CosZ},
                { CosY * SinZ, CosX * CosZ + SinX * SinY * SinZ, -SinX * CosZ + CosX * SinY * SinZ},
                {-SinY, SinX * CosY, CosX * CosY }
            };

            //Las constantes de transformación para cuadrar en pantalla
            double convierteX = (XpantallaFin - XpantallaIni) / 1.758630875383556;
            double convierteY = (YpantallaFin - YpantallaIni) / 1.758630875383556;

            //Gira los 8 puntos
            for (int cont = 0; cont < puntos.Count; cont++)
                puntos[cont].Giro(Matriz, ZPersona, XpantallaIni, YpantallaIni, convierteX, convierteY);

            //Calcula la profundidad y forma el polígono
            for (int Cont = 0; Cont < poligonos.Count; Cont++)
                poligonos[Cont].ProfundidadFigura(puntos);

            //Algoritmo de pintor.
            //Ordena del polígono más alejado al más cercano,
            //los polígonos de adelante son visibles y los de atrás son borrados.
            poligonos.Sort((p1, p2) => p1.Centro.CompareTo(p2.Centro));
        }

        //Dibuja el icosaedro
        public void Dibuja(Graphics lienzo, Pen lapizIcosaedro, Brush relleno) {
            for (int Cont = 0; Cont < poligonos.Count; Cont++)
                poligonos[Cont].Dibuja(lienzo, lapizIcosaedro, relleno);
        }
    }
}

