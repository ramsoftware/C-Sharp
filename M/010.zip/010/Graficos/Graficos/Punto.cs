﻿namespace Graficos {
    //Cada punto espacial es almacenado y convertido
    internal class Punto {
        private double X, Y, Z; //Coordenadas originales
        public double Zgiro; //Al girar los puntos
        public int Xpantalla, Ypantalla; //Puntos en pantalla

        public Punto(double X, double Y, double Z) {
            this.X = X;
            this.Y = Y;
            this.Z = Z;
        }

        //Giro en los tres ejes
        public void Giro(double[,] Matriz, double ZPersona, int XpantallaIni, int YpantallaIni, double convierteX, double convierteY) {

            //Hace el giro
            double Xgiro = X * Matriz[0, 0] + Y * Matriz[1, 0] + Z * Matriz[2, 0];
            double Ygiro = X * Matriz[0, 1] + Y * Matriz[1, 1] + Z * Matriz[2, 1];
            Zgiro = X * Matriz[0, 2] + Y * Matriz[1, 2] + Z * Matriz[2, 2];

            //Convierte de 3D a 2D (segunda dimensión)
            double PlanoX = Xgiro * ZPersona / (ZPersona - Zgiro);
            double PlanoY = Ygiro * ZPersona / (ZPersona - Zgiro);

            //Deduce las coordenadadas de pantalla
            Xpantalla = Convert.ToInt32(convierteX * (PlanoX + 0.879315437691778) + XpantallaIni);
            Ypantalla = Convert.ToInt32(convierteY * (PlanoY + 0.879315437691778) + YpantallaIni);
        }
    }
}
