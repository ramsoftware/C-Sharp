﻿namespace Graficos {
    public partial class Valores : Form {

        Form1 FrmGrafico = new();
        const double Radianes = Math.PI / 180;
        public Valores() {
            InitializeComponent();

            FrmGrafico.AnguloX = Convert.ToDouble(numGiroX.Value) * Radianes;
            FrmGrafico.AnguloY = Convert.ToDouble(numGiroY.Value) * Radianes;
            FrmGrafico.AnguloZ = Convert.ToDouble(numGiroZ.Value) * Radianes;
            FrmGrafico.NumLineas = Convert.ToInt32((double)numTotalLineas.Value);
            FrmGrafico.Ecuacion = txtEcuacion.Text;
            FrmGrafico.ZPersona = 5;
            FrmGrafico.HuboCambio = true;

            FrmGrafico.Show();
        }

        private void numGiroX_ValueChanged(object sender, EventArgs e) {
            FrmGrafico.AnguloX = Convert.ToDouble(numGiroX.Value) * Radianes;
            FrmGrafico.HuboCambio = true;
            FrmGrafico.Refresh();
        }

        private void numGiroY_ValueChanged(object sender, EventArgs e) {
            FrmGrafico.AnguloY = Convert.ToDouble(numGiroY.Value) * Radianes;
            FrmGrafico.HuboCambio = true;
            FrmGrafico.Refresh();
        }

        private void numGiroZ_ValueChanged(object sender, EventArgs e) {
            FrmGrafico.AnguloZ = Convert.ToDouble(numGiroZ.Value) * Radianes;
            FrmGrafico.HuboCambio = true;
            FrmGrafico.Refresh();
        }

        private void numMinimoX_ValueChanged(object sender, EventArgs e) {

        }

        private void numMinimoY_ValueChanged(object sender, EventArgs e) {

        }

        private void numMaximoX_ValueChanged(object sender, EventArgs e) {
        }

        private void numMaximoY_ValueChanged(object sender, EventArgs e) {
        }

        private void numTotalLineas_ValueChanged(object sender, EventArgs e) {
            FrmGrafico.NumLineas = Convert.ToInt32((double)numTotalLineas.Value);
            FrmGrafico.HuboCambio = true;
            FrmGrafico.Refresh();
        }

        private void btnProcesar_Click(object sender, EventArgs e) {
            FrmGrafico.Ecuacion = txtEcuacion.Text;
            FrmGrafico.HuboCambio = true;
            FrmGrafico.Refresh();
        }
    }
}
