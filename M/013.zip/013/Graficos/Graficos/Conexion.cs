﻿namespace Graficos {
	//Conecta con una línea recta un punto con otro
	internal class Conexion {
		public int punto1, punto2;

		public Conexion(int punto1, int punto2) {
			this.punto1 = punto1;
			this.punto2 = punto2;
		}
	}
}
