﻿namespace Graficos {
    internal class Objeto3D {
        //Coordenadas espaciales X, Y, Z
        private List<Punto> puntos;

        //Coordenadas del polígono (triángulo)
        private List<Poligono> poligonos;

        //Constructor
        public Objeto3D() {
            double Xini = -10;
            double Yini = -10;
            double Xfin = 10;
            double Yfin = 10;
            int NumLineas = 40;

            double IncrX = (Xfin - Xini) / (NumLineas-1);
            double IncrY = (Yfin - Yini) / (NumLineas-1);
            double X = Xini, Y = Yini;

            //Coordenadas espaciales X,Y,Z
            puntos = [];
            for (int EjeY = 1; EjeY <= NumLineas; EjeY++) {
                for (int EjeX = 1; EjeX <= NumLineas; EjeX++) {
                    double Z = Ecuacion(X, Y);
                    puntos.Add(new Punto(X, Y, Z));
                    X += IncrX;
                }
                X = Xini;
                Y += IncrY;
            }

            //Debe normalizar las coordenadas y ponerlas entre -0.5 y 0.5
            double Xmin = double.MaxValue;
            double Ymin = double.MaxValue;
            double Zmin = double.MaxValue;
            double Xmax = double.MinValue;
            double Ymax = double.MinValue;
            double Zmax = double.MinValue;
            for (int Cont = 0; Cont < puntos.Count; Cont++) {
                if (puntos[Cont].X < Xmin) Xmin = puntos[Cont].X;
                if (puntos[Cont].Y < Ymin) Ymin = puntos[Cont].Y;
                if (puntos[Cont].Z < Zmin) Zmin = puntos[Cont].Z;
                if (puntos[Cont].X > Xmax) Xmax = puntos[Cont].X;
                if (puntos[Cont].Y > Ymax) Ymax = puntos[Cont].Y;
                if (puntos[Cont].Z > Zmax) Zmax = puntos[Cont].Z;
            }

            for (int Cont = 0; Cont < puntos.Count; Cont++) {
                puntos[Cont].X = (puntos[Cont].X - Xmin) / (Xmax - Xmin) - 0.5;
                puntos[Cont].Y = (puntos[Cont].Y - Ymin) / (Ymax - Ymin) - 0.5;
                puntos[Cont].Z = (puntos[Cont].Z - Zmin) / (Zmax - Zmin) - 0.5;
            }

            // Inicializa la lista de polígonos
            poligonos = new List<Poligono>();

            int coordenadaActual = 0;
            int filaActual = 1;
            int totalPoligonos = (NumLineas - 1) * (NumLineas - 1);

            for (int Cont = 0; Cont < totalPoligonos; Cont++) {
                // Crea un polígono con las coordenadas de los vértices
                poligonos.Add(new Poligono(
                    coordenadaActual,
                    coordenadaActual + 1,
                    coordenadaActual + NumLineas + 1,
                    coordenadaActual + NumLineas
                ));

                coordenadaActual++;

                // Salta al inicio de la siguiente fila si se alcanza el final de la actual
                if (coordenadaActual == NumLineas * filaActual - 1) {
                    coordenadaActual++;
                    filaActual++;
                }
            }
        }

        public double Ecuacion(double X, double Y) {
            double Z = Math.Sqrt(X * X + Y * Y);
            Z += 3 * Math.Cos(Math.Sqrt(X * X + Y * Y)) + 5;
            return Z;
        }

        public void GirarFigura(double angX, double angY, double angZ, double ZPersona, int XpantallaIni, int YpantallaIni, int XpantallaFin, int YpantallaFin) {
            //Para la matriz de rotación
            double CosX = Math.Cos(angX);
            double SinX = Math.Sin(angX);
            double CosY = Math.Cos(angY);
            double SinY = Math.Sin(angY);
            double CosZ = Math.Cos(angZ);
            double SinZ = Math.Sin(angZ);

            //Matriz de Rotación
            //https://en.wikipedia.org/wiki/Rotation_formalisms_in_three_dimensions
            double[,] Matriz = new double[3, 3] {
                { CosY * CosZ, -CosX * SinZ + SinX * SinY * CosZ, SinX * SinZ + CosX * SinY * CosZ},
                { CosY * SinZ, CosX * CosZ + SinX * SinY * SinZ, -SinX * CosZ + CosX * SinY * SinZ},
                {-SinY, SinX * CosY, CosX * CosY }
            };

            //Las constantes de transformación para cuadrar en pantalla
            double convierteX = (XpantallaFin - XpantallaIni) / 1.758630875383556;
            double convierteY = (YpantallaFin - YpantallaIni) / 1.758630875383556;

            //Gira los puntos
            for (int cont = 0; cont < puntos.Count; cont++)
                puntos[cont].Giro(Matriz, ZPersona, XpantallaIni, YpantallaIni, convierteX, convierteY);

            //Calcula la profundidad y forma el polígono
            for (int Cont = 0; Cont < poligonos.Count; Cont++)
                poligonos[Cont].ProfundidadFigura(puntos);

            //Algoritmo de pintor.
            //Ordena del polígono más alejado al más cercano,
            //los polígonos de adelante son visibles y los de atrás son borrados.
            poligonos.Sort((p1, p2) => p1.Centro.CompareTo(p2.Centro));
        }

        //Dibuja la figura 3D
        public void Dibuja(Graphics lienzo, Pen lapizIcosaedro, Brush relleno) {
            for (int Cont = 0; Cont < poligonos.Count; Cont++)
                poligonos[Cont].Dibuja(lienzo, lapizIcosaedro, relleno);
        }
    }
}

