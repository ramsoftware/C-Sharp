using System.Diagnostics;

namespace Graficos {
	//Proyecci�n 3D a 2D y giros. Figura centrada. Optimizaci�n.
	public partial class Form1 : Form {

		//Para calcular los FPS (Frames Per Second)
		private Stopwatch cronometro = new Stopwatch();
		private int fps = 0;
		private int contadorFrames = 0;
		private long tiempoAcumulado = 0;

		//El icosaedro que se proyecta y gira
		Objeto3D Figura3D;

		//Tama�o de pantalla
		double AnguloX, AnguloY, AnguloZ, ZPersona;
		const double Radianes = Math.PI / 180;
		int XpantallaIni, YpantallaIni, XpantallaFin, YpantallaFin;

		//Para dibujar
		Pen LapizIcosaedro = new(Color.Black, 1);
		Brush Relleno = new SolidBrush(Color.White);

		public Form1() {
			InitializeComponent();

			//Para calcular los FPS (Frames Per Second)
			cronometro.Start();
			System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
			timer.Interval = 15; // ~60 FPS
			timer.Tick += (s, e) => this.Invalidate(); // Forzar redibujo
			timer.Start();

			//Distancia del observador
			ZPersona = 5;

			//Tama�o de pantalla
			XpantallaIni = 20;
			YpantallaIni = 20;
			XpantallaFin = 800;
			YpantallaFin = 800;

			Figura3D = new Objeto3D();

			//Gira, proyecta y cuadra cada punto de la figura 3D
			AnguloX = Convert.ToDouble(numGiroX.Value) * Radianes;
			AnguloY = Convert.ToDouble(numGiroY.Value) * Radianes;
			AnguloZ = Convert.ToDouble(numGiroZ.Value) * Radianes;
			Figura3D.GirarFigura(AnguloX, AnguloY, AnguloZ, ZPersona, XpantallaIni, YpantallaIni, XpantallaFin, YpantallaFin);
		}

		private void Form1_Paint(object sender, PaintEventArgs e) {

			//Dibuja la figura 3D
			Figura3D.Dibuja(e.Graphics, LapizIcosaedro, Relleno);

			//Calcular los FPS
			contadorFrames++;
			tiempoAcumulado += cronometro.ElapsedMilliseconds;
			cronometro.Restart();

			if (tiempoAcumulado >= 1000) {  // cada segundo
				fps = contadorFrames;
				contadorFrames = 0;
				tiempoAcumulado = 0;
			}

			// Dibujar texto con los FPS
			e.Graphics.DrawString($"FPS: {fps}", this.Font, Brushes.Red, 10, 10);
		}

		private void numGiroX_ValueChanged(object sender, EventArgs e) {
			AnguloX = Convert.ToDouble(numGiroX.Value) * Radianes;
			Figura3D.GirarFigura(AnguloX, AnguloY, AnguloZ, ZPersona, XpantallaIni, YpantallaIni, XpantallaFin, YpantallaFin);
			Refresh();
		}

		private void numGiroY_ValueChanged(object sender, EventArgs e) {
			AnguloY = Convert.ToDouble(numGiroY.Value) * Radianes;
			Figura3D.GirarFigura(AnguloX, AnguloY, AnguloZ, ZPersona, XpantallaIni, YpantallaIni, XpantallaFin, YpantallaFin);
			Refresh();
		}

		private void numGiroZ_ValueChanged(object sender, EventArgs e) {
			AnguloZ = Convert.ToDouble(numGiroZ.Value) * Radianes;
			Figura3D.GirarFigura(AnguloX, AnguloY, AnguloZ, ZPersona, XpantallaIni, YpantallaIni, XpantallaFin, YpantallaFin);
			Refresh();
		}
	}
}
