﻿using System;

namespace CalculaConstante {
    internal class Program {
        static void Main(string[] args) {
            Cubo Figura3D = new Cubo();
            Figura3D.CalculaExtremo(5);
        }
    }
}