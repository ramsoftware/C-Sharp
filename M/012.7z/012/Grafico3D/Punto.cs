﻿namespace Grafico3D {

    //Calcula el punto X,Y,Z de la ecuación
    public class Punto {
        private double X, Y, Z; //Coordenadas originales
        private double Xg, Yg, Zg; //Coordenadas al girar
        private double PlanoX, PlanoY; //Proyección o sombra
        public int Xp, Yp; //En Pantalla

        //Calcula el valor de Z, guarda los valores de X, Y
        public void Calcular(double X, double Y, Evaluador4 Evalua) {
            this.X = X;
            this.Y = Y;
            Evalua.DarValorVariable('x', X);
            Evalua.DarValorVariable('y', Y);
            Z = Evalua.Evaluar();
            if (double.IsNaN(Z) || double.IsInfinity(Z))
                Z = 0;
        }

        //Retorna el valor de Z sin girar
        public double getZ() {
            return Z;
        }

        //Retorna el valor de Z al girar
        public double getZg() {
            return Zg;
        }

        //Normaliza punto y luego lo ubica entre -0.5 y 0.5
        public void Normaliza(double MinX, double MinY, double MinZ,
                              double MaxX, double MaxY, double MaxZ) {
            X = (X - MinX) / (MaxX - MinX) - 0.5;
            Y = (Y - MinY) / (MaxY - MinY) - 0.5;
            Z = (Z - MinZ) / (MaxZ - MinZ) - 0.5;
        }

        //Gira el punto
        public void Giro(double[,] Mt) {
            Xg = X * Mt[0, 0] + Y * Mt[1, 0] + Z * Mt[2, 0];
            Yg = X * Mt[0, 1] + Y * Mt[1, 1] + Z * Mt[2, 1];
            Zg = X * Mt[0, 2] + Y * Mt[1, 2] + Z * Mt[2, 2];
        }

        //Convierte de 3D a 2D (segunda dimensión)
        public void Proyecta(double ZPersona) {
            PlanoX = Xg * ZPersona / (ZPersona - Zg);
            PlanoY = Yg * ZPersona / (ZPersona - Zg);
        }

        //Convierte 2D real a 2D pantalla
        public void Pantalla(int XpFin, int YpFin) {
            //Constante de transformación, nacida de girar la
            //figura en los ejes X, Y, Z (de 0 a 360 grados),
            //porque está contenida en un cubo de 1*1*1 cuyo centroide
            //está en 0,0,0
            double C = 1.758630875;

            //Cuadra en pantalla física
            Xp = Convert.ToInt32(XpFin / C * (PlanoX + C/2.0));
            Yp = Convert.ToInt32(YpFin / C * (PlanoY + C/2.0));
        }
    }
}
