﻿namespace Grafico3D {
    partial class Grafico {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            SuspendLayout();
            // 
            // Grafico
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(784, 761);
            DoubleBuffered = true;
            Name = "Grafico";
            StartPosition = FormStartPosition.Manual;
            Text = "Gráfico Z = F(X,Y)";
            FormClosed += Grafico_FormClosed;
            Paint += Grafico_Paint;
            MouseDown += Grafico_MouseDown;
            MouseMove += Grafico_MouseMove;
            MouseUp += Grafico_MouseUp;
            Resize += Grafico_Resize;
            ResumeLayout(false);
        }

        #endregion
    }
}