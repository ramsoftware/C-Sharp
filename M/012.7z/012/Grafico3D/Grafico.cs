﻿namespace Grafico3D {
    public partial class Grafico : Form {
        public Graf3D graf3D;
        private bool MousePresionado = false;
        private int MouseAntesX, MouseAntesY;

        public Grafico() {
            InitializeComponent();
        }

        private void Grafico_Paint(object sender, PaintEventArgs e) {
            Graphics Lienzo = e.Graphics;

            for (int Cont = 0; Cont < graf3D.Poligonos.Count; Cont++)
                graf3D.Poligonos[Cont].Dibuja(Lienzo);
        }

        private void Grafico_Resize(object sender, EventArgs e) {
            //Cuadrar en pantalla
            graf3D.setAltoAnchoVentana(this.ClientSize.Height, this.ClientSize.Width);
            graf3D.GiroProyectaCuadra();
            Refresh();
        }

        private void Grafico_MouseDown(object sender, MouseEventArgs e) {
            if (e.Button == MouseButtons.Left) {
                MousePresionado = true;
                this.Cursor = Cursors.SizeAll;
                MouseAntesX = e.X;
                MouseAntesY = e.Y;
            }
        }

        private void Grafico_MouseUp(object sender, MouseEventArgs e) {
            if (e.Button == MouseButtons.Left) {
                MousePresionado = false;
                this.Cursor = Cursors.Default;
            }
        }

        private void Grafico_MouseMove(object sender, MouseEventArgs e) {
            if (MousePresionado) {
                if (e.X > MouseAntesX)
                    graf3D.setAnguloY(graf3D.getAnguloY() - 2);
                else if (e.X < MouseAntesX)
                    graf3D.setAnguloY(graf3D.getAnguloY() + 2);

                if (e.Y > MouseAntesY)
                    graf3D.setAnguloX(graf3D.getAnguloX() + 2);
                else if (e.Y < MouseAntesY)
                    graf3D.setAnguloX(graf3D.getAnguloX() - 2);

                MouseAntesX = e.X;
                MouseAntesY = e.Y;
                graf3D.GiroProyectaCuadra();
                Refresh();
            }
        }

        private void Grafico_FormClosed(object sender, FormClosedEventArgs e) {
            Application.Exit();
        }
    }
}
