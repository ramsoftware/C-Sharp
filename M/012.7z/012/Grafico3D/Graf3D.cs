﻿namespace Grafico3D {
    public class Graf3D {
        //Arreglo bidimensional que tiene los puntos
        public Punto[][] MtPunto;

        double MinX, MinY, MaxX, MaxY, MinZ, MaxZ;
        double AnguloX, AnguloY;
        double ZPersona;
        int NumLineas;
        int AnchoVentana, AltoVentana;

        //Listado de poligonos
        public List<Poligono> Poligonos;

        //Colores para pintar la malla
        List<Color> ListaColores;

        //La ecuación
        Evaluador4 Evalua;

        public void Inicializa() {
            //Angulos de giro
            this.AnguloX = 0;
            this.AnguloY = 0;

            //Distancia de la persona al plano
            ZPersona = 5;

            //Inicializa polígonos
            Poligonos = [];

            int NumColores = 40; // Número de colores a generar
            ListaColores = GeneraGradienteColor(NumColores);
        }

        public void setAltoAnchoVentana(int AltoVentana, int AnchoVentana) {
            this.AnchoVentana = AnchoVentana;
            this.AltoVentana = AltoVentana;
        }

        public void setAnguloX(double AnguloX) {
            this.AnguloX = AnguloX;
        }

        public void setAnguloY(double AnguloY) {
            this.AnguloY = AnguloY;
        }

        public double getAnguloX() { return this.AnguloX; }
        public double getAnguloY() { return this.AnguloY; }

        public void Calcula(double MinX, double MaxX, double MinY, double MaxY, int NumLineas, Evaluador4 Evalua) {
            //Valores del formulario
            this.MinX = MinX;
            this.MaxX = MaxX;
            this.MinY = MinY;
            this.MaxY = MaxY;

            //Número de líneas que forma la malla
            this.NumLineas = NumLineas;

            //La ecuación
            this.Evalua = Evalua;

            IniciaMatrizPuntos();
            CalculaXYZ();
            ExtremosZ();
            NormalizaCalculos();
            GiroProyectaCuadra();
        }

        //Guarda los puntos calculados en una matriz bidimensional
        private void IniciaMatrizPuntos() {
            //Arreglo de arreglos
            MtPunto = new Punto[NumLineas][];
            for (int Fila = 0; Fila < MtPunto.Length; Fila++) {
                MtPunto[Fila] = new Punto[NumLineas];
                for (int Columna = 0; Columna < MtPunto[Fila].Length; Columna++) {
                    MtPunto[Fila][Columna] = new Punto();
                }
            }
        }

        private void CalculaXYZ() {
            //Calcula las coordenadas XYZ originales
            double IncrY = (MaxY - MinY) / NumLineas;
            double IncrX = (MaxX - MinX) / NumLineas;
            double X = MinX;
            double Y = MinY;

            for (int Fila = 0; Fila < NumLineas; Fila++) {
                X = MinX;
                for (int Columna = 0; Columna < NumLineas; Columna++) {
                    MtPunto[Fila][Columna].Calcular(X, Y, Evalua);
                    X += IncrX;
                }
                Y += IncrY;
            }
        }

        private void ExtremosZ() {
            MinZ = double.MaxValue;
            MaxZ = double.MinValue;

            for (int Fila = 0; Fila < NumLineas; Fila++) {
                for (int Columna = 0; Columna < NumLineas; Columna++) {
                    //Los valores extremos de Z
                    if (MtPunto[Fila][Columna].getZ() < MinZ)
                        MinZ = MtPunto[Fila][Columna].getZ();

                    if (MtPunto[Fila][Columna].getZ() > MaxZ)
                        MaxZ = MtPunto[Fila][Columna].getZ();
                }
            }
        }

        private void NormalizaCalculos() {
            for (int Fila = 0; Fila < NumLineas; Fila++)
                for (int Columna = 0; Columna < NumLineas; Columna++)
                    MtPunto[Fila][Columna].Normaliza(MinX, MinY, MinZ, MaxX, MaxY, MaxZ);
        }

        public void GiroProyectaCuadra() {
            //Genera la matriz de rotación
            double CosX = Math.Cos(AnguloX * Math.PI / 180);
            double SinX = Math.Sin(AnguloX * Math.PI / 180);
            double CosY = Math.Cos(AnguloY * Math.PI / 180);
            double SinY = Math.Sin(AnguloY * Math.PI / 180);

            //Matriz de Rotación (sólo de X, Y)
            //https://en.wikipedia.org/wiki/Rotation_formalisms_in_three_dimensions
            double[,] MtRota = new double[3, 3] {
                    {CosY,0,SinY},
                    {SinX*SinY,CosX,-SinX*CosY},
                    {-CosX*SinY,SinX,CosX*CosY}
            };

            for (int Fila = 0; Fila < NumLineas; Fila++)
                for (int Columna = 0; Columna < NumLineas; Columna++) {
                    MtPunto[Fila][Columna].Giro(MtRota);
                    MtPunto[Fila][Columna].Proyecta(ZPersona);
                    MtPunto[Fila][Columna].Pantalla(AnchoVentana, AltoVentana);
                }

            //Genera los poligonos
            GeneraPoligonos();

            //Ordena del polígono más alejado al más cercano,
            //de esa manera los polígonos de adelante son
            //visibles y los de atrás son borrados.
            Poligonos.Sort();
        }

        //Usa 4 coordenadas XY de pantalla para hacer cada polígono
        private void GeneraPoligonos() {
            Poligonos.Clear();
            for (int Fila = 0; Fila < NumLineas - 1; Fila++)
                for (int Columna = 0; Columna < NumLineas - 1; Columna++) {
                    int X1 = MtPunto[Fila][Columna].Xp;
                    int Y1 = MtPunto[Fila][Columna].Yp;
                    double Zg1 = MtPunto[Fila][Columna].getZg();
                    double Z1 = MtPunto[Fila][Columna].getZ();

                    int X2 = MtPunto[Fila][Columna + 1].Xp;
                    int Y2 = MtPunto[Fila][Columna + 1].Yp;
                    double Zg2 = MtPunto[Fila][Columna + 1].getZg();
                    double Z2 = MtPunto[Fila][Columna + 1].getZ();

                    int X3 = MtPunto[Fila + 1][Columna + 1].Xp;
                    int Y3 = MtPunto[Fila + 1][Columna + 1].Yp;
                    double Zg3 = MtPunto[Fila + 1][Columna + 1].getZg();
                    double Z3 = MtPunto[Fila + 1][Columna + 1].getZ();

                    int X4 = MtPunto[Fila + 1][Columna].Xp;
                    int Y4 = MtPunto[Fila + 1][Columna].Yp;
                    double Zg4 = MtPunto[Fila + 1][Columna].getZg();
                    double Z4 = MtPunto[Fila + 1][Columna].getZ();

                    Poligonos.Add(new Poligono(X1, Y1, X2, Y2, X3, Y3, X4, Y4, Zg1, Zg2, Zg3, Zg4, Z1, Z2, Z3, Z4, ListaColores));
                }
        }

        List<Color> GeneraGradienteColor(int NumColores) {
            List<Color> Colores = [];
            int Mitad = NumColores / 2;

            // Gradiente de azul a amarillo
            for (int Cont = 0; Cont < Mitad; Cont++) {
                int Rojo = (int)(255 * (Cont / (float)(NumColores - Mitad - 1)));
                int Verde = (int)(255 * (Cont / (float)(NumColores - Mitad - 1)));
                int Azul = 255 - (int)(255 * (Cont / (float)(NumColores - Mitad - 1)));
                Colores.Add(Color.FromArgb(Rojo, Verde, Azul));
            }

            // Gradiente de rojo a azul
            for (int Cont = 0; Cont < NumColores - Mitad; Cont++) {
                int Rojo = 255 - (int)(255 * (Cont / (float)(Mitad - 1)));
                int Verde = 0;
                int Azul = (int)(255 * (Cont / (float)(Mitad - 1)));
                Colores.Add(Color.FromArgb(Rojo, Verde, Azul));
            }

            return Colores;
        }
    }
}
