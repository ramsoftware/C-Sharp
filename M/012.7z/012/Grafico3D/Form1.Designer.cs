﻿namespace Grafico3D {
    partial class Form1 {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            lblEcuacion = new Label();
            btnProcesa = new Button();
            lblNumLineas = new Label();
            numLineas = new NumericUpDown();
            lblYmaximo = new Label();
            lblYminimo = new Label();
            lblXmaximo = new Label();
            lblXminimo = new Label();
            numYmaximo = new NumericUpDown();
            numYminimo = new NumericUpDown();
            numXmaximo = new NumericUpDown();
            numXminimo = new NumericUpDown();
            cboEcuacion = new ComboBox();
            btnAyuda = new Button();
            ((System.ComponentModel.ISupportInitialize)numLineas).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numYmaximo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numYminimo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numXmaximo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numXminimo).BeginInit();
            SuspendLayout();
            // 
            // lblEcuacion
            // 
            lblEcuacion.AutoSize = true;
            lblEcuacion.Location = new Point(27, 15);
            lblEcuacion.Name = "lblEcuacion";
            lblEcuacion.Size = new Size(54, 16);
            lblEcuacion.TabIndex = 2;
            lblEcuacion.Text = "f (x, y)";
            // 
            // btnProcesa
            // 
            btnProcesa.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnProcesa.Location = new Point(27, 94);
            btnProcesa.Name = "btnProcesa";
            btnProcesa.Size = new Size(344, 31);
            btnProcesa.TabIndex = 4;
            btnProcesa.Text = "Verificar, procesar y dibujar";
            btnProcesa.UseVisualStyleBackColor = true;
            btnProcesa.Click += btnProcesa_Click;
            // 
            // lblNumLineas
            // 
            lblNumLineas.AutoSize = true;
            lblNumLineas.Location = new Point(739, 54);
            lblNumLineas.Name = "lblNumLineas";
            lblNumLineas.Size = new Size(119, 16);
            lblNumLineas.TabIndex = 5;
            lblNumLineas.Text = "Número de líneas";
            // 
            // numLineas
            // 
            numLineas.Location = new Point(870, 54);
            numLineas.Maximum = new decimal(new int[] { 110, 0, 0, 0 });
            numLineas.Minimum = new decimal(new int[] { 40, 0, 0, 0 });
            numLineas.Name = "numLineas";
            numLineas.Size = new Size(81, 23);
            numLineas.TabIndex = 6;
            numLineas.TextAlign = HorizontalAlignment.Right;
            numLineas.Value = new decimal(new int[] { 70, 0, 0, 0 });
            numLineas.ValueChanged += numLineas_ValueChanged;
            // 
            // lblYmaximo
            // 
            lblYmaximo.AutoSize = true;
            lblYmaximo.Location = new Point(559, 54);
            lblYmaximo.Name = "lblYmaximo";
            lblYmaximo.Size = new Size(75, 16);
            lblYmaximo.TabIndex = 15;
            lblYmaximo.Text = "Y máximo:";
            // 
            // lblYminimo
            // 
            lblYminimo.AutoSize = true;
            lblYminimo.Location = new Point(383, 54);
            lblYminimo.Name = "lblYminimo";
            lblYminimo.Size = new Size(71, 16);
            lblYminimo.TabIndex = 14;
            lblYminimo.Text = "Y mínimo:";
            // 
            // lblXmaximo
            // 
            lblXmaximo.AutoSize = true;
            lblXmaximo.Location = new Point(203, 54);
            lblXmaximo.Name = "lblXmaximo";
            lblXmaximo.Size = new Size(75, 16);
            lblXmaximo.TabIndex = 13;
            lblXmaximo.Text = "X máximo:";
            // 
            // lblXminimo
            // 
            lblXminimo.AutoSize = true;
            lblXminimo.Location = new Point(27, 54);
            lblXminimo.Name = "lblXminimo";
            lblXminimo.Size = new Size(71, 16);
            lblXminimo.TabIndex = 12;
            lblXminimo.Text = "X mínimo:";
            // 
            // numYmaximo
            // 
            numYmaximo.DecimalPlaces = 2;
            numYmaximo.Location = new Point(646, 54);
            numYmaximo.Maximum = new decimal(new int[] { 99999, 0, 0, 0 });
            numYmaximo.Minimum = new decimal(new int[] { 99999, 0, 0, int.MinValue });
            numYmaximo.Name = "numYmaximo";
            numYmaximo.Size = new Size(81, 23);
            numYmaximo.TabIndex = 11;
            numYmaximo.TextAlign = HorizontalAlignment.Right;
            numYmaximo.Value = new decimal(new int[] { 5, 0, 0, 0 });
            // 
            // numYminimo
            // 
            numYminimo.DecimalPlaces = 2;
            numYminimo.Location = new Point(466, 54);
            numYminimo.Maximum = new decimal(new int[] { 99999, 0, 0, 0 });
            numYminimo.Minimum = new decimal(new int[] { 99999, 0, 0, int.MinValue });
            numYminimo.Name = "numYminimo";
            numYminimo.Size = new Size(81, 23);
            numYminimo.TabIndex = 10;
            numYminimo.TextAlign = HorizontalAlignment.Right;
            numYminimo.Value = new decimal(new int[] { 5, 0, 0, int.MinValue });
            // 
            // numXmaximo
            // 
            numXmaximo.DecimalPlaces = 2;
            numXmaximo.Location = new Point(290, 54);
            numXmaximo.Maximum = new decimal(new int[] { 99999, 0, 0, 0 });
            numXmaximo.Minimum = new decimal(new int[] { 99999, 0, 0, int.MinValue });
            numXmaximo.Name = "numXmaximo";
            numXmaximo.Size = new Size(81, 23);
            numXmaximo.TabIndex = 9;
            numXmaximo.TextAlign = HorizontalAlignment.Right;
            numXmaximo.Value = new decimal(new int[] { 5, 0, 0, 0 });
            // 
            // numXminimo
            // 
            numXminimo.DecimalPlaces = 2;
            numXminimo.Location = new Point(110, 54);
            numXminimo.Maximum = new decimal(new int[] { 99999, 0, 0, 0 });
            numXminimo.Minimum = new decimal(new int[] { 99999, 0, 0, int.MinValue });
            numXminimo.Name = "numXminimo";
            numXminimo.Size = new Size(81, 23);
            numXminimo.TabIndex = 8;
            numXminimo.TextAlign = HorizontalAlignment.Right;
            numXminimo.Value = new decimal(new int[] { 5, 0, 0, int.MinValue });
            // 
            // cboEcuacion
            // 
            cboEcuacion.FormattingEnabled = true;
            cboEcuacion.Items.AddRange(new object[] { "x^2-y^2", "exp(y^2-x^2)", "sen(x)+cos(y)", "7*x*y/exp(x^2 + y^2)", "-4*x/(x^2+y^2+1)", "(x+y)/(x-y)", "exp(0-x^2 - y^2)", "atn(tan(x) + tan(y))" });
            cboEcuacion.Location = new Point(110, 15);
            cboEcuacion.Name = "cboEcuacion";
            cboEcuacion.Size = new Size(775, 24);
            cboEcuacion.TabIndex = 16;
            cboEcuacion.Text = "sen(sqr(x^2 + y^2))";
            // 
            // btnAyuda
            // 
            btnAyuda.Location = new Point(891, 14);
            btnAyuda.Name = "btnAyuda";
            btnAyuda.Size = new Size(66, 30);
            btnAyuda.TabIndex = 17;
            btnAyuda.Text = "Ayuda";
            btnAyuda.UseVisualStyleBackColor = true;
            btnAyuda.Click += btnAyuda_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 16F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(966, 137);
            Controls.Add(btnAyuda);
            Controls.Add(cboEcuacion);
            Controls.Add(lblYmaximo);
            Controls.Add(lblYminimo);
            Controls.Add(lblXmaximo);
            Controls.Add(lblXminimo);
            Controls.Add(numYmaximo);
            Controls.Add(numYminimo);
            Controls.Add(numXmaximo);
            Controls.Add(numXminimo);
            Controls.Add(numLineas);
            Controls.Add(lblNumLineas);
            Controls.Add(btnProcesa);
            Controls.Add(lblEcuacion);
            Font = new Font("Verdana", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.Manual;
            Text = "Parámetros del gráfico";
            Shown += Form1_Shown;
            ((System.ComponentModel.ISupportInitialize)numLineas).EndInit();
            ((System.ComponentModel.ISupportInitialize)numYmaximo).EndInit();
            ((System.ComponentModel.ISupportInitialize)numYminimo).EndInit();
            ((System.ComponentModel.ISupportInitialize)numXmaximo).EndInit();
            ((System.ComponentModel.ISupportInitialize)numXminimo).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label lblEcuacion;
        private Button btnProcesa;
        private Label lblNumLineas;
        private NumericUpDown numLineas;
        private Label lblYmaximo;
        private Label lblYminimo;
        private Label lblXmaximo;
        private Label lblXminimo;
        private NumericUpDown numYmaximo;
        private NumericUpDown numYminimo;
        private NumericUpDown numXmaximo;
        private NumericUpDown numXminimo;
        private ComboBox cboEcuacion;
        private Button btnAyuda;
    }
}
