namespace Grafico3D {
    public partial class Form1 : Form {
        Graf3D graf3D;
        Evaluador4 Evaluador;
        Grafico Ventana;

        public Form1() {
            InitializeComponent();

            graf3D = new Graf3D();
            graf3D.Inicializa();
        }

        private void numXminimo_ValueChanged(object sender, EventArgs e) {
            if (numXminimo.Value >= numXmaximo.Value)
                numXminimo.Value = numXmaximo.Value - 1;
            Recalcula();
        }

        private void numXmaximo_ValueChanged(object sender, EventArgs e) {
            if (numXmaximo.Value <= numXminimo.Value)
                numXmaximo.Value = numXminimo.Value + 1;
            Recalcula();
        }

        private void numYminimo_ValueChanged(object sender, EventArgs e) {
            if (numYminimo.Value >= numYmaximo.Value)
                numYminimo.Value = numYmaximo.Value - 1;
            Recalcula();
        }

        private void numYmaximo_ValueChanged(object sender, EventArgs e) {
            if (numYmaximo.Value <= numYminimo.Value)
                numYmaximo.Value = numYminimo.Value + 1;
            Recalcula();
        }

        private void numLineas_ValueChanged(object sender, EventArgs e) {
            Recalcula();
        }

        //Si el usuario ingresa una nueva ecuaci�n
        private void btnProcesa_Click(object sender, EventArgs e) {
            string Ecuacion = cboEcuacion.Text;
            int Sintaxis = Evaluador.Analizar(Ecuacion);
            if (Sintaxis > 0) {
                string MensajeError = Evaluador.MensajeError(Sintaxis);
                MessageBox.Show(MensajeError, "Error de sintaxis",
    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
                Recalcula();
        }

        //Si la ecuaci�n ya ha sido analizada, se llama a este m�todo
        //que es para calcular cuando cambian los valores m�nimos y m�ximos
        //de X y Y
        private void Recalcula() {
            graf3D.Calcula((double)numXminimo.Value,
                    (double)numXmaximo.Value,
                    (double)numYminimo.Value,
                    (double)numYmaximo.Value,
                    (int)numLineas.Value, Evaluador);
            Ventana.graf3D = graf3D;
            Ventana.Refresh();
        }


        private void Form1_Shown(object sender, EventArgs e) {
            this.Location = new Point(10, 10);

            //Llama la ventana que muestra el gr�fico
            Ventana = new Grafico();
            Ventana.Location = new Point(this.Location.X, this.Location.Y + this.Height);
            Ventana.Show();

            //Cuadrar en pantalla
            graf3D.setAltoAnchoVentana(Ventana.ClientSize.Height, Ventana.ClientSize.Width);

            //La primera vez calcula la ecuaci�n
            Evaluador = new Evaluador4();
            string Ecuacion = cboEcuacion.Text;
            Evaluador.Analizar(Ecuacion);
            Recalcula();
        }

        private void btnAyuda_Click(object sender, EventArgs e) {
            string Ayuda = "USE:\r\n\r\nseno: sen( \r\ncoseno: cos( \r\ntangente: tan( \r\nvalor absoluto: abs( \r\narcoseno: asn( \r\narcocoseno: acs( \r\narcotantenge: atn( \r\nlogaritmo natural: log( \r\nexponencial: exp( \r\nraiz cuadrada: sqr( \r\n\r\nSuma: + \r\nResta: - \r\nMultiplicaci�n: * \r\nDivisi�n: / \r\nPotencia: ^ \r\nPar�ntesis: (  ) \r\nVariables: x  y ";
            MessageBox.Show(Ayuda, "Expresiones matem�ticas",
MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
