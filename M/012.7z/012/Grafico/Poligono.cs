﻿namespace Grafico {
    internal class Poligono : IComparable {
        //Un polígono son cuatro(4) coordenadas espaciales
        public double X1, Y1, Z1, X2, Y2, Z2, X3, Y3, Z3, X4, Y4, Z4;

        //Las coordenadas en pantalla
        public int X1p, Y1p, X2p, Y2p, X3p, Y3p, X4p, Y4p;

        //El valor de Z mas profundo del polígono
        public double ZMasFondo;

        public Poligono(double X1, double Y1, double Z1,
                        double X2, double Y2, double Z2,
                        double X3, double Y3, double Z3,
                        double X4, double Y4, double Z4) {
            this.X1 = X1; this.Y1 = Y1; this.Z1 = Z1;
            this.X2 = X2; this.Y2 = Y2; this.Z2 = Z2;
            this.X3 = X3; this.Y3 = Y3; this.Z3 = Z3;
            this.X4 = X4; this.Y4 = Y4; this.Z4 = Z4;
        }

        //Normaliza puntos polígono entre -0.5 y 0.5
        public void Normaliza(double MinimoX, double MinimoY, double MinimoZ,
                              double MaximoX, double MaximoY, double MaximoZ) {
            X1 = (X1 - MinimoX) / (MaximoX - MinimoX) - 0.5;
            Y1 = (Y1 - MinimoY) / (MaximoY - MinimoY) - 0.5;
            Z1 = (Z1 - MinimoZ) / (MaximoZ - MinimoZ) - 0.5;

            X2 = (X2 - MinimoX) / (MaximoX - MinimoX) - 0.5;
            Y2 = (Y2 - MinimoY) / (MaximoY - MinimoY) - 0.5;
            Z2 = (Z2 - MinimoZ) / (MaximoZ - MinimoZ) - 0.5;

            X3 = (X3 - MinimoX) / (MaximoX - MinimoX) - 0.5;
            Y3 = (Y3 - MinimoY) / (MaximoY - MinimoY) - 0.5;
            Z3 = (Z3 - MinimoZ) / (MaximoZ - MinimoZ) - 0.5;

            X4 = (X4 - MinimoX) / (MaximoX - MinimoX) - 0.5;
            Y4 = (Y4 - MinimoY) / (MaximoY - MinimoY) - 0.5;
            Z4 = (Z4 - MinimoZ) / (MaximoZ - MinimoZ) - 0.5;
        }


        //Gira en XYZ, convierte a 2D y cuadra en pantalla
        public void CalculoPantalla(double[,] Mt, double ZPersona,
                                    double ConstanteX, double ConstanteY,
                                    double MinimoX, double MinimoY,
                                    int XpIni, int YpIni) {
            double X1g = X1 * Mt[0, 0] + Y1 * Mt[1, 0] + Z1 * Mt[2, 0];
            double Y1g = X1 * Mt[0, 1] + Y1 * Mt[1, 1] + Z1 * Mt[2, 1];
            double Z1g = X1 * Mt[0, 2] + Y1 * Mt[1, 2] + Z1 * Mt[2, 2];

            double X2g = X2 * Mt[0, 0] + Y2 * Mt[1, 0] + Z2 * Mt[2, 0];
            double Y2g = X2 * Mt[0, 1] + Y2 * Mt[1, 1] + Z2 * Mt[2, 1];
            double Z2g = X2 * Mt[0, 2] + Y2 * Mt[1, 2] + Z2 * Mt[2, 2];

            double X3g = X3 * Mt[0, 0] + Y3 * Mt[1, 0] + Z3 * Mt[2, 0];
            double Y3g = X3 * Mt[0, 1] + Y3 * Mt[1, 1] + Z3 * Mt[2, 1];
            double Z3g = X3 * Mt[0, 2] + Y3 * Mt[1, 2] + Z3 * Mt[2, 2];

            double X4g = X4 * Mt[0, 0] + Y4 * Mt[1, 0] + Z4 * Mt[2, 0];
            double Y4g = X4 * Mt[0, 1] + Y4 * Mt[1, 1] + Z4 * Mt[2, 1];
            double Z4g = X4 * Mt[0, 2] + Y4 * Mt[1, 2] + Z4 * Mt[2, 2];

            //Usado para ordenar los polígonos del más lejano al más cercano
            ZMasFondo = Double.MaxValue;
            if (Z1g < ZMasFondo) ZMasFondo = Z1g;
            if (Z2g < ZMasFondo) ZMasFondo = Z2g;
            if (Z3g < ZMasFondo) ZMasFondo = Z3g;
            if (Z4g < ZMasFondo) ZMasFondo = Z4g;   

            //Convierte de 3D a 2D (segunda dimensión)
            double X1sd = X1g * ZPersona / (ZPersona - Z1g);
            double Y1sd = Y1g * ZPersona / (ZPersona - Z1g);

            double X2sd = X2g * ZPersona / (ZPersona - Z2g);
            double Y2sd = Y2g * ZPersona / (ZPersona - Z2g);

            double X3sd = X3g * ZPersona / (ZPersona - Z3g);
            double Y3sd = Y3g * ZPersona / (ZPersona - Z3g);

            double X4sd = X4g * ZPersona / (ZPersona - Z4g);
            double Y4sd = Y4g * ZPersona / (ZPersona - Z4g);

            //Cuadra en pantalla física
            X1p = Convert.ToInt32(ConstanteX * (X1sd - MinimoX) + XpIni);
            Y1p = Convert.ToInt32(ConstanteY * (Y1sd - MinimoY) + YpIni);

            X2p = Convert.ToInt32(ConstanteX * (X2sd - MinimoX) + XpIni);
            Y2p = Convert.ToInt32(ConstanteY * (Y2sd - MinimoY) + YpIni);

            X3p = Convert.ToInt32(ConstanteX * (X3sd - MinimoX) + XpIni);
            Y3p = Convert.ToInt32(ConstanteY * (Y3sd - MinimoY) + YpIni);

            X4p = Convert.ToInt32(ConstanteX * (X4sd - MinimoX) + XpIni);
            Y4p = Convert.ToInt32(ConstanteY * (Y4sd - MinimoY) + YpIni);
        }

        //Hace el gráfico del polígono
        public void Dibuja(Graphics Lienzo, Pen Lapiz, Brush Relleno) {
            //Pone un color de fondo al polígono
            //para borrar lo que hay detrás
            Point Punto1 = new(X1p, Y1p);
            Point Punto2 = new(X2p, Y2p);
            Point Punto3 = new(X3p, Y3p);
            Point Punto4 = new(X4p, Y4p);
            Point[] ListaPuntos = [Punto1, Punto2, Punto3, Punto4];

            //Dibuja el polígono relleno y su perímetro
            Lienzo.FillPolygon(Relleno, ListaPuntos);
            Lienzo.DrawPolygon(Lapiz, ListaPuntos);
        }

        //Usado para ordenar los polígonos
        //del más lejano al más cercano
        public int CompareTo(object obj) {
            Poligono OrdenCompara = obj as Poligono;
            if (OrdenCompara.ZMasFondo < ZMasFondo) return 1;
            if (OrdenCompara.ZMasFondo > ZMasFondo) return -1;
            return 0;
            //https://stackoverflow.com/questions/3309188/how-to-sort-a-listt-by-a-property-in-the-object
        }
    }
}