﻿namespace Grafico {
    partial class Form1 {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            numGiroZ = new NumericUpDown();
            numGiroY = new NumericUpDown();
            numGiroX = new NumericUpDown();
            lblGiroZ = new Label();
            lblGiroY = new Label();
            lblGiroX = new Label();
            label1 = new Label();
            lblProceso = new Label();
            txtEcuacion = new TextBox();
            txtProceso = new TextBox();
            btnProcesar = new Button();
            ((System.ComponentModel.ISupportInitialize)numGiroZ).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numGiroY).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numGiroX).BeginInit();
            SuspendLayout();
            // 
            // numGiroZ
            // 
            numGiroZ.Location = new Point(184, 124);
            numGiroZ.Margin = new Padding(4, 3, 4, 3);
            numGiroZ.Maximum = new decimal(new int[] { 360, 0, 0, 0 });
            numGiroZ.Name = "numGiroZ";
            numGiroZ.Size = new Size(89, 27);
            numGiroZ.TabIndex = 25;
            numGiroZ.TextAlign = HorizontalAlignment.Right;
            numGiroZ.Value = new decimal(new int[] { 82, 0, 0, 0 });
            numGiroZ.ValueChanged += numGiroZ_ValueChanged;
            // 
            // numGiroY
            // 
            numGiroY.Location = new Point(184, 74);
            numGiroY.Margin = new Padding(4, 3, 4, 3);
            numGiroY.Maximum = new decimal(new int[] { 360, 0, 0, 0 });
            numGiroY.Name = "numGiroY";
            numGiroY.Size = new Size(89, 27);
            numGiroY.TabIndex = 24;
            numGiroY.TextAlign = HorizontalAlignment.Right;
            numGiroY.Value = new decimal(new int[] { 45, 0, 0, 0 });
            numGiroY.ValueChanged += numGiroY_ValueChanged;
            // 
            // numGiroX
            // 
            numGiroX.Location = new Point(184, 25);
            numGiroX.Margin = new Padding(4, 3, 4, 3);
            numGiroX.Maximum = new decimal(new int[] { 360, 0, 0, 0 });
            numGiroX.Name = "numGiroX";
            numGiroX.Size = new Size(89, 27);
            numGiroX.TabIndex = 23;
            numGiroX.TextAlign = HorizontalAlignment.Right;
            numGiroX.Value = new decimal(new int[] { 45, 0, 0, 0 });
            numGiroX.ValueChanged += numGiroX_ValueChanged;
            // 
            // lblGiroZ
            // 
            lblGiroZ.AutoSize = true;
            lblGiroZ.ForeColor = Color.Black;
            lblGiroZ.Location = new Point(15, 132);
            lblGiroZ.Margin = new Padding(4, 0, 4, 0);
            lblGiroZ.Name = "lblGiroZ";
            lblGiroZ.Size = new Size(84, 18);
            lblGiroZ.TabIndex = 22;
            lblGiroZ.Text = "Giro en Z";
            // 
            // lblGiroY
            // 
            lblGiroY.AutoSize = true;
            lblGiroY.ForeColor = Color.Black;
            lblGiroY.Location = new Point(15, 82);
            lblGiroY.Margin = new Padding(4, 0, 4, 0);
            lblGiroY.Name = "lblGiroY";
            lblGiroY.Size = new Size(84, 18);
            lblGiroY.TabIndex = 21;
            lblGiroY.Text = "Giro en Y";
            // 
            // lblGiroX
            // 
            lblGiroX.AutoSize = true;
            lblGiroX.ForeColor = Color.Black;
            lblGiroX.Location = new Point(15, 33);
            lblGiroX.Margin = new Padding(4, 0, 4, 0);
            lblGiroX.Name = "lblGiroX";
            lblGiroX.Size = new Size(84, 18);
            lblGiroX.TabIndex = 20;
            lblGiroX.Text = "Giro en X";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = Color.Black;
            label1.Location = new Point(32, 780);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(437, 18);
            label1.TabIndex = 29;
            label1.Text = "Ecuación polar r=F(t, p) donde t es Theta y p es Phi";
            // 
            // lblProceso
            // 
            lblProceso.AutoSize = true;
            lblProceso.ForeColor = Color.Black;
            lblProceso.Location = new Point(32, 855);
            lblProceso.Margin = new Padding(4, 0, 4, 0);
            lblProceso.Name = "lblProceso";
            lblProceso.Size = new Size(78, 18);
            lblProceso.TabIndex = 30;
            lblProceso.Text = "Proceso:";
            // 
            // txtEcuacion
            // 
            txtEcuacion.Location = new Point(484, 780);
            txtEcuacion.Margin = new Padding(4, 3, 4, 3);
            txtEcuacion.Name = "txtEcuacion";
            txtEcuacion.Size = new Size(1026, 27);
            txtEcuacion.TabIndex = 31;
            txtEcuacion.Text = "cos(p + t) - sen(t - p)";
            // 
            // txtProceso
            // 
            txtProceso.Location = new Point(484, 851);
            txtProceso.Margin = new Padding(4, 3, 4, 3);
            txtProceso.Name = "txtProceso";
            txtProceso.Size = new Size(1026, 27);
            txtProceso.TabIndex = 32;
            // 
            // btnProcesar
            // 
            btnProcesar.Location = new Point(484, 813);
            btnProcesar.Margin = new Padding(4, 3, 4, 3);
            btnProcesar.Name = "btnProcesar";
            btnProcesar.Size = new Size(304, 29);
            btnProcesar.TabIndex = 33;
            btnProcesar.Text = "Procesar";
            btnProcesar.UseVisualStyleBackColor = true;
            btnProcesar.Click += btnProcesar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 18F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            ClientSize = new Size(1550, 888);
            Controls.Add(btnProcesar);
            Controls.Add(txtProceso);
            Controls.Add(txtEcuacion);
            Controls.Add(lblProceso);
            Controls.Add(label1);
            Controls.Add(numGiroZ);
            Controls.Add(numGiroY);
            Controls.Add(numGiroX);
            Controls.Add(lblGiroZ);
            Controls.Add(lblGiroY);
            Controls.Add(lblGiroX);
            DoubleBuffered = true;
            Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Margin = new Padding(4, 3, 4, 3);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Gráfico ecuación polar 3D";
            Paint += Form1_Paint;
            ((System.ComponentModel.ISupportInitialize)numGiroZ).EndInit();
            ((System.ComponentModel.ISupportInitialize)numGiroY).EndInit();
            ((System.ComponentModel.ISupportInitialize)numGiroX).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private NumericUpDown numGiroZ;
        private NumericUpDown numGiroY;
        private NumericUpDown numGiroX;
        private Label lblGiroZ;
        private Label lblGiroY;
        private Label lblGiroX;
        private Label label1;
        private Label lblProceso;
        private TextBox txtEcuacion;
        private TextBox txtProceso;
        private Button btnProcesar;
    }
}
