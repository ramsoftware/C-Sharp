namespace Grafico {
    public partial class Form1 : Form {
        Graf3D graf3D;

        public Form1() {
            InitializeComponent();
            graf3D = new Graf3D();
            graf3D.Inicializa();
            Recalcula();
        }

        private void numGiroX_ValueChanged(object sender, EventArgs e) {
            graf3D.setAnguloX((double)numGiroX.Value);
            graf3D.GiroProyectaCuadra();
            Refresh();
        }

        private void numGiroY_ValueChanged(object sender, EventArgs e) {
            graf3D.setAnguloY((double)numGiroY.Value);
            graf3D.GiroProyectaCuadra();
            Refresh();
        }

        private void numGiroZ_ValueChanged(object sender, EventArgs e) {
            graf3D.setAnguloZ((double)numGiroZ.Value);
            graf3D.GiroProyectaCuadra();
            Refresh();
        }

        private void numLineas_ValueChanged(object sender, EventArgs e) {
            Recalcula();
        }

        private void numXminimo_ValueChanged(object sender, EventArgs e) {
            if (numXminimo.Value >= numXmaximo.Value)
                numXminimo.Value = numXmaximo.Value - 1;
            Recalcula();
        }

        private void numXmaximo_ValueChanged(object sender, EventArgs e) {
            if (numXmaximo.Value <= numXminimo.Value)
                numXmaximo.Value = numXminimo.Value + 1;
            Recalcula();
        }

        private void numYminimo_ValueChanged(object sender, EventArgs e) {
            if (numYminimo.Value >= numYmaximo.Value)
                numYminimo.Value = numYmaximo.Value - 1;
            Recalcula();
        }

        private void numYmaximo_ValueChanged(object sender, EventArgs e) {
            if (numYmaximo.Value <= numYminimo.Value)
                numYmaximo.Value = numYminimo.Value + 1;
            Recalcula();
        }

        private void Recalcula() {
            graf3D.Calcula((double)numXminimo.Value,
                    (double)numXmaximo.Value,
                    (double)numYminimo.Value,
                    (double)numYmaximo.Value,
                    (double)numGiroX.Value,
                    (double)numGiroY.Value,
                    (double)numGiroZ.Value,
                    (int)numLineas.Value);
            Refresh();
        }

        private void Form1_Paint(object sender, PaintEventArgs e) {
            Graphics Lienzo = e.Graphics;

            for (int Cont = 0; Cont < graf3D.Poligonos.Count; Cont++)
                graf3D.Poligonos[Cont].Dibuja(Lienzo);
        }
    }
}
