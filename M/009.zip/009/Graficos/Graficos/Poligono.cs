﻿namespace Graficos {
    //Triángulo
    internal class Poligono {
        public int punto1, punto2, punto3;
        public double Centro;

        //Coordenadas de dibujo del polígono
        Point Punto1, Punto2, Punto3;

        public Poligono(int punto1, int punto2, int punto3) {
            this.punto1 = punto1;
            this.punto2 = punto2;
            this.punto3 = punto3;
        }

        //Calcula la profundidad y crea los vértices del polígo
        public void CalculaProfundidad(List<Punto> puntos) {
            double Z1 = puntos[punto1].Zgiro;
            double Z2 = puntos[punto2].Zgiro;
            double Z3 = puntos[punto3].Zgiro;
            Centro = (Z1+ Z2 +Z3) / 3;

            Punto1 = new(puntos[punto1].Xpantalla, puntos[punto1].Ypantalla);
            Punto2 = new(puntos[punto2].Xpantalla, puntos[punto2].Ypantalla);
            Punto3 = new(puntos[punto3].Xpantalla, puntos[punto3].Ypantalla);
        }

        //Hace el gráfico del polígono
        public void Dibuja(Graphics Lienzo, Pen Lapiz, Brush Relleno) {
            Point[] ListaPuntos = [Punto1, Punto2, Punto3];

            //Dibuja el polígono relleno y eso borra los polígonos que no se ven
            Lienzo.FillPolygon(Relleno, ListaPuntos);

            //Dibuja el perímetro del polígono haciéndolo visible.
            Lienzo.DrawPolygon(Lapiz, ListaPuntos);
        }
    }
}
