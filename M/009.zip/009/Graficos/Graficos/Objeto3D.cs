﻿namespace Graficos {
    internal class Objeto3D {
        //Coordenadas espaciales X, Y, Z
        private List<Punto> puntos;

        //Coordenadas del polígono (triángulo)
        private List<Poligono> poligonos;

        //Constructor
        public Objeto3D() {
            //Ejemplo de coordenadas espaciales X,Y,Z
            puntos = [
                new Punto( 0.00000000000,  0.361803,  0.5),
                new Punto( 0.00000000000,  0.361803, -0.5),
                new Punto( 0.00000000000, -0.361803,  0.5),
                new Punto( 0.00000000000, -0.361803, -0.5),
                new Punto( 0.361803,  0.5,  0.00000000000),
                new Punto( 0.361803, -0.5,  0.00000000000),
                new Punto(-0.361803,  0.5,  0.00000000000),
                new Punto(-0.361803, -0.5,  0.00000000000),
                new Punto( 0.5,  0.00000000000,  0.361803),
                new Punto( 0.5,  0.00000000000, -0.361803),
                new Punto(-0.5,  0.00000000000,  0.361803),
                new Punto(-0.5,  0.00000000000, -0.361803),

                //Coordenadas del cubo que contiene al icosaedro
                new Punto(-0.5, -0.5, -0.5),
                new Punto(0.5, -0.5, -0.5),
                new Punto(0.5, 0.5, -0.5),
                new Punto(-0.5, 0.5, -0.5),
                new Punto(-0.5, -0.5, 0.5),
                new Punto(0.5, -0.5, 0.5),
                new Punto(0.5, 0.5, 0.5),
                new Punto(-0.5, 0.5, 0.5)
             ];


            //Los polígonos que dibujan el icosaedro
            poligonos = [
                 new Poligono(0, 6, 4),
                 new Poligono(0, 4, 8),
                 new Poligono(0, 8, 2),
                 new Poligono(0, 2, 10),
                 new Poligono(0, 10, 6),
                 new Poligono(1, 9, 4),
                 new Poligono(1, 4, 6),
                 new Poligono(1, 6, 11),
                 new Poligono(1, 11, 3),
                 new Poligono(1, 3, 9),
                 new Poligono(2, 8, 5),
                 new Poligono(2, 5, 7),
                 new Poligono(2, 7, 10),
                 new Poligono(3, 11, 7),
                 new Poligono(3, 7, 5),
                 new Poligono(3, 5, 9),
                 new Poligono(6, 10, 11),
                 new Poligono(5, 8, 9),
                 new Poligono(7, 11, 10),
                 new Poligono(4, 9, 8)
            ];
        }

        public void GirarFigura(double angX, double angY, double angZ, double ZPersona, int XpantallaIni, int YpantallaIni, int XpantallaFin, int YpantallaFin) {
            //Gira los 8 puntos
            for (int cont = 0; cont < puntos.Count; cont++) {
                puntos[cont].Giro(angX, angY, angZ);
                puntos[cont].Proyecta(ZPersona);
                puntos[cont].CuadraPantalla(XpantallaIni, YpantallaIni, XpantallaFin, YpantallaFin);
            }

            //Calcula la profundidad promedio
            for (int Cont = 0; Cont < poligonos.Count; Cont++)
                poligonos[Cont].CalculaProfundidad(puntos);

            //Ordena del polígono más alejado al más cercano,
            //de esa manera los polígonos de adelante son
            //visibles y los de atrás son borrados.
            //Algoritmo de pintor.
            poligonos.Sort((p1, p2) => p1.Centro.CompareTo(p2.Centro));
        }

        //Dibuja el icosaedro
        public void Dibuja(Graphics lienzo, Pen lapizIcosaedro, Brush relleno) {
            for (int Cont = 0; Cont < poligonos.Count; Cont++)
                poligonos[Cont].Dibuja(lienzo, lapizIcosaedro, relleno);
        }
    }
}

