﻿namespace Graficos {
    internal class Objeto3D {
        //Coordenadas espaciales X, Y, Z
        private List<Punto> puntos;

        //Coordenadas del polígono (triángulo)
        private List<Poligono> poligonos;

        //Valores extremos
        private double minimoX, maximoX, minimoY, maximoY, convierteX, convierteY;

        //Despliegue en pantalla
        private int XpantallaIni, XpantallaFin, YpantallaIni, YpantallaFin;

        //Distancia del observador
        private int ZPersona;

        //Constructor
        public Objeto3D(int XpantallaIni, int XpantallaFin, int YpantallaIni, int YpantallaFin) {
            //Ejemplo de coordenadas espaciales X,Y,Z
            puntos = [
                new Punto( 0.00000000000,  0.361803,  0.5),
                new Punto( 0.00000000000,  0.361803, -0.5),
                new Punto( 0.00000000000, -0.361803,  0.5),
                new Punto( 0.00000000000, -0.361803, -0.5),
                new Punto( 0.361803,  0.5,  0.00000000000),
                new Punto( 0.361803, -0.5,  0.00000000000),
                new Punto(-0.361803,  0.5,  0.00000000000),
                new Punto(-0.361803, -0.5,  0.00000000000),
                new Punto( 0.5,  0.00000000000,  0.361803),
                new Punto( 0.5,  0.00000000000, -0.361803),
                new Punto(-0.5,  0.00000000000,  0.361803),
                new Punto(-0.5,  0.00000000000, -0.361803)
             ];

            //Los polígonos que dibujan el icosaedro
            poligonos = [
                 new Poligono(0, 6, 4),
                 new Poligono(0, 4, 8),
                 new Poligono(0, 8, 2),
                 new Poligono(0, 2, 10),
                 new Poligono(0, 10, 6),
                 new Poligono(1, 9, 4),
                 new Poligono(1, 4, 6),
                 new Poligono(1, 6, 11),
                 new Poligono(1, 11, 3),
                 new Poligono(1, 3, 9),
                 new Poligono(2, 8, 5),
                 new Poligono(2, 5, 7),
                 new Poligono(2, 7, 10),
                 new Poligono(3, 11, 7),
                 new Poligono(3, 7, 5),
                 new Poligono(3, 5, 9),
                 new Poligono(6, 10, 11),
                 new Poligono(5, 8, 9),
                 new Poligono(7, 11, 10),
                 new Poligono(9, 5, 8)
            ];

            this.XpantallaIni = XpantallaIni;
            this.XpantallaFin = XpantallaFin;
            this.YpantallaIni = YpantallaIni;
            this.YpantallaFin = YpantallaFin;
            this.ZPersona = 5;

            //Los valores extremos
            this.maximoX = 0.785674201318386;
            this.minimoX = -0.785674201318386;
            this.maximoY = 0.785674201318386;
            this.minimoY = -0.785674201318386;

            //Las constantes de transformación
            convierteX = (XpantallaFin - XpantallaIni) / (maximoX - minimoX);
            convierteY = (YpantallaFin - YpantallaIni) / (maximoY - minimoY);
        }

        public void GiroX(int Angulo) {
            double Radian = Angulo * Math.PI / 180;
            for (int cont = 0; cont < puntos.Count; cont++) {
                puntos[cont].GiroX(Radian);
                puntos[cont].Proyecta(ZPersona);
                puntos[cont].CuadraPantalla(convierteX, convierteY,
                                    minimoX, minimoY,
                                    XpantallaIni, XpantallaFin,
                                    YpantallaIni, YpantallaFin);
            }
        }

        public void GiroY(int Angulo) {
            double Radian = Angulo * Math.PI / 180;
            for (int cont = 0; cont < puntos.Count; cont++) {
                puntos[cont].GiroY(Radian);
                puntos[cont].Proyecta(ZPersona);
                puntos[cont].CuadraPantalla(convierteX, convierteY,
                                    minimoX, minimoY,
                                    XpantallaIni, XpantallaFin,
                                    YpantallaIni, YpantallaFin);
            }
        }

        public void GiroZ(int Angulo) {
            double Radian = Angulo * Math.PI / 180;
            for (int cont = 0; cont < puntos.Count; cont++) {
                puntos[cont].GiroZ(Radian);
                puntos[cont].Proyecta(ZPersona);
                puntos[cont].CuadraPantalla(convierteX, convierteY,
                                    minimoX, minimoY,
                                    XpantallaIni, XpantallaFin,
                                    YpantallaIni, YpantallaFin);
            }
        }

        //Dibuja el icosaedro
        public void Dibuja(Graphics lienzo, Pen lapiz) {
            for (int Cont = 0; Cont < poligonos.Count; Cont++) {
                int puntoA = poligonos[Cont].punto1;
                int puntoB = poligonos[Cont].punto2;
                int puntoC = poligonos[Cont].punto3;
                lienzo.DrawLine(lapiz, puntos[puntoA].Xpantalla, puntos[puntoA].Ypantalla,
                                   puntos[puntoB].Xpantalla, puntos[puntoB].Ypantalla);
                lienzo.DrawLine(lapiz, puntos[puntoA].Xpantalla, puntos[puntoA].Ypantalla,
                                   puntos[puntoC].Xpantalla, puntos[puntoC].Ypantalla);
                lienzo.DrawLine(lapiz, puntos[puntoC].Xpantalla, puntos[puntoC].Ypantalla,
                                   puntos[puntoB].Xpantalla, puntos[puntoB].Ypantalla);
            }
        }
    }
}

