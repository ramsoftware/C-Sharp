﻿namespace Graficos
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            numGiroX = new NumericUpDown();
            numGiroY = new NumericUpDown();
            numGiroZ = new NumericUpDown();
            lblGiroX = new Label();
            lblGiroY = new Label();
            lblGiroZ = new Label();
            ((System.ComponentModel.ISupportInitialize)numGiroX).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numGiroY).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numGiroZ).BeginInit();
            SuspendLayout();
            // 
            // numGiroX
            // 
            numGiroX.Location = new Point(854, 23);
            numGiroX.Maximum = new decimal(new int[] { 360, 0, 0, 0 });
            numGiroX.Name = "numGiroX";
            numGiroX.Size = new Size(113, 23);
            numGiroX.TabIndex = 0;
            numGiroX.TextAlign = HorizontalAlignment.Right;
            numGiroX.ValueChanged += numGiroX_ValueChanged;
            // 
            // numGiroY
            // 
            numGiroY.Location = new Point(854, 77);
            numGiroY.Maximum = new decimal(new int[] { 360, 0, 0, 0 });
            numGiroY.Name = "numGiroY";
            numGiroY.Size = new Size(113, 23);
            numGiroY.TabIndex = 1;
            numGiroY.TextAlign = HorizontalAlignment.Right;
            numGiroY.ValueChanged += numGiroY_ValueChanged;
            // 
            // numGiroZ
            // 
            numGiroZ.Location = new Point(854, 128);
            numGiroZ.Maximum = new decimal(new int[] { 360, 0, 0, 0 });
            numGiroZ.Name = "numGiroZ";
            numGiroZ.Size = new Size(113, 23);
            numGiroZ.TabIndex = 2;
            numGiroZ.TextAlign = HorizontalAlignment.Right;
            numGiroZ.ValueChanged += numGiroZ_ValueChanged;
            // 
            // lblGiroX
            // 
            lblGiroX.AutoSize = true;
            lblGiroX.Location = new Point(781, 23);
            lblGiroX.Name = "lblGiroX";
            lblGiroX.Size = new Size(67, 16);
            lblGiroX.TabIndex = 3;
            lblGiroX.Text = "Giro en X";
            // 
            // lblGiroY
            // 
            lblGiroY.AutoSize = true;
            lblGiroY.Location = new Point(781, 79);
            lblGiroY.Name = "lblGiroY";
            lblGiroY.Size = new Size(67, 16);
            lblGiroY.TabIndex = 4;
            lblGiroY.Text = "Giro en Y";
            // 
            // lblGiroZ
            // 
            lblGiroZ.AutoSize = true;
            lblGiroZ.Location = new Point(781, 135);
            lblGiroZ.Name = "lblGiroZ";
            lblGiroZ.Size = new Size(67, 16);
            lblGiroZ.TabIndex = 5;
            lblGiroZ.Text = "Giro en Z";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 16F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(981, 711);
            Controls.Add(lblGiroZ);
            Controls.Add(lblGiroY);
            Controls.Add(lblGiroX);
            Controls.Add(numGiroZ);
            Controls.Add(numGiroY);
            Controls.Add(numGiroX);
            DoubleBuffered = true;
            Font = new Font("Verdana", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Proyección 3D a 2D. Cubo centrado. Giros independientes.";
            Paint += Form1_Paint;
            ((System.ComponentModel.ISupportInitialize)numGiroX).EndInit();
            ((System.ComponentModel.ISupportInitialize)numGiroY).EndInit();
            ((System.ComponentModel.ISupportInitialize)numGiroZ).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private NumericUpDown numGiroX;
        private NumericUpDown numGiroY;
        private NumericUpDown numGiroZ;
        private Label lblGiroX;
        private Label lblGiroY;
        private Label lblGiroZ;
    }
}
