namespace Graficos {
	//Proyecci�n 3D a 2D y giros. Figura centrada.
	public partial class Form1 : Form {
		//El icosaedro que se proyecta y gira
		Objeto3D Figura3D;

		public Form1() {
			InitializeComponent();

			int XpantallaIni = 0, XpantallaFin = 700, YpantallaIni = 0, YpantallaFin = 700;
			Figura3D = new Objeto3D(XpantallaIni, XpantallaFin, YpantallaIni, YpantallaFin);
			Figura3D.GiroX(0);
		}

		private void numGiroX_ValueChanged(object sender, System.EventArgs e) {
			numGiroY.Value = 0;
			numGiroZ.Value = 0;
			int AnguloX = Convert.ToInt32(numGiroX.Value);
			Figura3D.GiroX(AnguloX);
			Refresh();
		}

		private void numGiroY_ValueChanged(object sender, EventArgs e) {
			numGiroX.Value = 0;
			numGiroZ.Value = 0;
			int AnguloY = Convert.ToInt32(numGiroY.Value);
			Figura3D.GiroY(AnguloY);
			Refresh();
		}

		private void numGiroZ_ValueChanged(object sender, EventArgs e) {
			numGiroX.Value = 0;
			numGiroY.Value = 0;
			int AnguloZ = Convert.ToInt32(numGiroZ.Value);
			Figura3D.GiroZ(AnguloZ);
			Refresh();
		}

		//Pinta la proyecci�n
		private void Form1_Paint(object sender, PaintEventArgs e) {
			Graphics Lienzo = e.Graphics;
			Pen Lapiz = new(Color.Blue, 3);
			Figura3D.Dibuja(Lienzo, Lapiz);
		}
	}
}
