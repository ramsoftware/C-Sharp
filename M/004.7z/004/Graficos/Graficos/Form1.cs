﻿using System;
using System.Drawing;
using System.Windows.Forms;

//Proyección 3D a 2D y giros. Figura centrada.
namespace Graficos {
    public partial class Form1 : Form {
        //El cubo que se proyecta y gira
        Cubo Figura3D;

        public Form1() {
            InitializeComponent();

            Figura3D = new Cubo();
            Figura3D.AplicaGiro(0, 0);
        }

        private void numGiroX_ValueChanged(object sender, System.EventArgs e) {
            numGiroY.Value = 0;
            numGiroZ.Value = 0;
            int AnguloX = Convert.ToInt32(numGiroX.Value);
            Figura3D.AplicaGiro(0, AnguloX);
            Refresh();
        }

        private void numGiroY_ValueChanged(object sender, EventArgs e) {
            numGiroX.Value = 0;
            numGiroZ.Value = 0;
            int AnguloY = Convert.ToInt32(numGiroY.Value);
            Figura3D.AplicaGiro(1, AnguloY);
            Refresh();
        }

        private void numGiroZ_ValueChanged(object sender, EventArgs e) {
            numGiroX.Value = 0;
            numGiroY.Value = 0;
            int AnguloZ = Convert.ToInt32(numGiroZ.Value);
            Figura3D.AplicaGiro(2, AnguloZ);
            Refresh();
        }

        //Pinta la proyección
        private void Form1_Paint(object sender, PaintEventArgs e) {
            Graphics Lienzo = e.Graphics;
            Pen Lapiz = new Pen(Color.Black, 2);

            int ZPersona = 180;
            Figura3D.Convierte3Da2D(ZPersona);
            Figura3D.CuadraPantalla(20, 20, 500, 500);
            Figura3D.Dibuja(Lienzo, Lapiz);
        }
    }
}