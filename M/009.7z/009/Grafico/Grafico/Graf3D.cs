﻿namespace Grafico {
    class Graf3D {
        //Arreglo bidimensional que tiene los puntos
        public Punto[][] MtPunto;

        double MinX, MinY, MaxX, MaxY, MinZ, MaxZ;
        double AnguloX, AnguloY, AnguloZ;
        double ZPersona;
        int NumLineas;
        int XpIni, YpIni, XpFin, YpFin;

        //Listado de poligonos
        public List<Poligono> poligonos;

        public void Inicializa() {
            //Valores
            MinX = -10;
            MinY = -10;
            MaxX = 10;
            MaxY = 10;
            NumLineas = 40;

            //Angulos de giro
            AnguloX = 45;
            AnguloY = 45;
            AnguloZ = 45;

            //Distancia de la persona al plano
            ZPersona = 5;

            //Tamaño de la pantalla
            XpIni = 400;
            YpIni = 0;
            XpFin = 1200;
            YpFin = 800;

            //Inicializa polígonos
            poligonos = new List<Poligono>();
        }

        public void setAnguloX(double AnguloX) {
            this.AnguloX = AnguloX;
        }

        public void setAnguloY(double AnguloY) {
            this.AnguloY = AnguloY;
        }

        public void setAnguloZ(double AnguloZ) {
            this.AnguloZ = AnguloZ;
        }

        public void setNumLineas(int NumLineas) {
            this.NumLineas = NumLineas;
        }

        public void Calcula() {
            IniciaMatrizPuntos();
            CalculaXYZ();
            ExtremosZ();
            NormalizaCalculos();
            GiroProyectaCuadra();
        }

        private void IniciaMatrizPuntos() {
            //Arreglo de arreglos
            MtPunto = new Punto[NumLineas][];
            for (int Fila = 0; Fila < MtPunto.Length; Fila++) {
                MtPunto[Fila] = new Punto[NumLineas];
                for (int Columna = 0; Columna < MtPunto[Fila].Length; Columna++) {
                    MtPunto[Fila][Columna] = new Punto();
                }
            }
        }

        private void CalculaXYZ() {
            //Calcula las coordenadas XYZ originales
            double IncrY = (MaxY - MinY) / NumLineas;
            double IncrX = (MaxX - MinX) / NumLineas;
            double X = MinX;
            double Y = MinY;

            for (int Fila = 0; Fila < NumLineas; Fila++) {
                X = MinX;
                for (int Columna = 0; Columna < NumLineas; Columna++) {
                    MtPunto[Fila][Columna].Calcular(X, Y);
                    X += IncrX;
                }
                Y += IncrY;
            }
        }

        private void ExtremosZ() {
            MinZ = double.MaxValue;
            MaxZ = double.MinValue;

            for (int Fila = 0; Fila < NumLineas; Fila++) {
                for (int Columna = 0; Columna < NumLineas; Columna++) {
                    //Los valores extremos de Z
                    if (MtPunto[Fila][Columna].getZ() < MinZ)
                        MinZ = MtPunto[Fila][Columna].getZ();

                    if (MtPunto[Fila][Columna].getZ() > MaxZ)
                        MaxZ = MtPunto[Fila][Columna].getZ();
                }
            }
        }

        private void NormalizaCalculos() {
            for (int Fila = 0; Fila < NumLineas; Fila++)
                for (int Columna = 0; Columna < NumLineas; Columna++)
                    MtPunto[Fila][Columna].Normaliza(MinX, MinY, MinZ, MaxX, MaxY, MaxZ);
        }

        public void GiroProyectaCuadra() {
            //Genera la matriz de rotación
            double CosX = Math.Cos(AnguloX * Math.PI / 180);
            double SinX = Math.Sin(AnguloX * Math.PI / 180);
            double CosY = Math.Cos(AnguloY * Math.PI / 180);
            double SinY = Math.Sin(AnguloY * Math.PI / 180);
            double CosZ = Math.Cos(AnguloZ * Math.PI / 180);
            double SinZ = Math.Sin(AnguloZ * Math.PI / 180);

            //Matriz de Rotación
            //https://en.wikipedia.org/wiki/Rotation_formalisms_in_three_dimensions
            double[,] MtRota = new double[3, 3] {
{CosY*CosZ,-CosX*SinZ+SinX*SinY*CosZ,SinX*SinZ+CosX*SinY*CosZ},
{CosY*SinZ,CosX*CosZ+SinX*SinY*SinZ,-SinX*CosZ+CosX*SinY*SinZ},
{-SinY,SinX*CosY,CosX*CosY}
            };

            for (int Fila = 0; Fila < NumLineas; Fila++)
                for (int Columna = 0; Columna < NumLineas; Columna++) {
                    MtPunto[Fila][Columna].Giro(MtRota);
                    MtPunto[Fila][Columna].Proyecta(ZPersona);
                    MtPunto[Fila][Columna].Pantalla(XpIni, YpIni, XpFin, YpFin);
                }

            //Genera los poligonos
            GeneraPoligonos();

            //Ordena del polígono más alejado al más cercano,
            //de esa manera los polígonos de adelante son
            //visibles y los de atrás son borrados.
            poligonos.Sort();
        }

        private void GeneraPoligonos() {
            poligonos.Clear();
            for (int Fila = 0; Fila < NumLineas - 1; Fila++)
                for (int Columna = 0; Columna < NumLineas - 1; Columna++) {
                    int X1 = MtPunto[Fila][Columna].Xp;
                    int Y1 = MtPunto[Fila][Columna].Yp;
                    double Zg1 = MtPunto[Fila][Columna].getZg();

                    int X2 = MtPunto[Fila][Columna + 1].Xp;
                    int Y2 = MtPunto[Fila][Columna + 1].Yp;
                    double Zg2 = MtPunto[Fila][Columna + 1].getZg();

                    int X3 = MtPunto[Fila + 1][Columna + 1].Xp;
                    int Y3 = MtPunto[Fila + 1][Columna + 1].Yp;
                    double Zg3 = MtPunto[Fila + 1][Columna + 1].getZg();

                    int X4 = MtPunto[Fila + 1][Columna].Xp;
                    int Y4 = MtPunto[Fila + 1][Columna].Yp;
                    double Zg4 = MtPunto[Fila + 1][Columna].getZg();

                    poligonos.Add(new Poligono(X1, Y1, X2, Y2, X3, Y3, X4, Y4, Zg1, Zg2, Zg3, Zg4));
                }
        }
    }
}
