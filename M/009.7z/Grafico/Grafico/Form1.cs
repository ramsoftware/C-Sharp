namespace Grafico {
    public partial class Form1 : Form {
        Graf3D graf3D;

        public Form1() {
            InitializeComponent();
            graf3D = new Graf3D();
            graf3D.Inicializa();
            graf3D.Calcula();
        }

        private void Form1_Paint(object sender, PaintEventArgs e) {
            Graphics Lienzo = e.Graphics;
            Pen Lapiz = new(Color.Black, 1);
            Brush Relleno = new SolidBrush(Color.White);

            for (int Cont = 0; Cont < graf3D.poligonos.Count; Cont++)
                graf3D.poligonos[Cont].Dibuja(Lienzo, Lapiz, Relleno);
        }

        private void numGiroX_ValueChanged(object sender, EventArgs e) {
            graf3D.setAnguloX((double)numGiroX.Value);
            graf3D.GiroProyectaCuadra();
            Refresh();
        }

        private void numGiroY_ValueChanged(object sender, EventArgs e) {
            graf3D.setAnguloY((double)numGiroY.Value);
            graf3D.GiroProyectaCuadra();
            Refresh();
        }

        private void numGiroZ_ValueChanged(object sender, EventArgs e) {
            graf3D.setAnguloZ((double)numGiroZ.Value);
            graf3D.GiroProyectaCuadra();
            Refresh();
        }

        private void numLineas_ValueChanged(object sender, EventArgs e) {
            graf3D.setNumLineas((int)numLineas.Value);
            graf3D.Calcula();
            graf3D.GiroProyectaCuadra();
            Refresh();
        }
    }
}
