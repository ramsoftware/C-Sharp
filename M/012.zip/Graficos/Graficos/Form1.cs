namespace Graficos {
	//Proyecci�n 3D a 2D y giros. Figura centrada. Optimizaci�n.
	public partial class Form1 : Form {
		//La figura que se proyecta y gira
		Objeto3D Figura3D;

		//Giro de figura
		public double AnguloX, AnguloY, AnguloZ;

		//Distancia del observador
		public double ZPersona;

		//Rango de valores
		public double Xini, Yini, Xfin, Yfin;

		//N�mero de l�neas que tendr� el gr�fico
		public int NumLineas;

		//Ecuaci�n
		public string Ecuacion;

		//En caso de que el usuario haya hecho alg�n cambio a los valores
		//se recalcula todo de nuevo.
		public bool HuboCambio;

		public Form1() {
			InitializeComponent();
			Figura3D = new Objeto3D();
		}

		private void Form1_Paint(object sender, PaintEventArgs e) {

			//Dibuja la figura 3D
			if (HuboCambio) {
				Figura3D.CalcularFigura3D(Ecuacion, Xini, Yini, Xfin, Yfin, NumLineas, AnguloX, AnguloY, AnguloZ, ZPersona, 0, 0, this.ClientSize.Width, this.ClientSize.Height);
				HuboCambio = false;
			}

			Figura3D.Dibuja(e.Graphics);
		}

		private void Form1_FormClosing(object sender, FormClosingEventArgs e) {
			Application.Exit();
		}

		private void Form1_Resize(object sender, EventArgs e) {
			HuboCambio = true;
			Refresh();
		}
	}
}
