﻿namespace Graficos {
    partial class Valores {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Valores));
            tabConfigura = new TabControl();
            tabEcuacion = new TabPage();
            btnProcesar = new Button();
            txtEcuacion = new TextBox();
            lblEcuacion = new Label();
            tabXY = new TabPage();
            numMaximoY = new NumericUpDown();
            numMaximoX = new NumericUpDown();
            lblMaximoY = new Label();
            lblMaximoX = new Label();
            numTotalLineas = new NumericUpDown();
            numMinimoY = new NumericUpDown();
            numMinimoX = new NumericUpDown();
            lblTotalLineas = new Label();
            lblMinimoY = new Label();
            lblMinimoX = new Label();
            tabGiros = new TabPage();
            numGiroZ = new NumericUpDown();
            numGiroY = new NumericUpDown();
            numGiroX = new NumericUpDown();
            lblGiroZ = new Label();
            lblGiroY = new Label();
            lblGiroX = new Label();
            tabAyuda = new TabPage();
            txtAyuda = new TextBox();
            tabConfigura.SuspendLayout();
            tabEcuacion.SuspendLayout();
            tabXY.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numMaximoY).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numMaximoX).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numTotalLineas).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numMinimoY).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numMinimoX).BeginInit();
            tabGiros.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numGiroZ).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numGiroY).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numGiroX).BeginInit();
            tabAyuda.SuspendLayout();
            SuspendLayout();
            // 
            // tabConfigura
            // 
            tabConfigura.Appearance = TabAppearance.Buttons;
            tabConfigura.Controls.Add(tabEcuacion);
            tabConfigura.Controls.Add(tabXY);
            tabConfigura.Controls.Add(tabGiros);
            tabConfigura.Controls.Add(tabAyuda);
            tabConfigura.Dock = DockStyle.Fill;
            tabConfigura.Font = new Font("Verdana", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tabConfigura.Location = new Point(0, 0);
            tabConfigura.Margin = new Padding(4, 3, 4, 3);
            tabConfigura.Name = "tabConfigura";
            tabConfigura.SelectedIndex = 0;
            tabConfigura.Size = new Size(1191, 81);
            tabConfigura.TabIndex = 0;
            // 
            // tabEcuacion
            // 
            tabEcuacion.BackColor = Color.LightGreen;
            tabEcuacion.Controls.Add(btnProcesar);
            tabEcuacion.Controls.Add(txtEcuacion);
            tabEcuacion.Controls.Add(lblEcuacion);
            tabEcuacion.Location = new Point(4, 30);
            tabEcuacion.Margin = new Padding(4, 3, 4, 3);
            tabEcuacion.Name = "tabEcuacion";
            tabEcuacion.Padding = new Padding(4, 3, 4, 3);
            tabEcuacion.Size = new Size(1183, 47);
            tabEcuacion.TabIndex = 2;
            tabEcuacion.Text = "Ecuación";
            // 
            // btnProcesar
            // 
            btnProcesar.Location = new Point(1080, 14);
            btnProcesar.Margin = new Padding(4, 3, 4, 3);
            btnProcesar.Name = "btnProcesar";
            btnProcesar.Size = new Size(99, 28);
            btnProcesar.TabIndex = 14;
            btnProcesar.Text = "Procesar";
            btnProcesar.UseVisualStyleBackColor = true;
            btnProcesar.Click += btnProcesar_Click;
            // 
            // txtEcuacion
            // 
            txtEcuacion.Location = new Point(49, 16);
            txtEcuacion.Margin = new Padding(4, 3, 4, 3);
            txtEcuacion.Name = "txtEcuacion";
            txtEcuacion.Size = new Size(1023, 26);
            txtEcuacion.TabIndex = 12;
            txtEcuacion.Text = "sqr(X * X + Y * Y) + 3 * cos(sqr(X * X + Y * Y)) + 5";
            // 
            // lblEcuacion
            // 
            lblEcuacion.AutoSize = true;
            lblEcuacion.Location = new Point(6, 16);
            lblEcuacion.Margin = new Padding(4, 0, 4, 0);
            lblEcuacion.Name = "lblEcuacion";
            lblEcuacion.Size = new Size(35, 18);
            lblEcuacion.TabIndex = 10;
            lblEcuacion.Text = "Z =";
            // 
            // tabXY
            // 
            tabXY.BackColor = Color.PeachPuff;
            tabXY.Controls.Add(numMaximoY);
            tabXY.Controls.Add(numMaximoX);
            tabXY.Controls.Add(lblMaximoY);
            tabXY.Controls.Add(lblMaximoX);
            tabXY.Controls.Add(numTotalLineas);
            tabXY.Controls.Add(numMinimoY);
            tabXY.Controls.Add(numMinimoX);
            tabXY.Controls.Add(lblTotalLineas);
            tabXY.Controls.Add(lblMinimoY);
            tabXY.Controls.Add(lblMinimoX);
            tabXY.Location = new Point(4, 30);
            tabXY.Margin = new Padding(4, 3, 4, 3);
            tabXY.Name = "tabXY";
            tabXY.Padding = new Padding(4, 3, 4, 3);
            tabXY.Size = new Size(1183, 47);
            tabXY.TabIndex = 3;
            tabXY.Text = "Valores X, Y, Líneas";
            // 
            // numMaximoY
            // 
            numMaximoY.Location = new Point(784, 18);
            numMaximoY.Margin = new Padding(4, 3, 4, 3);
            numMaximoY.Maximum = new decimal(new int[] { 2000, 0, 0, 0 });
            numMaximoY.Minimum = new decimal(new int[] { 2000, 0, 0, int.MinValue });
            numMaximoY.Name = "numMaximoY";
            numMaximoY.Size = new Size(90, 26);
            numMaximoY.TabIndex = 21;
            numMaximoY.TextAlign = HorizontalAlignment.Right;
            numMaximoY.Value = new decimal(new int[] { 10, 0, 0, 0 });
            numMaximoY.ValueChanged += numMaximoY_ValueChanged;
            // 
            // numMaximoX
            // 
            numMaximoX.Location = new Point(553, 18);
            numMaximoX.Margin = new Padding(4, 3, 4, 3);
            numMaximoX.Maximum = new decimal(new int[] { 2000, 0, 0, 0 });
            numMaximoX.Minimum = new decimal(new int[] { 2000, 0, 0, int.MinValue });
            numMaximoX.Name = "numMaximoX";
            numMaximoX.Size = new Size(90, 26);
            numMaximoX.TabIndex = 20;
            numMaximoX.TextAlign = HorizontalAlignment.Right;
            numMaximoX.Value = new decimal(new int[] { 10, 0, 0, 0 });
            numMaximoX.ValueChanged += numMaximoX_ValueChanged;
            // 
            // lblMaximoY
            // 
            lblMaximoY.AutoSize = true;
            lblMaximoY.Location = new Point(692, 18);
            lblMaximoY.Margin = new Padding(4, 0, 4, 0);
            lblMaximoY.Name = "lblMaximoY";
            lblMaximoY.Size = new Size(81, 18);
            lblMaximoY.TabIndex = 19;
            lblMaximoY.Text = "Máximo Y";
            // 
            // lblMaximoX
            // 
            lblMaximoX.AutoSize = true;
            lblMaximoX.Location = new Point(460, 18);
            lblMaximoX.Margin = new Padding(4, 0, 4, 0);
            lblMaximoX.Name = "lblMaximoX";
            lblMaximoX.Size = new Size(82, 18);
            lblMaximoX.TabIndex = 18;
            lblMaximoX.Text = "Máximo X";
            // 
            // numTotalLineas
            // 
            numTotalLineas.Location = new Point(1046, 18);
            numTotalLineas.Margin = new Padding(4, 3, 4, 3);
            numTotalLineas.Maximum = new decimal(new int[] { 70, 0, 0, 0 });
            numTotalLineas.Minimum = new decimal(new int[] { 15, 0, 0, 0 });
            numTotalLineas.Name = "numTotalLineas";
            numTotalLineas.Size = new Size(90, 26);
            numTotalLineas.TabIndex = 17;
            numTotalLineas.TextAlign = HorizontalAlignment.Right;
            numTotalLineas.Value = new decimal(new int[] { 50, 0, 0, 0 });
            numTotalLineas.ValueChanged += numTotalLineas_ValueChanged;
            // 
            // numMinimoY
            // 
            numMinimoY.Location = new Point(321, 18);
            numMinimoY.Margin = new Padding(4, 3, 4, 3);
            numMinimoY.Maximum = new decimal(new int[] { 2000, 0, 0, 0 });
            numMinimoY.Minimum = new decimal(new int[] { 2000, 0, 0, int.MinValue });
            numMinimoY.Name = "numMinimoY";
            numMinimoY.Size = new Size(90, 26);
            numMinimoY.TabIndex = 16;
            numMinimoY.TextAlign = HorizontalAlignment.Right;
            numMinimoY.Value = new decimal(new int[] { 10, 0, 0, int.MinValue });
            numMinimoY.ValueChanged += numMinimoY_ValueChanged;
            // 
            // numMinimoX
            // 
            numMinimoX.Location = new Point(96, 18);
            numMinimoX.Margin = new Padding(4, 3, 4, 3);
            numMinimoX.Maximum = new decimal(new int[] { 2000, 0, 0, 0 });
            numMinimoX.Minimum = new decimal(new int[] { 2000, 0, 0, int.MinValue });
            numMinimoX.Name = "numMinimoX";
            numMinimoX.Size = new Size(90, 26);
            numMinimoX.TabIndex = 15;
            numMinimoX.TextAlign = HorizontalAlignment.Right;
            numMinimoX.Value = new decimal(new int[] { 10, 0, 0, int.MinValue });
            numMinimoX.ValueChanged += numMinimoX_ValueChanged;
            // 
            // lblTotalLineas
            // 
            lblTotalLineas.AutoSize = true;
            lblTotalLineas.Location = new Point(923, 18);
            lblTotalLineas.Margin = new Padding(4, 0, 4, 0);
            lblTotalLineas.Name = "lblTotalLineas";
            lblTotalLineas.Size = new Size(112, 18);
            lblTotalLineas.TabIndex = 14;
            lblTotalLineas.Text = "Total de líneas";
            // 
            // lblMinimoY
            // 
            lblMinimoY.AutoSize = true;
            lblMinimoY.Location = new Point(235, 18);
            lblMinimoY.Margin = new Padding(4, 0, 4, 0);
            lblMinimoY.Name = "lblMinimoY";
            lblMinimoY.Size = new Size(75, 18);
            lblMinimoY.TabIndex = 13;
            lblMinimoY.Text = "Mínimo Y";
            // 
            // lblMinimoX
            // 
            lblMinimoX.AutoSize = true;
            lblMinimoX.Location = new Point(9, 18);
            lblMinimoX.Margin = new Padding(4, 0, 4, 0);
            lblMinimoX.Name = "lblMinimoX";
            lblMinimoX.Size = new Size(76, 18);
            lblMinimoX.TabIndex = 12;
            lblMinimoX.Text = "Mínimo X";
            // 
            // tabGiros
            // 
            tabGiros.BackColor = Color.PaleGoldenrod;
            tabGiros.Controls.Add(numGiroZ);
            tabGiros.Controls.Add(numGiroY);
            tabGiros.Controls.Add(numGiroX);
            tabGiros.Controls.Add(lblGiroZ);
            tabGiros.Controls.Add(lblGiroY);
            tabGiros.Controls.Add(lblGiroX);
            tabGiros.Location = new Point(4, 30);
            tabGiros.Margin = new Padding(4, 3, 4, 3);
            tabGiros.Name = "tabGiros";
            tabGiros.Padding = new Padding(4, 3, 4, 3);
            tabGiros.Size = new Size(1183, 47);
            tabGiros.TabIndex = 0;
            tabGiros.Text = "Giros";
            // 
            // numGiroZ
            // 
            numGiroZ.Location = new Point(698, 14);
            numGiroZ.Margin = new Padding(4, 3, 4, 3);
            numGiroZ.Maximum = new decimal(new int[] { 360, 0, 0, 0 });
            numGiroZ.Name = "numGiroZ";
            numGiroZ.Size = new Size(90, 26);
            numGiroZ.TabIndex = 11;
            numGiroZ.TextAlign = HorizontalAlignment.Right;
            numGiroZ.Value = new decimal(new int[] { 45, 0, 0, 0 });
            numGiroZ.ValueChanged += numGiroZ_ValueChanged;
            // 
            // numGiroY
            // 
            numGiroY.Location = new Point(405, 14);
            numGiroY.Margin = new Padding(4, 3, 4, 3);
            numGiroY.Maximum = new decimal(new int[] { 360, 0, 0, 0 });
            numGiroY.Name = "numGiroY";
            numGiroY.Size = new Size(90, 26);
            numGiroY.TabIndex = 10;
            numGiroY.TextAlign = HorizontalAlignment.Right;
            numGiroY.Value = new decimal(new int[] { 45, 0, 0, 0 });
            numGiroY.ValueChanged += numGiroY_ValueChanged;
            // 
            // numGiroX
            // 
            numGiroX.Location = new Point(114, 14);
            numGiroX.Margin = new Padding(4, 3, 4, 3);
            numGiroX.Maximum = new decimal(new int[] { 360, 0, 0, 0 });
            numGiroX.Name = "numGiroX";
            numGiroX.Size = new Size(90, 26);
            numGiroX.TabIndex = 9;
            numGiroX.TextAlign = HorizontalAlignment.Right;
            numGiroX.Value = new decimal(new int[] { 45, 0, 0, 0 });
            numGiroX.ValueChanged += numGiroX_ValueChanged;
            // 
            // lblGiroZ
            // 
            lblGiroZ.AutoSize = true;
            lblGiroZ.Location = new Point(613, 14);
            lblGiroZ.Margin = new Padding(4, 0, 4, 0);
            lblGiroZ.Name = "lblGiroZ";
            lblGiroZ.Size = new Size(77, 18);
            lblGiroZ.TabIndex = 8;
            lblGiroZ.Text = "Giro en Z";
            // 
            // lblGiroY
            // 
            lblGiroY.AutoSize = true;
            lblGiroY.Location = new Point(321, 14);
            lblGiroY.Margin = new Padding(4, 0, 4, 0);
            lblGiroY.Name = "lblGiroY";
            lblGiroY.Size = new Size(76, 18);
            lblGiroY.TabIndex = 7;
            lblGiroY.Text = "Giro en Y";
            // 
            // lblGiroX
            // 
            lblGiroX.AutoSize = true;
            lblGiroX.Location = new Point(29, 14);
            lblGiroX.Margin = new Padding(4, 0, 4, 0);
            lblGiroX.Name = "lblGiroX";
            lblGiroX.Size = new Size(77, 18);
            lblGiroX.TabIndex = 6;
            lblGiroX.Text = "Giro en X";
            // 
            // tabAyuda
            // 
            tabAyuda.Controls.Add(txtAyuda);
            tabAyuda.Location = new Point(4, 30);
            tabAyuda.Name = "tabAyuda";
            tabAyuda.Padding = new Padding(3);
            tabAyuda.Size = new Size(1183, 47);
            tabAyuda.TabIndex = 4;
            tabAyuda.Text = "Ayuda";
            tabAyuda.UseVisualStyleBackColor = true;
            // 
            // txtAyuda
            // 
            txtAyuda.Dock = DockStyle.Fill;
            txtAyuda.Font = new Font("Verdana", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtAyuda.Location = new Point(3, 3);
            txtAyuda.Multiline = true;
            txtAyuda.Name = "txtAyuda";
            txtAyuda.ReadOnly = true;
            txtAyuda.Size = new Size(1177, 41);
            txtAyuda.TabIndex = 0;
            txtAyuda.Text = resources.GetString("txtAyuda.Text");
            // 
            // Valores
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(1191, 81);
            Controls.Add(tabConfigura);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Margin = new Padding(4, 3, 4, 3);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Valores";
            Text = "Configuración del gráfico";
            tabConfigura.ResumeLayout(false);
            tabEcuacion.ResumeLayout(false);
            tabEcuacion.PerformLayout();
            tabXY.ResumeLayout(false);
            tabXY.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numMaximoY).EndInit();
            ((System.ComponentModel.ISupportInitialize)numMaximoX).EndInit();
            ((System.ComponentModel.ISupportInitialize)numTotalLineas).EndInit();
            ((System.ComponentModel.ISupportInitialize)numMinimoY).EndInit();
            ((System.ComponentModel.ISupportInitialize)numMinimoX).EndInit();
            tabGiros.ResumeLayout(false);
            tabGiros.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numGiroZ).EndInit();
            ((System.ComponentModel.ISupportInitialize)numGiroY).EndInit();
            ((System.ComponentModel.ISupportInitialize)numGiroX).EndInit();
            tabAyuda.ResumeLayout(false);
            tabAyuda.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabConfigura;
        private TabPage tabGiros;
        private TabPage tabEcuacion;
        private TabPage tabXY;
        private NumericUpDown numGiroZ;
        private NumericUpDown numGiroY;
        private NumericUpDown numGiroX;
        private Label lblGiroZ;
        private Label lblGiroY;
        private Label lblGiroX;
        private Button btnProcesar;
        private TextBox txtEcuacion;
        private Label lblEcuacion;
        private NumericUpDown numMaximoY;
        private NumericUpDown numMaximoX;
        private Label lblMaximoY;
        private Label lblMaximoX;
        private NumericUpDown numTotalLineas;
        private NumericUpDown numMinimoY;
        private NumericUpDown numMinimoX;
        private Label lblTotalLineas;
        private Label lblMinimoY;
        private Label lblMinimoX;
        private TabPage tabAyuda;
        private TextBox txtAyuda;
    }
}