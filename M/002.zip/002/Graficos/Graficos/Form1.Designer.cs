﻿namespace Graficos
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            lblGiroX = new Label();
            lblGiroY = new Label();
            lblGiroZ = new Label();
            numGiroX = new NumericUpDown();
            numGiroY = new NumericUpDown();
            numGiroZ = new NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)numGiroX).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numGiroY).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numGiroZ).BeginInit();
            SuspendLayout();
            // 
            // lblGiroX
            // 
            lblGiroX.AutoSize = true;
            lblGiroX.Location = new Point(501, 19);
            lblGiroX.Name = "lblGiroX";
            lblGiroX.Size = new Size(67, 16);
            lblGiroX.TabIndex = 0;
            lblGiroX.Text = "Giro en X";
            // 
            // lblGiroY
            // 
            lblGiroY.AutoSize = true;
            lblGiroY.Location = new Point(501, 63);
            lblGiroY.Name = "lblGiroY";
            lblGiroY.Size = new Size(67, 16);
            lblGiroY.TabIndex = 1;
            lblGiroY.Text = "Giro en Y";
            // 
            // lblGiroZ
            // 
            lblGiroZ.AutoSize = true;
            lblGiroZ.Location = new Point(501, 110);
            lblGiroZ.Name = "lblGiroZ";
            lblGiroZ.Size = new Size(67, 16);
            lblGiroZ.TabIndex = 2;
            lblGiroZ.Text = "Giro en Z";
            // 
            // numGiroX
            // 
            numGiroX.Location = new Point(574, 19);
            numGiroX.Maximum = new decimal(new int[] { 360, 0, 0, 0 });
            numGiroX.Name = "numGiroX";
            numGiroX.Size = new Size(98, 23);
            numGiroX.TabIndex = 3;
            numGiroX.TextAlign = HorizontalAlignment.Right;
            numGiroX.ValueChanged += numGiroX_ValueChanged;
            // 
            // numGiroY
            // 
            numGiroY.Location = new Point(574, 65);
            numGiroY.Maximum = new decimal(new int[] { 360, 0, 0, 0 });
            numGiroY.Name = "numGiroY";
            numGiroY.Size = new Size(98, 23);
            numGiroY.TabIndex = 4;
            numGiroY.TextAlign = HorizontalAlignment.Right;
            numGiroY.ValueChanged += numGiroY_ValueChanged;
            // 
            // numGiroZ
            // 
            numGiroZ.Location = new Point(574, 103);
            numGiroZ.Maximum = new decimal(new int[] { 360, 0, 0, 0 });
            numGiroZ.Name = "numGiroZ";
            numGiroZ.Size = new Size(98, 23);
            numGiroZ.TabIndex = 5;
            numGiroZ.TextAlign = HorizontalAlignment.Right;
            numGiroZ.ValueChanged += numGiroZ_ValueChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 16F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(686, 503);
            Controls.Add(numGiroZ);
            Controls.Add(numGiroY);
            Controls.Add(numGiroX);
            Controls.Add(lblGiroZ);
            Controls.Add(lblGiroY);
            Controls.Add(lblGiroX);
            DoubleBuffered = true;
            Font = new Font("Verdana", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Name = "Form1";
            Text = "Proyección 3D a 2D. Implementación de giros en forma independiente.";
            Paint += Form1_Paint;
            ((System.ComponentModel.ISupportInitialize)numGiroX).EndInit();
            ((System.ComponentModel.ISupportInitialize)numGiroY).EndInit();
            ((System.ComponentModel.ISupportInitialize)numGiroZ).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblGiroX;
        private Label lblGiroY;
        private Label lblGiroZ;
        private NumericUpDown numGiroX;
        private NumericUpDown numGiroY;
        private NumericUpDown numGiroZ;
    }
}
