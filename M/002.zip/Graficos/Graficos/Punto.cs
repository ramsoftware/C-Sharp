﻿namespace Graficos {
	//Cada punto espacial es almacenado y convertido
	internal class Punto {
		private double X, Y, Z; //Coordenadas originales
		private double Xg, Yg, Zg; //Coordenadas al girar
		public int PlanoX, PlanoY; //Proyección o sombra

		public Punto(double X, double Y, double Z) {
			this.X = X;
			this.Y = Y;
			this.Z = Z;
		}

		//Convierte de 3D a 2D (segunda dimensión)
		public void Proyecta(double ZPersona) {
			PlanoX = Convert.ToInt32(Xg * ZPersona / (ZPersona - Zg));
			PlanoY = Convert.ToInt32(Yg * ZPersona / (ZPersona - Zg));
		}

		//Gira en X
		public void GiroX(double angulo) {
			double[,] Mt = new double[3, 3] {
				{1, 0, 0},
				{0, Math.Cos(angulo), Math.Sin(angulo)},
				{0, -Math.Sin(angulo), Math.Cos(angulo) }
			};

			Xg = X * Mt[0, 0] + Y * Mt[1, 0] + Z * Mt[2, 0];
			Yg = X * Mt[0, 1] + Y * Mt[1, 1] + Z * Mt[2, 1];
			Zg = X * Mt[0, 2] + Y * Mt[1, 2] + Z * Mt[2, 2];
		}

		//Gira en Y
		public void GiroY(double angulo) {
			double[,] Mt = new double[3, 3] {
				{Math.Cos(angulo), 0, -Math.Sin(angulo)},
				{0, 1, 0},
				{Math.Sin(angulo), 0, Math.Cos(angulo) }
			};

			Xg = X * Mt[0, 0] + Y * Mt[1, 0] + Z * Mt[2, 0];
			Yg = X * Mt[0, 1] + Y * Mt[1, 1] + Z * Mt[2, 1];
			Zg = X * Mt[0, 2] + Y * Mt[1, 2] + Z * Mt[2, 2];
		}

		//Gira en Z
		public void GiroZ(double angulo) {
			double[,] Mt = new double[3, 3] {
				{Math.Cos(angulo), Math.Sin(angulo), 0},
				{-Math.Sin(angulo), Math.Cos(angulo), 0},
				{0, 0, 1 }
			};

			Xg = X * Mt[0, 0] + Y * Mt[1, 0] + Z * Mt[2, 0];
			Yg = X * Mt[0, 1] + Y * Mt[1, 1] + Z * Mt[2, 1];
			Zg = X * Mt[0, 2] + Y * Mt[1, 2] + Z * Mt[2, 2];
		}
	}
}
