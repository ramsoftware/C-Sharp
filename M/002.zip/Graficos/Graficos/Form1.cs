namespace Graficos {
	//Proyecci�n 3D a 2D. Uso de giros en X, Y, Z pero tan s�lo en uno

	public partial class Form1 : Form {
		//El cubo que se proyecta y gira
		Cubo Figura3D;
		int ZPersona = 180;

		public Form1() {
			InitializeComponent();

			Figura3D = new Cubo();
			Figura3D.AplicaGiro(0, 0, ZPersona);
		}

		private void numGiroX_ValueChanged(object sender, System.EventArgs e) {
			//Se anulan los dos valores de los otros �ngulos
			numGiroY.Value = 0;
			numGiroZ.Value = 0;

			//S�lo puede girar en un �ngulo
			int AnguloX = Convert.ToInt32(numGiroX.Value);
			Figura3D.AplicaGiro(0, AnguloX, ZPersona); //O es giro en X
			Refresh();
		}

		private void numGiroY_ValueChanged(object sender, EventArgs e) {
			numGiroX.Value = 0;
			numGiroZ.Value = 0;
			int AnguloY = Convert.ToInt32(numGiroY.Value);
			Figura3D.AplicaGiro(1, AnguloY, ZPersona); //1 es giro en Y
			Refresh();
		}

		private void numGiroZ_ValueChanged(object sender, EventArgs e) {
			numGiroX.Value = 0;
			numGiroY.Value = 0;
			int AnguloZ = Convert.ToInt32(numGiroZ.Value);
			Figura3D.AplicaGiro(2, AnguloZ, ZPersona); //2 es giro en Z
			Refresh();
		}

		//Pinta la proyecci�n
		private void Form1_Paint(object sender, PaintEventArgs e) {
			Graphics Lienzo = e.Graphics;
			Pen Lapiz = new(Color.Blue, 3);
			Figura3D.Dibuja(Lienzo, Lapiz);

			//Dibuja la l�nea de referencia del giro que parte de 0,0
			Pen Lapiz2 = new(Color.Red, 3);
			Lienzo.DrawLine(Lapiz2, 0, 0, Figura3D.puntos[0].PlanoX, Figura3D.puntos[0].PlanoY);
		}
	}
}
