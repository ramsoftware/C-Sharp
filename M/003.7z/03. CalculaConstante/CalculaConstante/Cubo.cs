﻿using System;
using System.Collections.Generic;

namespace CalculaConstante {
    internal class Cubo {
        //Un cubo tiene 8 coordenadas espaciales X, Y, Z
        private List<double> Coordenadas;

        //Un cubo tiene 8 coordenadas espaciales X, Y, Z que han sido giradas
        private List<double> Giradas;

        //Luego tiene 8 coordenadas planas
        private List<double> PlanoX;
        private List<double> PlanoY;

        //Constructor
        public Cubo() {
            //Ejemplo de coordenadas espaciales X,Y,Z
            Coordenadas = new List<double>() {
            -0.5, -0.5, -0.5,
            0.5, -0.5, -0.5,
            0.5, 0.5, -0.5,
            -0.5, 0.5, -0.5,
            -0.5, -0.5, 0.5,
            0.5, -0.5, 0.5,
            0.5, 0.5, 0.5,
            -0.5, 0.5, 0.5 };

            Giradas = new List<double>();
            PlanoX = new List<double>();
            PlanoY = new List<double>();
        }

        //Gira en X
        private void GiroX(double angulo) {
            double ang = angulo * Math.PI / 180;

            double[,] Matriz = new double[3, 3] {
                {1, 0, 0},
                {0, Math.Cos(ang), Math.Sin(ang)},
                {0, -Math.Sin(ang), Math.Cos(ang) }
            };

            AplicaMatrizGiro(Matriz);
        }

        //Gira en Y
        private void GiroY(double angulo) {
            double ang = angulo * Math.PI / 180;

            double[,] Matriz = new double[3, 3] {
                {Math.Cos(ang), 0, -Math.Sin(ang)},
                {0, 1, 0},
                {Math.Sin(ang), 0, Math.Cos(ang) }
            };

            AplicaMatrizGiro(Matriz);
        }

        //Gira en Z
        private void GiroZ(double angulo) {
            double ang = angulo * Math.PI / 180;

            double[,] Matriz = new double[3, 3] {
                {Math.Cos(ang), Math.Sin(ang), 0},
                {-Math.Sin(ang), Math.Cos(ang), 0},
                {0, 0, 1 }
            };

            AplicaMatrizGiro(Matriz);
        }

        private void AplicaMatrizGiro(double[,] Matriz) {
            Giradas.Clear();

            //Gira las 8 coordenadas
            for (int cont = 0; cont < Coordenadas.Count; cont += 3) {
                //Extrae las coordenadas espaciales
                double X = Coordenadas[cont];
                double Y = Coordenadas[cont + 1];
                double Z = Coordenadas[cont + 2];

                //Hace el giro
                double posXg = X * Matriz[0, 0] + Y * Matriz[1, 0] + Z * Matriz[2, 0];
                double posYg = X * Matriz[0, 1] + Y * Matriz[1, 1] + Z * Matriz[2, 1];
                double posZg = X * Matriz[0, 2] + Y * Matriz[1, 2] + Z * Matriz[2, 2];

                //Guarda en la lista de giro
                Giradas.Add(posXg);
                Giradas.Add(posYg);
                Giradas.Add(posZg);
            }
        }

        //Convierte de 3D a 2D las coordenadas giradas
        private void Convierte3Da2D(int ZPersona) {
            for (int cont = 0; cont < Giradas.Count; cont += 3) {
                //Extrae las coordenadas espaciales
                double X = Giradas[cont];
                double Y = Giradas[cont + 1];
                double Z = Giradas[cont + 2];

                //Convierte a coordenadas planas
                double Xp = ZPersona * X / (ZPersona - Z);
                double Yp = ZPersona * Y / (ZPersona - Z);

                //Agrega las coordenadas planas a la lista
                PlanoX.Add(Xp);
                PlanoY.Add(Yp);
            }
        }

        //Calcula los extremos de las coordenadas del cubo al girar y proyectarse
        public void CalculaExtremo(int ZPersona) {
            double maximoX = double.MinValue;
            double minimoX = double.MaxValue;
            double maximoY = double.MinValue;
            double minimoY = double.MaxValue;

            for (double angX = 0; angX <= 360; angX++) {
                GiroX(angX);
                Convierte3Da2D(ZPersona);
            }

            for (double angY = 0; angY <= 360; angY++) {
                GiroY(angY);
                Convierte3Da2D(ZPersona);
            }

            for (double angZ = 0; angZ <= 360; angZ++) {
                GiroZ(angZ);
                Convierte3Da2D(ZPersona);
            }

            for (int cont = 0; cont < PlanoX.Count; cont++) {
                if (PlanoX[cont] < minimoX) minimoX = PlanoX[cont];
                if (PlanoX[cont] > maximoX) maximoX = PlanoX[cont];
                if (PlanoY[cont] < minimoY) minimoY = PlanoY[cont];
                if (PlanoY[cont] > maximoY) maximoY = PlanoY[cont];
            }

            Console.WriteLine("Extremos son:");
            Console.WriteLine("MinimoX: " + minimoX.ToString());
            Console.WriteLine("MaximoX: " + maximoX.ToString());
            Console.WriteLine("MinimoY: " + minimoY.ToString());
            Console.WriteLine("MaximoY: " + maximoY.ToString());
        }
    }
}
