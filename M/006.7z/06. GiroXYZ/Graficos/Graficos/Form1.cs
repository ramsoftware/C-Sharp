﻿using System;
using System.Drawing;
using System.Windows.Forms;

//Proyección 3D a 2D y giros en los tres ejes simultáneamente
namespace Graficos {
    public partial class Form1 : Form {
        //El cubo que se proyecta y gira
        Cubo Figura3D;

        public Form1() {
            InitializeComponent();

            Figura3D = new Cubo();
            Figura3D.GirarFigura(0, 0, 0);
        }

        private void numGiroX_ValueChanged(object sender, System.EventArgs e) {
            Refresh();
        }

        private void numGiroY_ValueChanged(object sender, EventArgs e) {
            Refresh();
        }

        private void numGiroZ_ValueChanged(object sender, EventArgs e) {
            Refresh();
        }

        //Pinta la proyección del cubo
        private void Form1_Paint(object sender, PaintEventArgs e) {
            Graphics Lienzo = e.Graphics;
            Pen Lapiz = new Pen(Color.Black, 1);

            int AnguloX = Convert.ToInt32(numGiroX.Value);
            int AnguloY = Convert.ToInt32(numGiroY.Value);
            int AnguloZ = Convert.ToInt32(numGiroZ.Value);

            int ZPersona = 5;
            Figura3D.GirarFigura(AnguloX, AnguloY, AnguloZ);
            Figura3D.Convierte3Da2D(ZPersona);
            Figura3D.CuadraPantalla(20, 20, 500, 500);
            Figura3D.Dibuja(Lienzo, Lapiz);
        }
    }
}