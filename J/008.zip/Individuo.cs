﻿/* Algoritmo evolutivo para simplificar ecuaciones
 * Autor: Rafael Alberto Moreno Parra
 * 
 * Problema:
 * Dada una ecuación compleja del tipo
 * Y = a*seno(b*X+c) + ... + p*seno(q*X+r) + ...
 * Con múltiples sumandos
 * 
 * donde X es la variable independiente y
 * Y la variable dependiente, hallar una función
 * que simplifique la ecuación anterior.
 * 
 * Solución:
 * Usar un algoritmo evolutivo para dar con esa
 * función que se acerque al comportamiento de la 
 * función compleja. 
 * ¿Cómo?
 * La ecuación compleja genera una serie de datos, luego
 * se busca la ecuación simple que se acerque a esa serie
 * de datos.
 * */

namespace Ejemplo {
    /* Los individuos son ecuaciones cortas del tipo:
     * Y = a*Seno(b*X+c) + d*Seno(e*X+f) + g*Seno(h*X+i) + .....
     * Cada sumando, por ejemplo, a*Seno(b*X+c) se le conoce como bloque
     * Cuando se crea un individuo, se crean los coeficientes (a, b, c, d, e, f, ..) 
     * al azar entre un valor mínimo y máximo */

    public class Individuo {

        /* Entre más cercano a cero mejor */
        public double Ajuste = -1;

        /* Los coeficientes del individuo. Al principio son al azar. */
        public double[] Coeficientes;

        /* Crea el individuo con coeficientes al azar */
        public Individuo(int Bloques, Random Azar, double MinCoef, double MaxCoef) {
            Coeficientes = new double[Bloques * 3];

            //Usando distribución uniforme se crean los coeficientes
            for (int Cont = 0; Cont < Coeficientes.Length; Cont++) {
                Coeficientes[Cont] = Azar.NextDouble() * (MaxCoef - MinCoef) + MinCoef;
            }
        }

        /* Calcula que tan ajustado está el individuo a los datos de la ecuación compleja */
        public void CalculaAjuste(double[] Xentrada, double[] Yesperado) {
            /* Si ya se había calculado entonces evita el recálculo */
            if (this.Ajuste != -1) return;
            this.Ajuste = 0;
            for (int Valor = 0; Valor < Xentrada.Length; Valor++) {
                double Yindividuo = Ycalculado(Xentrada[Valor]);

                /* Diferencia absoluta entre lo esperado y lo que calcula el individuo */
                this.Ajuste += Math.Abs(Yindividuo - Yesperado[Valor]);
            }
        }

        /* Calcula el Y del individuo dada la entrada */
        public double Ycalculado(double X) {
            double Acumula = 0;
            for (int Cont = 0; Cont < Coeficientes.Length; Cont += 3) {
                Acumula += Coeficientes[Cont] * Math.Sin((Coeficientes[Cont + 1] * X + Coeficientes[Cont + 2]) * Math.PI / 180);
            }
            return Acumula;
        }


        public void ImprimeIndividuo() {
            Console.Write("Y = ");
            for (int Cont = 0; Cont < Coeficientes.Length; Cont += 3) {
                double a = Coeficientes[Cont];
                double b = Coeficientes[Cont + 1];
                double c = Coeficientes[Cont + 2];
                Console.Write(a + " * Seno(" + b + "*X + " + c + ")");
                if (Cont < Coeficientes.Length - 3) Console.Write(" + ");
            }
            Console.WriteLine(" ");
        }
    }
}
