﻿/* Algoritmo evolutivo para simplificar ecuaciones
 * Autor: Rafael Alberto Moreno Parra
 * 
 * Problema:
 * Dada una ecuación compleja del tipo
 * Y = a*seno(b*X+c) + ... + p*seno(q*X+r) + ...
 * Con múltiples sumandos
 * 
 * donde X es la variable independiente y
 * Y la variable dependiente, hallar una función
 * que simplifique la ecuación anterior.
 * 
 * Solución:
 * Usar un algoritmo evolutivo para dar con esa
 * función que se acerque al comportamiento de la 
 * función compleja. 
 * ¿Cómo?
 * La ecuación compleja genera una serie de datos, luego
 * se busca la ecuación simple que se acerque a esa serie
 * de datos.
 * */

namespace Ejemplo {

    internal class DatosGenera {
        //Valores X de entrada
        public double[] Xentrada;

        //Valores Y generados por la ecuación
        public double[] Yesperado;

        //Almacena los coeficientes (generados al azar) de la ecuación compleja que genera los datos
        public double[] Coeficientes;

        /* Genera los datos de la ecuación compleja */
        public void GeneraDataset(Random Azar, int Bloques, double MinCoef, double MaxCoef, double Xmin, double Xmax, int TotalDatos) {
            Coeficientes = new double[Bloques * 3];

            //Usando distribución uniforme se crean los coeficientes
            for (int Cont = 0; Cont < Coeficientes.Length; Cont++) {
                Coeficientes[Cont] = Azar.NextDouble() * (MaxCoef - MinCoef) + MinCoef;
            }

            /* Genera valores X e Y */
            Xentrada = new double[TotalDatos];
            for (int Cont = 0; Cont < TotalDatos; Cont++)
                Xentrada[Cont] = Azar.NextDouble() * (Xmax - Xmin) + Xmin;
            Xentrada.Sort();

            Yesperado = new double[TotalDatos];
            for (int Cont = 0; Cont < TotalDatos; Cont++) {
                Yesperado[Cont] = Ecuacion(Xentrada[Cont]);
            }
        }

        //Una ecuación del tipo Y = a*seno(b*X+c) + ... + p*seno(q*X+r) + ...
        public double Ecuacion(double X) {
            double Acumula = 0;
            for (int Cont = 0; Cont < Coeficientes.Length; Cont += 3) {
                Acumula += Coeficientes[Cont] * Math.Sin((Coeficientes[Cont + 1] * X + Coeficientes[Cont + 2]) * Math.PI / 180);
            }
            return Acumula;
        }

        public void ImprimeEcuacion() {
            Console.Write("Ecuación generadora: Y = ");
            for (int Cont = 0; Cont < Coeficientes.Length; Cont += 3) {
                double a = Coeficientes[Cont];
                double b = Coeficientes[Cont + 1];
                double c = Coeficientes[Cont + 2];
                Console.Write(a + " * Seno(" + b + "*X + " + c + ")");
                if (Cont < Coeficientes.Length - 3) Console.Write(" + ");
            }
            Console.WriteLine(" ");
        }

        public void ImprimeDatosGenerados() {
            Console.WriteLine("Datos generados");
            for (int Cont = 0; Cont < Xentrada.Length; Cont++) {
                Console.WriteLine(Xentrada[Cont] + ";" + Yesperado[Cont]);
            }
        }
    }
}
