﻿/* Algoritmo evolutivo para simplificar ecuaciones
 * Autor: Rafael Alberto Moreno Parra
 * 
 * Problema:
 * Dada una ecuación compleja del tipo
 * Y = a*seno(b*X+c) + ... + p*seno(q*X+r) + ...
 * Con múltiples sumandos
 * 
 * donde X es la variable independiente y
 * Y la variable dependiente, hallar una función
 * que simplifique la ecuación anterior.
 * 
 * Solución:
 * Usar un algoritmo evolutivo para dar con esa
 * función que se acerque al comportamiento de la 
 * función compleja. 
 * ¿Cómo?
 * La ecuación compleja genera una serie de datos, luego
 * se busca la ecuación simple que se acerque a esa serie
 * de datos.
 * */
namespace Ejemplo;

internal class Program {

    static void Main() {
        /* Único generador de números aleatorios para todo el programa */
        Random Azar = new();

        /* Genera el dataset de la ecuación compleja */
        int BloquesDataset = 30; // Cuántos bloques tendrá la ecuación compleja
        double MinCoef = -3;
        double MaxCoef = 3;
        double Xmin = -720;
        double Xmax = 720;
        int TotalDatos = 100;
        DatosGenera objDatos = new();
        objDatos.GeneraDataset(Azar, BloquesDataset, MinCoef, MaxCoef, Xmin, Xmax, TotalDatos);

        /* Buscar la ecuación más simple */
        int Poblacion = 200; //Cuántos individuos tendrá la población al inicio
        int Ciclos = 4000000; //Cuántas veces se ejecutará el ciclo de: seleccionar dos individuos, reproducir y mutar
        int Bloques = 7; //Cuántos bloques tendrán los individuos para simplificar la ecuación compleja 

        /* Genera población inicial con coeficientes aleatorios */
        Individuo[] Individuos = new Individuo[Poblacion];
        Individuo Hijo = new(Bloques, Azar, MinCoef, MaxCoef);

        for (int indiv = 0; indiv < Poblacion; indiv++) {
            Individuos[indiv] = new Individuo(Bloques, Azar, MinCoef, MaxCoef);
        }

        double MejorAjuste = double.MaxValue;
        int MejorIndividuo = -1;
        int numCoef = Bloques * 3;

        for (int ciclo = 1; ciclo <= Ciclos; ciclo++) {

            /* Seleccionar dos inviduos aleatoriamente */
            int Uno = Azar.Next(Poblacion);
            int Dos;
            do {
                Dos = Azar.Next(Poblacion);
            } while (Dos == Uno);

            Individuos[Uno].CalculaAjuste(objDatos.Xentrada, objDatos.Yesperado);
            Individuos[Dos].CalculaAjuste(objDatos.Xentrada, objDatos.Yesperado);

            /* Evalúa cada individuo */

            if (Individuos[Uno].Ajuste < MejorAjuste) {
                MejorAjuste = Individuos[Uno].Ajuste;
                MejorIndividuo = Uno;
            }

            if (Individuos[Dos].Ajuste < MejorAjuste) {
                MejorAjuste = Individuos[Dos].Ajuste;
                MejorIndividuo = Dos;
            }

            /* Genera un hijo con operador cruce (se cruzan los coeficientes) */
            var coef1 = Individuos[Uno].Coeficientes;
            var coef2 = Individuos[Dos].Coeficientes;
            var coefHijo = Hijo.Coeficientes;

            int puntoCruce = Azar.Next(numCoef);
            Array.Copy(coef1, 0, coefHijo, 0, puntoCruce + 1);
            Array.Copy(coef2, puntoCruce + 1, coefHijo, puntoCruce + 1, numCoef - (puntoCruce + 1));

            /* Muta el hijo */
            int PuntoMutacion = Azar.Next(numCoef);
            coefHijo[PuntoMutacion] += Azar.NextDouble() * 2 - 1;

            /* Evalúa el hijo */
            Hijo.Ajuste = -1;
            Hijo.CalculaAjuste(objDatos.Xentrada, objDatos.Yesperado);

            /* Si el hijo es mejor que algún progenitor, entonces se sobre-escribe el progenitor */
            if (Hijo.Ajuste < Individuos[Uno].Ajuste) {
                Array.Copy(coefHijo, coef1, coefHijo.Length);
                Individuos[Uno].Ajuste = Hijo.Ajuste;
            }
            /* Pero no los dos a la vez */
            else if (Hijo.Ajuste < Individuos[Dos].Ajuste) {
                Array.Copy(coefHijo, coef2, coefHijo.Length);
                Individuos[Dos].Ajuste = Hijo.Ajuste;
            }

            /* Informar cada 100000 intentos */
            if (ciclo % 100000 == 0) {
                Console.WriteLine($"Intento: {ciclo:N0} Mejor individuo: [{MejorIndividuo}] con Valor: [{Individuos[MejorIndividuo].Ajuste}]");
            }
        }

        /* Datos originales generados */
        Console.WriteLine("\r\nConfiguración dataset original");
        Console.WriteLine("Número de bloques originales: " + BloquesDataset);
        Console.WriteLine("Valor mínimo de los coeficientes: " + MinCoef);
        Console.WriteLine("Valor máximo de los coeficientes: " + MaxCoef);
        Console.WriteLine("X mínimo: " + Xmin);
        Console.WriteLine("X máximo: " + Xmax);
        Console.WriteLine("Total datos generados: " + TotalDatos);
        objDatos.ImprimeEcuacion();

        /* Individuos */
        Console.WriteLine("\r\nConfiguración población");
        Console.WriteLine("Total individuos: " + Poblacion);
        Console.WriteLine("Número de ciclos: " + Ciclos);
        Console.WriteLine("Número de bloques de cada individuo: " + Bloques);

        /* Mejor Individuo */
        Console.WriteLine("\r\nMejor Ajuste: " + Individuos[MejorIndividuo].Ajuste);
        Console.Write("Mejor ecuación cercana: ");
        Individuos[MejorIndividuo].ImprimeIndividuo();

        /* Imprime los datos generados y lo que hizo el mejor individuo */
        Console.WriteLine("\r\nDatos generados y lo que hizo el mejor individuo");
        for (int Cont = 0; Cont < objDatos.Xentrada.Length; Cont++) {
            double Yindividuo = Individuos[MejorIndividuo].Ycalculado(objDatos.Xentrada[Cont]);
            Console.WriteLine(objDatos.Xentrada[Cont] + ";" + objDatos.Yesperado[Cont] + ";" + Yindividuo);
        }
    }
}
