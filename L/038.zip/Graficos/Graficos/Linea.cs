﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Graficos {
    internal class Linea {
        //Valor X, Y reales de la ecuación para dibujar la línea
        public double Xa, Ya;
        public double Xb, Yb;

        //Puntos convertidos a coordenadas enteras de pantalla
        public int pantXa, pantYa;
        public int pantXb, pantYb;

        public Linea(double Xa, double Ya, double Xb, double Yb) {
            this.Xa = Xa;
            this.Ya = Ya;
            this.Xb = Xb;
            this.Yb = Yb;
        }

        //Convierte las coordenadas reales a coordenadas en pantalla
        public void Convierte(double convierteX, double convierteY, double Xmin, double Ymin, int XpantallaIni, int YpantallaIni) {
            pantXa = Convert.ToInt32(convierteX * (Xa - Xmin) + XpantallaIni);
            pantXb = Convert.ToInt32(convierteX * (Xb - Xmin) + XpantallaIni);
            pantYa = Convert.ToInt32(convierteY * (Ya - Ymin) + YpantallaIni);
            pantYb = Convert.ToInt32(convierteY * (Yb - Ymin) + YpantallaIni);
        }
    }
}
