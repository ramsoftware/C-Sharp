﻿namespace Graficos {
    internal class Punto {
        //Valor X, Y reales de la ecuación
        public double X, Y;

        //Puntos convertidos a coordenadas enteras de pantalla
        public int pantX, pantY;

        public Punto(double X, double Y) {
            this.X = X;
            this.Y = Y;
        }
    }
}
