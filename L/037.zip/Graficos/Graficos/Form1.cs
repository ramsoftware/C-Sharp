namespace Graficos
{
    public partial class Form1 : Form {
        List<Linea> Lineas;
        List<Linea> Ejes;
        int XpantallaIni, YpantallaIni, XpantallaFin, YpantallaFin;

        public Form1() {
            InitializeComponent();
            Lineas = [];
            Ejes = [];

            //�rea d�nde se dibujar� el gr�fico matem�tico
            XpantallaIni = 20;
            YpantallaIni = 40;
            XpantallaFin = 600;
            YpantallaFin = 550;

            //Algoritmo que calcula los puntos del gr�fico
            double Xini = -100;
            double Xfin = 750;
            double Xavance = 0.01;
            Logica(Xini, Xfin, Xavance);
        }

        public void Logica(double Xini, double Xfin, double Xavance) {

            Lineas.Clear();
            Ejes.Clear();

            //Calcula las l�neas que tendr� el gr�fico
            double valXa = Xini;
            double valYa = -Ecuacion(valXa);
            while (valXa < Xfin) {
                double valXb = Math.Round(valXa + Xavance, 5);
                double valYb = -Ecuacion(valXb);

                //Si la l�nea es v�lida, se agrega a la lista
                if (double.IsFinite(valYa) && double.IsFinite(valYb)) {
                    Lineas.Add(new Linea(valXa, valYa, valXb, valYb));
                }

                valXa = valXb;
                valYa = valYb;
            }

            //Determina los valores m�ximos y m�nimos en X y Y que tienen las l�neas
            double Xmin = double.MaxValue;
            double Xmax = double.MinValue;
            double Ymin = double.MaxValue;
            double Ymax = double.MinValue;
            foreach (var linea in Lineas) {
                Xmin = Math.Min(Xmin, Math.Min(linea.Xa, linea.Xb));
                Xmax = Math.Max(Xmax, Math.Max(linea.Xa, linea.Xb));
                Ymin = Math.Min(Ymin, Math.Min(linea.Ya, linea.Yb));
                Ymax = Math.Max(Ymax, Math.Max(linea.Ya, linea.Yb));
            }

            //Extremos para poder dibujar los ejes
            Xmin = Math.Min(Xmin, Xini);
            Xmax = Math.Max(Xmax, Xfin);
            Ymin = Math.Min(Ymin, 0);
            Ymax = Math.Max(Ymax, 0);

            //Ejes
            Ejes.Add(new Linea(Xmin, 0, Xmax, 0)); //Eje X
            Ejes.Add(new Linea(0, Ymin, 0, Ymax)); //Eje Y

            //Calcula los puntos a poner en la pantalla
            double convierteX = (XpantallaFin - XpantallaIni) / (Xmax - Xmin);
            double convierteY = (YpantallaFin - YpantallaIni) / (Ymax - Ymin);

            for (int Cont = 0; Cont < Lineas.Count; Cont++) {
                Lineas[Cont].Convierte(convierteX, convierteY, Xmin, Ymin, XpantallaIni, YpantallaIni);
            }

            //Calcula donde poner los ejes
            Ejes[0].Convierte(convierteX, convierteY, Xmin, Ymin, XpantallaIni, YpantallaIni);
            Ejes[1].Convierte(convierteX, convierteY, Xmin, Ymin, XpantallaIni, YpantallaIni);
        }

        //Aqu� est� la ecuaci�n que se desee graficar con variable independiente X
        public double Ecuacion(double X) {
            //return Math.Sqrt(Math.Cos(X*Math.PI/180));
            //return Math.Sqrt(X);
            //return (X * X - 1) / (X - 1);
            return Math.Sin(X * Math.PI / 180);
        }

        //Pinta la ecuaci�n
        private void Form1_Paint(object sender, PaintEventArgs e) {
            Graphics Lienzo = e.Graphics;
            Pen LapizGrafica = new(Color.Blue, 2);
            Pen LapizPerimetro = new(Color.White, 2);
            Pen LapizEje = new(Color.Red, 2);
            Brush Relleno = new SolidBrush(Color.White);

            //Un recuadro para ver el �rea del gr�fico
            Lienzo.DrawRectangle(LapizPerimetro, XpantallaIni, YpantallaIni,
                XpantallaFin - XpantallaIni, YpantallaFin - YpantallaIni);

            Lienzo.FillRectangle(Relleno, XpantallaIni, YpantallaIni,
                XpantallaFin - XpantallaIni, YpantallaFin - YpantallaIni);

            //Dibuja el gr�fico matem�tico
            for (int Cont = 0; Cont < Lineas.Count; Cont++) {
                Lienzo.DrawLine(LapizGrafica, Lineas[Cont].pantXa, Lineas[Cont].pantYa,
                    Lineas[Cont].pantXb, Lineas[Cont].pantYb);
            }

            //Dibuja los ejes
            Lienzo.DrawLine(LapizEje, Ejes[0].pantXa, Ejes[0].pantYa,
                    Ejes[0].pantXb, Ejes[0].pantYb);
            Lienzo.DrawLine(LapizEje, Ejes[1].pantXa, Ejes[1].pantYa,
                    Ejes[1].pantXb, Ejes[1].pantYb);
        }
    }
}
