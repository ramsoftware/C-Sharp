namespace Graficos {
    public partial class Form1 : Form {
        List<Punto> Puntos;
        int XpantallaIni, YpantallaIni, XpantallaFin, YpantallaFin;

        public Form1() {
            InitializeComponent();
            Puntos = [];

            //�rea d�nde se dibujar� el gr�fico matem�tico
            XpantallaIni = 20;
            YpantallaIni = 40;
            XpantallaFin = 600;
            YpantallaFin = 550;

            //Algoritmo que calcula los puntos del gr�fico
            double Xini = -8;
            double Xfin = 5;
            double Xavance = 0.02;
            Logica(Xini, Xfin, Xavance);
        }

        public void Logica(double Xini, double Xfin, double Xavance) {
            double Xmin = double.MaxValue; //El m�nimo valor de X obtenido
            double Xmax = double.MinValue; //El m�ximo valor de X obtenido

            double Ymin = double.MaxValue; //El m�nimo valor de Y obtenido
            double Ymax = double.MinValue; //El m�ximo valor de Y obtenido

            Puntos.Clear();
            for (double valX = Xini; valX <= Xfin; valX += Xavance) {
                //Se invierte el valor porque el eje Y
                //aumenta hacia abajo
                double valY = -1 * Ecuacion(valX);

                //Valores m�ximos y m�nimos
                if (valY > Ymax) Ymax = valY;
                if (valY < Ymin) Ymin = valY;
                if (valX > Xmax) Xmax = valX;
                if (valX < Xmin) Xmin = valX;

                Puntos.Add(new Punto(valX, valY));
            }

            //Calcula los puntos a poner en la pantalla
            double convierteX = (XpantallaFin - XpantallaIni) / (Xmax - Xmin);
            double convierteY = (YpantallaFin - YpantallaIni) / (Ymax - Ymin);

            for (int Cont = 0; Cont < Puntos.Count; Cont++) {
                double pX = convierteX * (Puntos[Cont].X - Xmin) + XpantallaIni;
                double pY = convierteY * (Puntos[Cont].Y - Ymin) + YpantallaIni;
                Puntos[Cont].pantX = Convert.ToInt32(pX);
                Puntos[Cont].pantY = Convert.ToInt32(pY);
            }
        }

        //Aqu� est� la ecuaci�n que se desee graficar
        //con variable independiente X
        public double Ecuacion(double X) {
            double Y = 0.1 * Math.Pow(X, 6) + 0.6 * Math.Pow(X, 5);
            Y -= 0.7 * Math.Pow(X, 4) - 5.7 * Math.Pow(X, 3);
            Y += 2 * X * X + 2 * X + 1;
            return Y;
        }

        //Pinta la ecuaci�n
        private void Form1_Paint(object sender, PaintEventArgs e) {
            Graphics Lienzo = e.Graphics;
            Pen LapizGrafica = new(Color.Blue, 2);
            Pen LapizPerimetro = new(Color.Red, 2);
            Brush Relleno = new SolidBrush(Color.Black);

            //Un recuadro para ver el �rea del gr�fico
            int Xini = XpantallaIni;
            int Yini = YpantallaIni;
            int Xfin = XpantallaFin - XpantallaIni;
            int Yfin = YpantallaFin - YpantallaIni;
            Lienzo.DrawRectangle(LapizPerimetro, Xini, Yini, Xfin, Yfin);
            Lienzo.FillRectangle(Relleno, Xini, Yini, Xfin, Yfin);

            //Dibuja el gr�fico matem�tico
            for (int cont = 0; cont < Puntos.Count - 1; cont++) {
                Xini = Puntos[cont].pantX;
                Yini = Puntos[cont].pantY;
                Xfin = Puntos[cont + 1].pantX;
                Yfin = Puntos[cont + 1].pantY;
                Lienzo.DrawLine(LapizGrafica, Xini, Yini, Xfin, Yfin);
            }
        }
    }
}