﻿namespace Ejemplo;

//Generador congruencia lineal de números
//pseudo-aleatorios
internal class Aleatorio {
    private long A, B, X0, N;
    public Aleatorio(long A, long X0, long B, long N) {
        this.A = A;
        this.X0 = X0;
        this.B = B;
        this.N = N;
    }

    public double Numero() {
        X0 = (A * X0 + B) % N;
        return (double)X0 / N;
    }
}
