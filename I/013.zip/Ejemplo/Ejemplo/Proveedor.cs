﻿namespace Ejemplo;

//Los días que tarda el proveedor en entregar el producto
//desde el pedido
internal class Proveedor {
    int Dias;
    int Probabilidad;

    public Proveedor(int Dias, int Probabilidad) {
        this.Dias = Dias;
        this.Probabilidad = Probabilidad;
    }

    public int getDias() { return Dias; }
    public int getProbabilidad() { return Probabilidad; }
}
