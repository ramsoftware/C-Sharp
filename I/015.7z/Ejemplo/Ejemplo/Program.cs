﻿namespace Ejemplo {
    internal class Program {
        static void Main(string[] args) {
            Poblacion poblacion = new Poblacion();
            poblacion.Parametros();
            poblacion.Proceso();
        }
    }
}
