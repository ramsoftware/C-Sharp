﻿namespace Ejemplo {
    internal class Apostador {
        public int Dinero;
        public int Riesgo;

        public Apostador(int dinero, int riesgo) {
            Dinero = dinero;
            Riesgo = riesgo;
        }
    }
}
