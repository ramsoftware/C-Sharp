﻿namespace Ejemplo; 

//Demanda diaria del producto
internal class Demanda {
    private int Compra;
    private int Probabilidad;

    public Demanda(int Compra, int Probabilidad) {
        this.Compra = Compra;
        this.Probabilidad = Probabilidad;
    }

    public int getCompra() {  return Compra; }
    public int getProbabilidad() { return Probabilidad; }
}
