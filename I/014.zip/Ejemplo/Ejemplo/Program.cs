﻿namespace Ejemplo; 
//Inventario
class Program {
    static void Main() {
        int CostoTotal = int.MaxValue;

        int MejorR = -1, MejorQ = -1;
        for (int R = 1; R <= 1000; R++)
            for (int Q = 1; Q <= 1000; Q++) {
                int Costo = SimularInventario(R, Q);
                if (Costo < CostoTotal) {
                    CostoTotal = Costo;
                    MejorR = R;
                    MejorQ = Q;
                    Console.WriteLine("Costo: " + CostoTotal + " R = " + MejorR + " Q = " + MejorQ);
                }
            }

        Console.WriteLine("Costo más bajo: " + CostoTotal);
        Console.WriteLine("R = " + MejorR);
        Console.WriteLine("Q = " + MejorQ);
    }

    static public int SimularInventario(int R, int Q) {
        Simular simular = new();
        simular.Parametros(R, Q);
        return simular.Proceso();
    }
}