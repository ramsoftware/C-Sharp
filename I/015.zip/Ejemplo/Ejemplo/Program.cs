﻿namespace Ejemplo; 
internal class Program {
    static void Main() {
        Poblacion poblacion = new();
        poblacion.Parametros();
        poblacion.Proceso();
    }
}
