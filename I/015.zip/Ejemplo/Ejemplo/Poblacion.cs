﻿namespace Ejemplo;
    internal class Poblacion {
        int TotalJugadores;
        int DineroInicial;
        int DineroMinimo;
        int TotalCiclos;
        List<Apostador> Jugador;

        public void Parametros() {
            TotalJugadores = 900;
            Jugador = [];

            //Con cuánto dinero arranca cada jugador
            DineroInicial = 20000;

            //Si el capital de un jugador cae por debajo
            //de este número, se retira
            DineroMinimo = 1500;

            TotalCiclos = 7000;
        }

        public void Proceso() {
            Random Azar = new();

            //Crea la población
            for (int cont = 1; cont <= TotalJugadores; cont++)
                Jugador.Add(new Apostador(DineroInicial, Azar.Next(1, 101)));

            //Ciclo de juegos
            for (int Ciclo = 1; Ciclo <= TotalCiclos; Ciclo++) {
                int num = 0;
                while (num < Jugador.Count) {

                    //Si el jugador queda con capital por debajo
                    //de DineroMinimo, se elimina
                    if (Jugador[num].Dinero < DineroMinimo) {
                        Jugador.RemoveAt(num);
                        continue;
                    }

                    //Se enfrenta a una apuesta
                    int Ganancia = Jugador[num].Dinero * Jugador[num].Riesgo / 100;
                    if (Azar.Next(1, 101) <= Jugador[num].Riesgo)
                        Jugador[num].Dinero -= Ganancia;
                    else
                        Jugador[num].Dinero += Ganancia;

                    //Siguiente jugador
                    num++;
                }

                //¿La población quedó en cero?
                if (Jugador.Count == 0) {
                    Console.WriteLine("Colapso de la población");
                    Environment.Exit(0);
                }

                //Si la población está por debajo de TotalJugadores,
                //entonces se busca el que más dinero tiene y se le
                //sacan copias modificadas
                if (Jugador.Count < TotalJugadores) {

                    //Busca el que tiene más dinero
                    int MaximoDinero = int.MinValue;
                    int Cual = -1;
                    for (num = 0; num < Jugador.Count; num++) {
                        if (Jugador[num].Dinero > MaximoDinero) {
                            MaximoDinero = Jugador[num].Dinero;
                            Cual = num;
                        }
                    }

                    //Saca copias modificadas del individuo con más dinero
                    while (Jugador.Count < TotalJugadores) {
                        int CambiaRiesgo = 1;
                        if (Azar.NextDouble() < 0.5) CambiaRiesgo = -1;
                        int NuevoRiesgo = Jugador[Cual].Riesgo + CambiaRiesgo;
                        Jugador.Add(new Apostador(DineroInicial, NuevoRiesgo));
                    }
                }
            }

            Console.Write("Los jugadores que se mantienen en la población, arriesgaron porcentaje de su capital en promedio: ");
            int Acumula = 0;
            for (int num = 0; num < Jugador.Count; num++)
                Acumula += Jugador[num].Riesgo;
            double Promedio = (double) Acumula / Jugador.Count;
            Console.WriteLine(Promedio);
        }
    }
