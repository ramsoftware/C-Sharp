﻿namespace Ejemplo {

    //Simula el día a día del inventario de punto RQ
    internal class Simular {
        int R, Q;
        int Inicial;
        int CostoPerdida;
        int CostoPedido;
        int CostoAlmacena;
        List<Demanda> DemandaCliente;
        List<Proveedor> DiasProveedor;
        int DiasSimula;
        Aleatorio AzarA;
        Aleatorio AzarB;


        public void Parametros() {
            /* Punto de Reorden.Cuando el inventario al final del día queda
             * igual o por debajo de este valor, entonces se hace el pedido
             * al proveedor */
            R = 120;

            /* Esta es la cantidad fija que se le pide al proveedor */
            Q = 240;

            /* Inventario Inicial */
            Inicial = 570;

            /* Costo de pérdida de prestigio por unidad no entregada al cliente */
            CostoPerdida = 400;

            /* Costo de hacer el pedido */
            CostoPedido = 7000;

            /* Costo de almacenar una unidad por día */
            CostoAlmacena = 125;

            /* Comportamiento de la demanda, 
             * las probabilidades deben sumar 100 */
            DemandaCliente = new List<Demanda>();
            DemandaCliente.Add(new Demanda(25, 10));
            DemandaCliente.Add(new Demanda(26, 20));
            DemandaCliente.Add(new Demanda(27, 30));
            DemandaCliente.Add(new Demanda(28, 25));
            DemandaCliente.Add(new Demanda(29, 15));

            /* Dias de entrega del proveedor,
             * las probabilidades deben sumar 100 */
            DiasProveedor = new List<Proveedor>();
            DiasProveedor.Add(new Proveedor(3, 20));
            DiasProveedor.Add(new Proveedor(4, 30));
            DiasProveedor.Add(new Proveedor(5, 35));
            DiasProveedor.Add(new Proveedor(6, 10));
            DiasProveedor.Add(new Proveedor(7, 5));

            /* Días a simular */
            DiasSimula = 1000;

            /* Generadores de números aleatorios */
            AzarA = new Aleatorio(2678917, 4579991, 1317513, 9824217);
            AzarB = new Aleatorio(7921083, 6731297, 9021531, 9420811);
        }

        /* Retorna la demanda de unidades dependiendo del 
         * del número aleatorio */

        public int Demanda(double Valor) {
            int Acumula = 0;
            int Tope = (int)(Valor * 100);
            int Cont;
            for (Cont = 0; Cont < DemandaCliente.Count; Cont++) {
                Acumula += DemandaCliente[Cont].getProbabilidad();
                if (Acumula > Tope) break;
            }
            return DemandaCliente[Cont].getCompra();
        }

        /* Retorna los días dependiendo del número aleatorio */
        public int Dias(double Valor) {
            int Acumula = 0;
            int Tope = (int)(Valor * 100);
            int Cont;
            for (Cont = 0; Cont < DiasProveedor.Count; Cont++) {
                Acumula += DiasProveedor[Cont].getProbabilidad();
                if (Acumula > Tope) break;
            }
            return DiasProveedor[Cont].getDias();
        }

        /* Proceso de simulación */
        public void Proceso() {
            //Día cero
            AzarA.Numero();
            AzarB.Numero();

            //Inicia el día cero con un inventario inicial
            int Inventario = Inicial;

            //Días para llegar el pedido del proveedor
            int DiasLlegaPedido = 0, CuentaAtrasPedido = -1;
            
            //Costos diarios
            int CostoInventario, CostoOrdenar, CostoPrestigio;

            //Acumula Costos
            int AcumCostoInventario = 0, AcumCostoOrdenar = 0, AcumCostoPrestigio = 0;

            Console.WriteLine("Dia;Azar;Demanda;Inventario;Costo Inventario;Costo Ordenar;Azar;Llega Pedido;Cuenta atrás pedido;Costo pérdida de prestigio");

            for (int dias = 1; dias <= DiasSimula; dias++) {

                //Cuenta Atrás para llegar el pedido del proveedor
                if (DiasLlegaPedido > 0)
                    CuentaAtrasPedido = DiasLlegaPedido;
                else {
                    if (CuentaAtrasPedido > 0)
                        CuentaAtrasPedido--;
                    else
                        CuentaAtrasPedido = -1;
                }

                //Valores aleatorios del día
                double NumA = AzarA.Numero();
                double NumB = AzarB.Numero();

                //Valor del inventario
                int NuevoValor = 0;
                if (Inventario > 0) NuevoValor = Inventario;

                //Compra de los clientes
                int Compra = Demanda(NumA);
                NuevoValor -= Compra;

                //Si llega el pedido
                if (CuentaAtrasPedido == 0) NuevoValor += Q;

                //El nuevo valor de inventario
                Inventario = NuevoValor;

                //Costo del inventario
                if (Inventario > 0)
                    CostoInventario = Inventario * CostoAlmacena;
                else
                    CostoInventario = 0;

                //Costo ordenar
                CostoOrdenar = 0;
                if (Inventario <= R && CuentaAtrasPedido <= 0)
                    CostoOrdenar = CostoPedido;

                //Segundo Azar si hay pedido
                double SegundoAzar = -1;
                if (CostoOrdenar > 0)
                    SegundoAzar = NumB;

                //Llega Pedido
                DiasLlegaPedido = 0;
                if (SegundoAzar > 0)
                    DiasLlegaPedido = Dias(SegundoAzar);

                //Pérdida de prestigio
                CostoPrestigio = 0;
                if (Inventario < 0)
                    CostoPrestigio = Inventario * CostoPerdida * -1;

                //Imprime el día
                Console.WriteLine(dias + ";" + NumA + ";" + Compra + ";" + Inventario + ";" + CostoInventario + ";" + CostoOrdenar + ";" + SegundoAzar + ";" + DiasLlegaPedido + ";" + CuentaAtrasPedido + ";" + CostoPrestigio);

                //Acumula costos
                AcumCostoInventario += CostoInventario;
                AcumCostoOrdenar += CostoOrdenar;
                AcumCostoPrestigio += CostoPrestigio;
            }

            //Imprime los costos totales
            Console.WriteLine("Costo total inventario;" + AcumCostoInventario);
            Console.WriteLine("Costo total ordenar;" + AcumCostoOrdenar);
            Console.WriteLine("Costo total prestigio;" + AcumCostoPrestigio);

            //Costo total
            int CostoTotal = AcumCostoInventario + AcumCostoOrdenar + AcumCostoPrestigio;
            Console.WriteLine("Costo total;" + CostoTotal);
        }
    }
}
