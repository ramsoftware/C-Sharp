﻿
namespace Ejemplo {
    //Inventario
    class Program {
        static void Main() {
            Simular simular = new();
            simular.Parametros();
            simular.Proceso();
        }
    }
}