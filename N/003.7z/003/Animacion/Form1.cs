namespace Animacion {
    public partial class Form1 : Form {
        int[,] Plano; //D�nde ocurre realmente la acci�n
        int PosX, PosY; //Coordenadas del cuadrado relleno
        int IncrX, IncrY; //Desplazamiento del cuadrado relleno

        public Form1() {
            InitializeComponent();

            //Inicializa el tablero
            Plano = new int[30, 30];

            //Inicializa la posici�n del cuadrado relleno
            Random azar = new();
            PosX = azar.Next(0, Plano.GetLength(0));
            PosY = azar.Next(0, Plano.GetLength(1));

            //Desplaza el cuadrado relleno
            IncrX = 1;
            IncrY = 1;
        }

        private void timer1_Tick(object sender, System.EventArgs e) {
            Logica(); //L�gica de la animaci�n
            Refresh(); //Visual de la animaci�n
        }

        void Logica() {
            //Borra la posici�n anterior
            Plano[PosX, PosY] = 0;

            //Si colisiona con alguna pared cambia el incremento
            if (PosX + IncrX >= Plano.GetLength(0) || PosX + IncrX < 0)
                IncrX *= -1;

            if (PosY + IncrY >= Plano.GetLength(1) || PosY + IncrY < 0)
                IncrY *= -1;

            //Cambia la posici�n de X y Y 
            PosX += IncrX;
            PosY += IncrY;

            //Nueva posici�n
            Plano[PosX, PosY] = 1;
        }

        private void Form1_Paint(object sender, PaintEventArgs e) {
            Graphics lienzo = e.Graphics;
            Pen Lapiz = new(Color.Blue, 1);
            Brush Llena = new SolidBrush(Color.Red);

            //Tama�o de cada celda
            int tX = ClientSize.Width / Plano.GetLength(0);
            int tY = ClientSize.Height / Plano.GetLength(1);

            //Fondo de la ventana
            Rectangle rect = new(0, 0, this.Width, this.Height);
            lienzo.FillRectangle(Brushes.Black, rect);

            //Dibuja la malla y la posici�n del rect�ngulo relleno
            for (int Fil = 0; Fil < Plano.GetLength(0); Fil++) {
                for (int Col = 0; Col < Plano.GetLength(1); Col++)
                    if (Plano[Fil, Col] == 0)
                        lienzo.DrawRectangle(Lapiz, Fil * tX, Col * tY, tX, tY);
                    else
                        lienzo.FillRectangle(Llena, Fil * tX, Col * tY, tX, tY);
            }
        }
    }
}