﻿namespace Graficos {
	//Triángulo
	internal class Poligono {
		public int punto1, punto2, punto3, punto4;
		public double Centro;

		//Coordenadas de dibujo del polígono
		private Point Polig1, Polig2, Polig3, Polig4;
		private Point[] ListaPuntos;

		//Color de relleno del polígono
		Color ColorZ;

		public Poligono(int punto1, int punto2, int punto3, int punto4) {
			this.punto1 = punto1;
			this.punto2 = punto2;
			this.punto3 = punto3;
			this.punto4 = punto4;
		}

		//Calcula la profundidad y crea los vértices del polígono
		public void ProfundidadFigura(List<Punto> puntos, List<Color> colorList) {
			double Z1 = puntos[punto1].Zgiro;
			double Z2 = puntos[punto2].Zgiro;
			double Z3 = puntos[punto3].Zgiro;
			double Z4 = puntos[punto4].Zgiro;
			Centro = (Z1 + Z2 + Z3 + Z4) / 4;

			Polig1 = new(puntos[punto1].Xpantalla, puntos[punto1].Ypantalla);
			Polig2 = new(puntos[punto2].Xpantalla, puntos[punto2].Ypantalla);
			Polig3 = new(puntos[punto3].Xpantalla, puntos[punto3].Ypantalla);
			Polig4 = new(puntos[punto4].Xpantalla, puntos[punto4].Ypantalla);
			ListaPuntos = [Polig1, Polig2, Polig3, Polig4];

			int TotalColores = colorList.Count;
			double PromedioZ = (puntos[punto1].Z + puntos[punto2].Z + puntos[punto3].Z + puntos[punto4].Z + 2) / 4;
			int ColorEscoge = (int)Math.Floor(TotalColores * PromedioZ);
			ColorZ = colorList[ColorEscoge];
		}

		//Hace el gráfico del polígono
		public void Dibuja(Graphics Lienzo) {
			//Dibuja el polígono relleno
			Brush Relleno2 = new SolidBrush(ColorZ);
			Lienzo.FillPolygon(Relleno2, ListaPuntos);
		}
	}
}
