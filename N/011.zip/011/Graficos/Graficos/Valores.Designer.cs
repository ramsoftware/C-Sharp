﻿namespace Graficos {
    partial class Valores {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Valores));
            tabConfigura = new TabControl();
            tabEcuacion = new TabPage();
            btnProcesar = new Button();
            txtEcuacion = new TextBox();
            lblEcuacion = new Label();
            tabTiempo = new TabPage();
            numAvanceT = new NumericUpDown();
            lblAvanceT = new Label();
            numMaximoT = new NumericUpDown();
            numMinimoT = new NumericUpDown();
            lblMaximoT = new Label();
            lblMinimoT = new Label();
            tabGiros = new TabPage();
            numTotalLineas = new NumericUpDown();
            lblTotalLineas = new Label();
            numGiroZ = new NumericUpDown();
            numGiroY = new NumericUpDown();
            numGiroX = new NumericUpDown();
            lblGiroZ = new Label();
            lblGiroY = new Label();
            lblGiroX = new Label();
            tabAyuda = new TabPage();
            txtAyuda = new TextBox();
            tabConfigura.SuspendLayout();
            tabEcuacion.SuspendLayout();
            tabTiempo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numAvanceT).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numMaximoT).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numMinimoT).BeginInit();
            tabGiros.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numTotalLineas).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numGiroZ).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numGiroY).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numGiroX).BeginInit();
            tabAyuda.SuspendLayout();
            SuspendLayout();
            // 
            // tabConfigura
            // 
            tabConfigura.Appearance = TabAppearance.Buttons;
            tabConfigura.Controls.Add(tabEcuacion);
            tabConfigura.Controls.Add(tabTiempo);
            tabConfigura.Controls.Add(tabGiros);
            tabConfigura.Controls.Add(tabAyuda);
            tabConfigura.Dock = DockStyle.Fill;
            tabConfigura.Font = new Font("Verdana", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tabConfigura.Location = new Point(0, 0);
            tabConfigura.Margin = new Padding(4, 3, 4, 3);
            tabConfigura.Name = "tabConfigura";
            tabConfigura.SelectedIndex = 0;
            tabConfigura.Size = new Size(1191, 81);
            tabConfigura.TabIndex = 0;
            // 
            // tabEcuacion
            // 
            tabEcuacion.BackColor = Color.LightGreen;
            tabEcuacion.Controls.Add(btnProcesar);
            tabEcuacion.Controls.Add(txtEcuacion);
            tabEcuacion.Controls.Add(lblEcuacion);
            tabEcuacion.Location = new Point(4, 30);
            tabEcuacion.Margin = new Padding(4, 3, 4, 3);
            tabEcuacion.Name = "tabEcuacion";
            tabEcuacion.Padding = new Padding(4, 3, 4, 3);
            tabEcuacion.Size = new Size(1183, 47);
            tabEcuacion.TabIndex = 2;
            tabEcuacion.Text = "Ecuación";
            // 
            // btnProcesar
            // 
            btnProcesar.Location = new Point(1080, 14);
            btnProcesar.Margin = new Padding(4, 3, 4, 3);
            btnProcesar.Name = "btnProcesar";
            btnProcesar.Size = new Size(99, 28);
            btnProcesar.TabIndex = 14;
            btnProcesar.Text = "Procesar";
            btnProcesar.UseVisualStyleBackColor = true;
            btnProcesar.Click += btnProcesar_Click;
            // 
            // txtEcuacion
            // 
            txtEcuacion.Location = new Point(49, 16);
            txtEcuacion.Margin = new Padding(4, 3, 4, 3);
            txtEcuacion.Name = "txtEcuacion";
            txtEcuacion.Size = new Size(1023, 26);
            txtEcuacion.TabIndex = 12;
            txtEcuacion.Text = "2 * Sen(P + T) - Sen(H - T)";
            // 
            // lblEcuacion
            // 
            lblEcuacion.AutoSize = true;
            lblEcuacion.Location = new Point(6, 16);
            lblEcuacion.Margin = new Padding(4, 0, 4, 0);
            lblEcuacion.Name = "lblEcuacion";
            lblEcuacion.Size = new Size(31, 18);
            lblEcuacion.TabIndex = 10;
            lblEcuacion.Text = "r =";
            // 
            // tabTiempo
            // 
            tabTiempo.Controls.Add(numAvanceT);
            tabTiempo.Controls.Add(lblAvanceT);
            tabTiempo.Controls.Add(numMaximoT);
            tabTiempo.Controls.Add(numMinimoT);
            tabTiempo.Controls.Add(lblMaximoT);
            tabTiempo.Controls.Add(lblMinimoT);
            tabTiempo.Location = new Point(4, 30);
            tabTiempo.Name = "tabTiempo";
            tabTiempo.Padding = new Padding(3);
            tabTiempo.Size = new Size(1183, 47);
            tabTiempo.TabIndex = 5;
            tabTiempo.Text = "Tiempo";
            tabTiempo.UseVisualStyleBackColor = true;
            // 
            // numAvanceT
            // 
            numAvanceT.DecimalPlaces = 2;
            numAvanceT.Location = new Point(945, 9);
            numAvanceT.Margin = new Padding(4, 3, 4, 3);
            numAvanceT.Maximum = new decimal(new int[] { 2000, 0, 0, 0 });
            numAvanceT.Minimum = new decimal(new int[] { 1, 0, 0, 131072 });
            numAvanceT.Name = "numAvanceT";
            numAvanceT.Size = new Size(90, 26);
            numAvanceT.TabIndex = 32;
            numAvanceT.TextAlign = HorizontalAlignment.Right;
            numAvanceT.Value = new decimal(new int[] { 1, 0, 0, 131072 });
            // 
            // lblAvanceT
            // 
            lblAvanceT.AutoSize = true;
            lblAvanceT.Location = new Point(764, 9);
            lblAvanceT.Margin = new Padding(4, 0, 4, 0);
            lblAvanceT.Name = "lblAvanceT";
            lblAvanceT.Size = new Size(173, 18);
            lblAvanceT.TabIndex = 31;
            lblAvanceT.Text = "Avance de T (Tiempo)";
            // 
            // numMaximoT
            // 
            numMaximoT.DecimalPlaces = 2;
            numMaximoT.Location = new Point(622, 9);
            numMaximoT.Margin = new Padding(4, 3, 4, 3);
            numMaximoT.Maximum = new decimal(new int[] { 2000, 0, 0, 0 });
            numMaximoT.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numMaximoT.Name = "numMaximoT";
            numMaximoT.Size = new Size(90, 26);
            numMaximoT.TabIndex = 30;
            numMaximoT.TextAlign = HorizontalAlignment.Right;
            numMaximoT.Value = new decimal(new int[] { 3, 0, 0, 0 });
            // 
            // numMinimoT
            // 
            numMinimoT.DecimalPlaces = 2;
            numMinimoT.Location = new Point(305, 11);
            numMinimoT.Margin = new Padding(4, 3, 4, 3);
            numMinimoT.Maximum = new decimal(new int[] { 2000, 0, 0, 0 });
            numMinimoT.Minimum = new decimal(new int[] { 1, 0, 0, 131072 });
            numMinimoT.Name = "numMinimoT";
            numMinimoT.Size = new Size(90, 26);
            numMinimoT.TabIndex = 29;
            numMinimoT.TextAlign = HorizontalAlignment.Right;
            numMinimoT.Value = new decimal(new int[] { 2, 0, 0, 65536 });
            // 
            // lblMaximoT
            // 
            lblMaximoT.AutoSize = true;
            lblMaximoT.Location = new Point(459, 9);
            lblMaximoT.Margin = new Padding(4, 0, 4, 0);
            lblMaximoT.Name = "lblMaximoT";
            lblMaximoT.Size = new Size(155, 18);
            lblMaximoT.TabIndex = 28;
            lblMaximoT.Text = "Máximo T (Tiempo)";
            // 
            // lblMinimoT
            // 
            lblMinimoT.AutoSize = true;
            lblMinimoT.Location = new Point(148, 11);
            lblMinimoT.Margin = new Padding(4, 0, 4, 0);
            lblMinimoT.Name = "lblMinimoT";
            lblMinimoT.Size = new Size(149, 18);
            lblMinimoT.TabIndex = 27;
            lblMinimoT.Text = "Mínimo T (Tiempo)";
            // 
            // tabGiros
            // 
            tabGiros.BackColor = Color.PaleGoldenrod;
            tabGiros.Controls.Add(numTotalLineas);
            tabGiros.Controls.Add(lblTotalLineas);
            tabGiros.Controls.Add(numGiroZ);
            tabGiros.Controls.Add(numGiroY);
            tabGiros.Controls.Add(numGiroX);
            tabGiros.Controls.Add(lblGiroZ);
            tabGiros.Controls.Add(lblGiroY);
            tabGiros.Controls.Add(lblGiroX);
            tabGiros.Location = new Point(4, 30);
            tabGiros.Margin = new Padding(4, 3, 4, 3);
            tabGiros.Name = "tabGiros";
            tabGiros.Padding = new Padding(4, 3, 4, 3);
            tabGiros.Size = new Size(1183, 47);
            tabGiros.TabIndex = 0;
            tabGiros.Text = "Giros";
            // 
            // numTotalLineas
            // 
            numTotalLineas.Location = new Point(1072, 14);
            numTotalLineas.Margin = new Padding(4, 3, 4, 3);
            numTotalLineas.Maximum = new decimal(new int[] { 120, 0, 0, 0 });
            numTotalLineas.Minimum = new decimal(new int[] { 50, 0, 0, 0 });
            numTotalLineas.Name = "numTotalLineas";
            numTotalLineas.Size = new Size(90, 26);
            numTotalLineas.TabIndex = 19;
            numTotalLineas.TextAlign = HorizontalAlignment.Right;
            numTotalLineas.Value = new decimal(new int[] { 80, 0, 0, 0 });
            numTotalLineas.ValueChanged += numTotalLineas_ValueChanged;
            // 
            // lblTotalLineas
            // 
            lblTotalLineas.AutoSize = true;
            lblTotalLineas.Location = new Point(949, 14);
            lblTotalLineas.Margin = new Padding(4, 0, 4, 0);
            lblTotalLineas.Name = "lblTotalLineas";
            lblTotalLineas.Size = new Size(112, 18);
            lblTotalLineas.TabIndex = 18;
            lblTotalLineas.Text = "Total de líneas";
            // 
            // numGiroZ
            // 
            numGiroZ.Location = new Point(698, 14);
            numGiroZ.Margin = new Padding(4, 3, 4, 3);
            numGiroZ.Maximum = new decimal(new int[] { 360, 0, 0, 0 });
            numGiroZ.Name = "numGiroZ";
            numGiroZ.Size = new Size(90, 26);
            numGiroZ.TabIndex = 11;
            numGiroZ.TextAlign = HorizontalAlignment.Right;
            numGiroZ.Value = new decimal(new int[] { 45, 0, 0, 0 });
            numGiroZ.ValueChanged += numGiroZ_ValueChanged;
            // 
            // numGiroY
            // 
            numGiroY.Location = new Point(405, 14);
            numGiroY.Margin = new Padding(4, 3, 4, 3);
            numGiroY.Maximum = new decimal(new int[] { 360, 0, 0, 0 });
            numGiroY.Name = "numGiroY";
            numGiroY.Size = new Size(90, 26);
            numGiroY.TabIndex = 10;
            numGiroY.TextAlign = HorizontalAlignment.Right;
            numGiroY.Value = new decimal(new int[] { 45, 0, 0, 0 });
            numGiroY.ValueChanged += numGiroY_ValueChanged;
            // 
            // numGiroX
            // 
            numGiroX.Location = new Point(114, 14);
            numGiroX.Margin = new Padding(4, 3, 4, 3);
            numGiroX.Maximum = new decimal(new int[] { 360, 0, 0, 0 });
            numGiroX.Name = "numGiroX";
            numGiroX.Size = new Size(90, 26);
            numGiroX.TabIndex = 9;
            numGiroX.TextAlign = HorizontalAlignment.Right;
            numGiroX.Value = new decimal(new int[] { 45, 0, 0, 0 });
            numGiroX.ValueChanged += numGiroX_ValueChanged;
            // 
            // lblGiroZ
            // 
            lblGiroZ.AutoSize = true;
            lblGiroZ.Location = new Point(613, 14);
            lblGiroZ.Margin = new Padding(4, 0, 4, 0);
            lblGiroZ.Name = "lblGiroZ";
            lblGiroZ.Size = new Size(77, 18);
            lblGiroZ.TabIndex = 8;
            lblGiroZ.Text = "Giro en Z";
            // 
            // lblGiroY
            // 
            lblGiroY.AutoSize = true;
            lblGiroY.Location = new Point(321, 14);
            lblGiroY.Margin = new Padding(4, 0, 4, 0);
            lblGiroY.Name = "lblGiroY";
            lblGiroY.Size = new Size(76, 18);
            lblGiroY.TabIndex = 7;
            lblGiroY.Text = "Giro en Y";
            // 
            // lblGiroX
            // 
            lblGiroX.AutoSize = true;
            lblGiroX.Location = new Point(29, 14);
            lblGiroX.Margin = new Padding(4, 0, 4, 0);
            lblGiroX.Name = "lblGiroX";
            lblGiroX.Size = new Size(77, 18);
            lblGiroX.TabIndex = 6;
            lblGiroX.Text = "Giro en X";
            // 
            // tabAyuda
            // 
            tabAyuda.Controls.Add(txtAyuda);
            tabAyuda.Location = new Point(4, 30);
            tabAyuda.Name = "tabAyuda";
            tabAyuda.Padding = new Padding(3);
            tabAyuda.Size = new Size(1183, 47);
            tabAyuda.TabIndex = 4;
            tabAyuda.Text = "Ayuda";
            tabAyuda.UseVisualStyleBackColor = true;
            // 
            // txtAyuda
            // 
            txtAyuda.Dock = DockStyle.Fill;
            txtAyuda.Font = new Font("Verdana", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtAyuda.Location = new Point(3, 3);
            txtAyuda.Multiline = true;
            txtAyuda.Name = "txtAyuda";
            txtAyuda.ReadOnly = true;
            txtAyuda.Size = new Size(1177, 41);
            txtAyuda.TabIndex = 0;
            txtAyuda.Text = resources.GetString("txtAyuda.Text");
            // 
            // Valores
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(1191, 81);
            Controls.Add(tabConfigura);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Margin = new Padding(4, 3, 4, 3);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Valores";
            Text = "Configuración del gráfico";
            tabConfigura.ResumeLayout(false);
            tabEcuacion.ResumeLayout(false);
            tabEcuacion.PerformLayout();
            tabTiempo.ResumeLayout(false);
            tabTiempo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numAvanceT).EndInit();
            ((System.ComponentModel.ISupportInitialize)numMaximoT).EndInit();
            ((System.ComponentModel.ISupportInitialize)numMinimoT).EndInit();
            tabGiros.ResumeLayout(false);
            tabGiros.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numTotalLineas).EndInit();
            ((System.ComponentModel.ISupportInitialize)numGiroZ).EndInit();
            ((System.ComponentModel.ISupportInitialize)numGiroY).EndInit();
            ((System.ComponentModel.ISupportInitialize)numGiroX).EndInit();
            tabAyuda.ResumeLayout(false);
            tabAyuda.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabConfigura;
        private TabPage tabGiros;
        private TabPage tabEcuacion;
        private NumericUpDown numGiroZ;
        private NumericUpDown numGiroY;
        private NumericUpDown numGiroX;
        private Label lblGiroZ;
        private Label lblGiroY;
        private Label lblGiroX;
        private Button btnProcesar;
        private TextBox txtEcuacion;
        private Label lblEcuacion;
        private TabPage tabAyuda;
        private TextBox txtAyuda;
        private NumericUpDown numTotalLineas;
        private Label lblTotalLineas;
        private TabPage tabTiempo;
        private NumericUpDown numAvanceT;
        private Label lblAvanceT;
        private NumericUpDown numMaximoT;
        private NumericUpDown numMinimoT;
        private Label lblMaximoT;
        private Label lblMinimoT;
    }
}