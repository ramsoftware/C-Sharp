namespace Graficos {
    //Proyecci�n 3D a 2D y giros. Figura centrada. Optimizaci�n.
    public partial class Form1 : Form {
        //La figura que se proyecta y gira
        Objeto3D Figura3D;

        //Distancia del observador
        public double ZPersona;

        //Rango de valores
        public double Xini, Yini, Xfin, Yfin;

        //N�mero de l�neas que tendr� el gr�fico
        public int NumLineas;

        //Ecuaci�n
        public string Ecuacion;

        //Para el movimiento aleatorio del gr�fico 3D
        private double AnguloX, AnguloY, AnguloZ;
        private double IncrAngX, IncrAngY, IncrAngZ;
        private double AnguloXNuevo, AnguloYNuevo, AnguloZNuevo;
        Random Azar;


        public Form1() {
            InitializeComponent();
            Figura3D = new Objeto3D();

            //�ngulos aleatorios para simular animaci�n
            Azar = new Random();
            AnguloX = Azar.Next(0, 360);
            AnguloY = Azar.Next(0, 360);
            AnguloZ = Azar.Next(0, 360);
            AnguloXNuevo = Azar.Next(0, 360);
            AnguloYNuevo = Azar.Next(0, 360);
            AnguloZNuevo = Azar.Next(0, 360);
        }

        private void Form1_Paint(object sender, PaintEventArgs e) {
            //Dibuja la figura 3D
            Figura3D.CalcularFigura3D(Ecuacion, Xini, Yini, Xfin, Yfin, NumLineas, AnguloX*Math.PI/180, AnguloY * Math.PI / 180, AnguloZ * Math.PI / 180, ZPersona, 0, 0, this.ClientSize.Width, this.ClientSize.Height);
            Figura3D.Dibuja(e.Graphics);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e) {
            Application.Exit();
        }

        private void Form1_Resize(object sender, EventArgs e) {
            Refresh();
        }

        private void timer1_Tick(object sender, EventArgs e) {
            //Cambio de los �ngulos de giro
            if (AnguloX > AnguloXNuevo) IncrAngX = -1; else IncrAngX = 1;
            if (AnguloY > AnguloYNuevo) IncrAngY = -1; else IncrAngY = 1;
            if (AnguloZ > AnguloZNuevo) IncrAngZ = -1; else IncrAngZ = 1;

            AnguloX += IncrAngX;
            AnguloY += IncrAngY;
            AnguloZ += IncrAngZ;

            if (AnguloX == AnguloXNuevo) AnguloXNuevo = Azar.Next(0, 360);
            if (AnguloY == AnguloYNuevo) AnguloYNuevo = Azar.Next(0, 360);
            if (AnguloZ == AnguloZNuevo) AnguloZNuevo = Azar.Next(0, 360);
            Refresh();
        }
    }
}
