﻿namespace Graficos {
	public partial class Valores : Form {

		Form1 FrmGrafico = new();
		const double Radianes = Math.PI / 180;
		public Valores() {
			InitializeComponent();

			FrmGrafico.Xini = Convert.ToDouble((double)numMinimoX.Value);
			FrmGrafico.Yini = Convert.ToDouble((double)numMinimoY.Value);
			FrmGrafico.Xfin = Convert.ToDouble((double)numMaximoX.Value);
			FrmGrafico.Yfin = Convert.ToDouble((double)numMaximoY.Value);
			FrmGrafico.NumLineas = Convert.ToInt32((double)numTotalLineas.Value);
			FrmGrafico.Ecuacion = txtEcuacion.Text;
			FrmGrafico.ZPersona = 5;

			FrmGrafico.Show();
		}

		private void numMinimoX_ValueChanged(object sender, EventArgs e) {
			if (numMinimoX.Value >= numMaximoX.Value)
				numMinimoX.Value = numMaximoX.Value - 1;

			FrmGrafico.Xini = Convert.ToDouble((double)numMinimoX.Value);
			FrmGrafico.Refresh();
		}

		private void numMinimoY_ValueChanged(object sender, EventArgs e) {
			if (numMinimoY.Value >= numMaximoY.Value)
				numMinimoY.Value = numMaximoY.Value - 1;

			FrmGrafico.Yini = Convert.ToDouble((double)numMinimoY.Value);
			FrmGrafico.Refresh();
		}

		private void numMaximoX_ValueChanged(object sender, EventArgs e) {
			if (numMinimoX.Value >= numMaximoX.Value)
				numMaximoX.Value = numMinimoX.Value + 1;

			FrmGrafico.Xfin = Convert.ToDouble((double)numMaximoX.Value);
			FrmGrafico.Refresh();
		}

		private void numMaximoY_ValueChanged(object sender, EventArgs e) {
			if (numMinimoY.Value >= numMaximoY.Value)
				numMaximoY.Value = numMinimoY.Value + 1;

			FrmGrafico.Yfin = Convert.ToDouble((double)numMaximoY.Value);
			FrmGrafico.Refresh();
		}

		private void numTotalLineas_ValueChanged(object sender, EventArgs e) {
			FrmGrafico.NumLineas = Convert.ToInt32((double)numTotalLineas.Value);
			FrmGrafico.Refresh();
		}

		private void btnProcesar_Click(object sender, EventArgs e) {
			FrmGrafico.Ecuacion = txtEcuacion.Text;
			FrmGrafico.Refresh();
		}
	}
}
