﻿namespace Graficos {
    internal class Objeto3D {
        //Coordenadas espaciales X, Y, Z
        private List<Punto> puntos;

        //Coordenadas del polígono (triángulo)
        private List<Poligono> poligonos;

        //Colores para pintar la malla
        List<Color> ListaColores;

        //Ecuación
        string EcuacionAnterior = "";
        Evaluador4 Evaluador = new();

        public Objeto3D() {
            int NumColores = 40; // Número de colores a generar            

            //Genera listado de colores para el gráfico
            ListaColores = [];
            int Mitad = NumColores / 2;

            // Gradiente de azul a amarillo
            for (int Cont = 0; Cont < Mitad; Cont++) {
                int Rojo = (int)(255 * (Cont / (float)(NumColores - Mitad - 1)));
                int Verde = (int)(255 * (Cont / (float)(NumColores - Mitad - 1)));
                int Azul = 255 - (int)(255 * (Cont / (float)(NumColores - Mitad - 1)));
                ListaColores.Add(Color.FromArgb(Rojo, Verde, Azul));
            }

            // Gradiente de rojo a azul
            for (int Cont = 0; Cont < NumColores - Mitad; Cont++) {
                int Rojo = 255 - (int)(255 * (Cont / (float)(Mitad - 1)));
                int Verde = 0;
                int Azul = (int)(255 * (Cont / (float)(Mitad - 1)));
                ListaColores.Add(Color.FromArgb(Rojo, Verde, Azul));
            }
        }

        //Hace los cálculos de la ecuación Z = F(X,Y)
        //para dibujarla
        public void CalcularFigura3D(string Ecuacion, double Xini, double Xfin, int NumLineas, double valorT, double angX, double angY, double angZ, double ZPersona, int XpantallaIni, int YpantallaIni, int XpantallaFin, int YpantallaFin) {

            //Evalúa la ecuación. Si es nueva, la analiza.
            if (Ecuacion.Equals(EcuacionAnterior) == false) {
                int Sintaxis = Evaluador.Analizar(Ecuacion);
                if (Sintaxis > 0) { //Tiene un error de sintaxis
                    string MensajeError = Evaluador.MensajeError(Sintaxis);
                    MessageBox.Show(MensajeError, "Error de sintaxis",
        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            EcuacionAnterior = Ecuacion;

            //Incrementos X, Y 
            double IncrX = (Xfin - Xini) / (NumLineas - 1);
            double IncAng = (double) 360 / NumLineas;
            double X = Xini;

            //Valida que la ecuación tenga valores para graficar y de paso calcula
            //las constantes para normalizar
            double Xmin = double.MaxValue;
            double Ymin = double.MaxValue;
            double Zmin = double.MaxValue;
            double Xmax = double.MinValue;
            double Ymax = double.MinValue;
            double Zmax = double.MinValue;

            double AnguloGiro = 0;
            for (int GiroLinea = 1; GiroLinea <= NumLineas + 1; GiroLinea++) {
                for (int EjeX = 1; EjeX <= NumLineas; EjeX++) {
                    Evaluador.DarValorVariable('x', X);
                    Evaluador.DarValorVariable('t', valorT);
                    double Y = Evaluador.Evaluar();
                    if (double.IsNaN(Y) || double.IsInfinity(Y)) Y = 0;

                    double Yg = Y * Math.Cos(AnguloGiro * Math.PI / 180);
                    double Zg = Y * Math.Sin(AnguloGiro * Math.PI / 180);

                    if (X < Xmin) Xmin = X;
                    if (Yg < Ymin) Ymin = Yg;
                    if (Zg < Zmin) Zmin = Zg;

                    if (X > Xmax) Xmax = X;
                    if (Yg > Ymax) Ymax = Yg;
                    if (Zg > Zmax) Zmax = Zg;

                    X += IncrX;
                }
                AnguloGiro += IncAng;
                X = Xini;
            }

            if ( Math.Abs(Xmin-Xmax) < 0.0001 || Math.Abs(Ymin-Ymax) < 0.0001 || Math.Abs(Zmin - Zmax) < 0.0001) {
                MessageBox.Show("La ecuación digitada no puede generar un gráfico", "Error de cálculo",
    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            //Coordenadas espaciales X,Y,Z
            X = Xini;
            puntos = [];
            AnguloGiro = 0;
            for (int GiroLinea = 1; GiroLinea <= NumLineas+1; GiroLinea++) {
                for (int EjeX = 1; EjeX <= NumLineas; EjeX++) {
                    Evaluador.DarValorVariable('x', X);
                    Evaluador.DarValorVariable('t', valorT);
                    double Y = Evaluador.Evaluar();
                    if (double.IsNaN(Y) || double.IsInfinity(Y)) Y = 0;

                    double Yg = Y * Math.Cos(AnguloGiro * Math.PI / 180);
                    double Zg = Y * Math.Sin(AnguloGiro * Math.PI / 180);

                    puntos.Add(new Punto(X, Yg, Zg));
                    X += IncrX;
                }
                AnguloGiro += IncAng;
                X = Xini;
            }

            //Normaliza
            for (int Cont = 0; Cont < puntos.Count; Cont++) {
                puntos[Cont].X = (puntos[Cont].X - Xmin) / (Xmax - Xmin) - 0.5;
                puntos[Cont].Y = (puntos[Cont].Y - Ymin) / (Ymax - Ymin) - 0.5;
                puntos[Cont].Z = (puntos[Cont].Z - Zmin) / (Zmax - Zmin) - 0.5;
            }

            // Inicializa la lista de polígonos
            poligonos = [];

            int coordenadaActual = 0;
            int filaActual = 1;
            int totalPoligonos = (NumLineas - 1) * (NumLineas - 1) + (NumLineas - 1);

            for (int Cont = 0; Cont < totalPoligonos; Cont++) {
                // Crea un polígono con las coordenadas de los vértices
                poligonos.Add(new Poligono(
                    coordenadaActual,
                    coordenadaActual + 1,
                    coordenadaActual + NumLineas + 1,
                    coordenadaActual + NumLineas
                ));

                coordenadaActual++;

                // Salta al inicio de la siguiente fila si se alcanza el final de la actual
                if (coordenadaActual == NumLineas * filaActual - 1) {
                    coordenadaActual++;
                    filaActual++;
                }
            }

            //Para la matriz de rotación
            double CosX = Math.Cos(angX);
            double SinX = Math.Sin(angX);
            double CosY = Math.Cos(angY);
            double SinY = Math.Sin(angY);
            double CosZ = Math.Cos(angZ);
            double SinZ = Math.Sin(angZ);

            //Matriz de Rotación
            //https://en.wikipedia.org/wiki/Rotation_formalisms_in_three_dimensions
            double[,] Matriz = new double[3, 3] {
                { CosY * CosZ, -CosX * SinZ + SinX * SinY * CosZ, SinX * SinZ + CosX * SinY * CosZ},
                { CosY * SinZ, CosX * CosZ + SinX * SinY * SinZ, -SinX * CosZ + CosX * SinY * SinZ},
                {-SinY, SinX * CosY, CosX * CosY }
            };

            //Las constantes de transformación para cuadrar en pantalla
            double convierteX = (XpantallaFin - XpantallaIni) / 1.758630875383556;
            double convierteY = (YpantallaFin - YpantallaIni) / 1.758630875383556;

            //Gira los 8 puntos
            for (int cont = 0; cont < puntos.Count; cont++)
                puntos[cont].Giro(Matriz, ZPersona, XpantallaIni, YpantallaIni, convierteX, convierteY);

            //Calcula la profundidad y forma el polígono
            for (int Cont = 0; Cont < poligonos.Count; Cont++)
                poligonos[Cont].ProfundidadFigura(puntos, ListaColores);

            //Algoritmo de pintor.
            //Ordena del polígono más alejado al más cercano,
            //los polígonos de adelante son visibles y los de atrás son borrados.
            poligonos.Sort((p1, p2) => p1.Centro.CompareTo(p2.Centro));
        }

        //Dibuja la figura 3D
        public void Dibuja(Graphics lienzo) {
            for (int Cont = 0; Cont < poligonos.Count; Cont++)
                poligonos[Cont].Dibuja(lienzo);
        }
    }
}

