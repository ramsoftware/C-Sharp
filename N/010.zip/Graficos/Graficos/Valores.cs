﻿namespace Graficos {
	public partial class Valores : Form {

		Form1 FrmGrafico = new();
		const double Radianes = Math.PI / 180;
		public Valores() {
			InitializeComponent();

			FrmGrafico.AnguloX = Convert.ToDouble(numGiroX.Value) * Radianes;
			FrmGrafico.AnguloY = Convert.ToDouble(numGiroY.Value) * Radianes;
			FrmGrafico.AnguloZ = Convert.ToDouble(numGiroZ.Value) * Radianes;
			FrmGrafico.Xini = Convert.ToDouble((double)numMinimoX.Value);
			FrmGrafico.Yini = Convert.ToDouble((double)numMinimoY.Value);
			FrmGrafico.Xfin = Convert.ToDouble((double)numMaximoX.Value);
			FrmGrafico.Yfin = Convert.ToDouble((double)numMaximoY.Value);
			FrmGrafico.Tini = Convert.ToDouble((double)numMinimoT.Value);
			FrmGrafico.Tfin = Convert.ToDouble((double)numMaximoT.Value);
			FrmGrafico.Tavance = Convert.ToDouble((double)numAvanceT.Value);


			FrmGrafico.NumLineas = Convert.ToInt32((double)numTotalLineas.Value);
			FrmGrafico.Ecuacion = txtEcuacion.Text;
			FrmGrafico.ZPersona = 5;

			FrmGrafico.Show();
		}

		private void numGiroX_ValueChanged(object sender, EventArgs e) {
			FrmGrafico.AnguloX = Convert.ToDouble(numGiroX.Value) * Radianes;
			FrmGrafico.Refresh();
		}

		private void numGiroY_ValueChanged(object sender, EventArgs e) {
			FrmGrafico.AnguloY = Convert.ToDouble(numGiroY.Value) * Radianes;
			FrmGrafico.Refresh();
		}

		private void numGiroZ_ValueChanged(object sender, EventArgs e) {
			FrmGrafico.AnguloZ = Convert.ToDouble(numGiroZ.Value) * Radianes;
			FrmGrafico.Refresh();
		}

		private void numMinimoX_ValueChanged(object sender, EventArgs e) {
			if (numMinimoX.Value >= numMaximoX.Value)
				numMinimoX.Value = numMaximoX.Value - 1;

			FrmGrafico.Xini = Convert.ToDouble((double)numMinimoX.Value);
			FrmGrafico.Refresh();
		}

		private void numMinimoY_ValueChanged(object sender, EventArgs e) {
			if (numMinimoY.Value >= numMaximoY.Value)
				numMinimoY.Value = numMaximoY.Value - 1;

			FrmGrafico.Yini = Convert.ToDouble((double)numMinimoY.Value);
			FrmGrafico.Refresh();
		}

		private void numMaximoX_ValueChanged(object sender, EventArgs e) {
			if (numMinimoX.Value >= numMaximoX.Value)
				numMaximoX.Value = numMinimoX.Value + 1;

			FrmGrafico.Xfin = Convert.ToDouble((double)numMaximoX.Value);
			FrmGrafico.Refresh();
		}

		private void numMaximoY_ValueChanged(object sender, EventArgs e) {
			if (numMinimoY.Value >= numMaximoY.Value)
				numMaximoY.Value = numMinimoY.Value + 1;

			FrmGrafico.Yfin = Convert.ToDouble((double)numMaximoY.Value);
			FrmGrafico.Refresh();
		}

		private void numTotalLineas_ValueChanged(object sender, EventArgs e) {
			FrmGrafico.NumLineas = Convert.ToInt32((double)numTotalLineas.Value);
			FrmGrafico.Refresh();
		}

		private void btnProcesar_Click(object sender, EventArgs e) {
			FrmGrafico.Ecuacion = txtEcuacion.Text;
			FrmGrafico.Refresh();
		}

		private void numMinimoT_ValueChanged(object sender, EventArgs e) {
			if (numMinimoY.Value >= numMaximoY.Value)
				numMinimoY.Value = numMaximoY.Value - 1;

			FrmGrafico.Tini = Convert.ToDouble((double)numMinimoT.Value);
			FrmGrafico.valorT = FrmGrafico.Tini + 0.01;
			FrmGrafico.Refresh();
		}

		private void numMaximoT_ValueChanged(object sender, EventArgs e) {
			if (numMinimoY.Value >= numMaximoY.Value)
				numMaximoY.Value = numMinimoY.Value + 1;

			FrmGrafico.Tfin = Convert.ToDouble((double)numMaximoT.Value);
			FrmGrafico.valorT = FrmGrafico.Tini + 0.01;
			FrmGrafico.Refresh();
		}

		private void numAvanceT_ValueChanged(object sender, EventArgs e) {
			FrmGrafico.Tavance = Convert.ToDouble((double)numAvanceT.Value);
			FrmGrafico.Refresh();
		}
	}
}
