﻿using System.Globalization;
using System.Text;

/* Evaluador de expresiones versión 4.1 (diciembre de 2025)
 * Autor: Rafael Alberto Moreno Parra
 * Correo: ramsoftware@gmail.com ;  enginelife@hotmail.com
 * URL: http://darwin.50webs.com 
 * GitHub: https://github.com/ramsoftware
 * */
namespace Chequear {

    public class Evaluador4_1 {
        /* Donde guarda los valores de variables, Constantes4_1 y piezas */
        public List<double> Valores;

        /* Listado de partes en que se divide la expresión
		   Toma una expresión, por ejemplo:
		   1.68 + sen( 3 / x ) * ( 2.92 - 9 )
		   y la divide en partes así:
		   [1.68] [+] [sen(] [3] [/] [x] [)] [*] [(] [2.92] [-] [9] [)]
		   Cada parte puede tener un número, un operador, una función,
		   un paréntesis que abre o un paréntesis que cierra.
		   En esta versión 4.1, las Constantes4_1, piezas y variables guardan
		   sus valores en la lista Valores.
		   En partes, se almacena la posición en Valores */
        public List<ParteEvl4_1> Partes;

        /* Listado de piezas que ejecutan
			Toma las partes y las divide en piezas con 
			la siguiente estructura:

			acumula = funcion valor operador valor

			donde valor puede ser un número, una variable o 
			un acumulador
			
			Siguiendo el ejemplo anterior sería:
			A =  2.92 - 9
			B =  sen( 3 / x )
			C =  B * A
			D =  1.68 + C

		   Esas piezas se evalúan de arriba a abajo y así
		   se interpreta la ecuación */
        public List<PiezaEvl4_1> Piezas;

        /* Evaluar la sintaxis */
        public Sintaxis4_1 objSintaxis;

        /* Constructor */
        public Evaluador4_1() {
            this.Valores = [];
            this.Partes = [];
            this.Piezas = [];
            this.objSintaxis = new();
        }

        /* Analiza la expresión */
        public bool Analizar(string ExpresionOriginal) {
            if (objSintaxis.ChequeaSintaxis(ExpresionOriginal)) {
                CrearPartes(objSintaxis.ExpresionConvertida);
                CrearPiezas();
                return true;
            }
            return false;
        }

        /* Da valor a las variables que tendrá
		 * la expresión algebraica */
        public void DarValorVariable(char varAlgebra, double Valor) {
            Valores[varAlgebra - 'a'] = Valor;
        }

        /* Evalúa la expresión convertida en piezas */
        public double Evaluar() {
            double Resulta = 0;
            PiezaEvl4_1 tmp;

            /* Va de pieza en pieza */
            int TotalPiezas = Piezas.Count;
            for (int Posicion = 0; Posicion < TotalPiezas; Posicion++) {
                tmp = Piezas[Posicion];

                // Cacheo de operandos para menos indirections
                double a = Valores[tmp.pA];
                double b = Valores[tmp.pB];

                // Operación binaria (mantiene tu lógica original)
                Resulta = tmp.Operador switch {
                    Constantes4_1.SUMA => a + b,
                    Constantes4_1.RESTA => a - b,
                    Constantes4_1.MULTIPLICA => a * b,
                    Constantes4_1.DIVIDE => a / b,
                    _ => Math.Pow(a, b),
                };

                switch (tmp.Funcion) {
                    case Constantes4_1.SENO_COD: Resulta = Math.Sin(Resulta); break;
                    case Constantes4_1.COSENO_COD: Resulta = Math.Cos(Resulta); break;
                    case Constantes4_1.TANGENTE_COD: Resulta = Math.Tan(Resulta); break;
                    case Constantes4_1.VALORABSOLUTO_COD: Resulta = Math.Abs(Resulta); break;
                    case Constantes4_1.ARCOSENO_COD: Resulta = Math.Asin(Resulta); break;
                    case Constantes4_1.ARCOCOSENO_COD: Resulta = Math.Acos(Resulta); break;
                    case Constantes4_1.ARCOTANGENTE_COD: Resulta = Math.Atan(Resulta); break;
                    case Constantes4_1.LOGARITMONATURAL_COD: Resulta = Math.Log(Resulta); break;
                    case Constantes4_1.EXPONENCIAL_COD: Resulta = Math.Exp(Resulta); break;
                    case Constantes4_1.RAIZCUADRADA_COD: Resulta = Math.Sqrt(Resulta); break;
                    default:
                        break;
                }

                Valores[tmp.PosResultado] = Resulta;
            }
            return Resulta;
        }

        /* Convierte las partes en las piezas finales de ejecución */
        private void CrearPiezas() {
            Piezas.Clear();

            int Contador = Partes.Count - 1;
            do {
                if (Partes[Contador].Tipo == Constantes4_1.ESPARABRE) {

                    /* Evalúa las potencias de izquierda a derecha como Excel */
                    GeneraPiezaOpera(Constantes4_1.POTENCIA, Constantes4_1.POTENCIA, Contador);

                    /* Luego evalúa multiplicar y dividir */
                    GeneraPiezaOpera(Constantes4_1.MULTIPLICA, Constantes4_1.DIVIDE, Contador);

                    /* Finalmente evalúa sumar y restar */
                    GeneraPiezaOpera(Constantes4_1.SUMA, Constantes4_1.RESTA, Contador);

                    /* Agrega la función a la última pieza */
                    if (Contador > 0 && Partes[Contador - 1].Tipo == Constantes4_1.ESFUNCION) {
                        Piezas[Piezas.Count - 1].Funcion = Partes[Contador - 1].Funcion;
                        Partes.RemoveAt(Contador - 1);
                        Partes.RemoveAt(Contador - 1);
                        Partes.RemoveAt(Contador);
                    }
                    else {
                        /* Quita el paréntesis que abre y
                         * el que cierra, dejando el centro */
                        Partes.RemoveAt(Contador);
                        Partes.RemoveAt(Contador + 1);
                    }
                }
                Contador--;
            } while (Contador >= 0);
        }

        /* Genera las piezas buscando determinado operador */
        private void GeneraPiezaOpera(int OperA, int OperB, int Inicia) {
            int Contador = Inicia + 1;
            do {
                ParteEvl4_1 tmpParte = Partes[Contador];
                if (tmpParte.Tipo == Constantes4_1.ESOPERADOR &&
                    (tmpParte.Operador == OperA || tmpParte.Operador == OperB)) {
                    ParteEvl4_1 tmpParteIzq = Partes[Contador - 1];
                    ParteEvl4_1 tmpParteDer = Partes[Contador + 1];

                    /* Crea Pieza */
                    PiezaEvl4_1 NuevaPieza = new();
                    NuevaPieza.Funcion = -1;

                    switch (tmpParteIzq.Tipo) {
                        case Constantes4_1.ESNUMERO:
                            NuevaPieza.pA = tmpParteIzq.posNumero;
                            break;

                        case Constantes4_1.ESVARIABLE:
                            NuevaPieza.pA = tmpParteIzq.posVariable;
                            break;

                        default:
                            NuevaPieza.pA = tmpParteIzq.posAcumula;
                            break;
                    }

                    NuevaPieza.Operador = tmpParte.Operador;

                    switch (tmpParteDer.Tipo) {
                        case Constantes4_1.ESNUMERO:
                            NuevaPieza.pB = tmpParteDer.posNumero;
                            break;

                        case Constantes4_1.ESVARIABLE:
                            NuevaPieza.pB = tmpParteDer.posVariable;
                            break;

                        default:
                            NuevaPieza.pB = tmpParteDer.posAcumula;
                            break;
                    }

                    /* Añade a lista de piezas y crea una
					 * nueva posición en Valores */
                    Valores.Add(0);
                    NuevaPieza.PosResultado = Valores.Count - 1;
                    Piezas.Add(NuevaPieza);

                    /* Elimina la parte del operador y la siguiente */
                    Partes.RemoveRange(Contador, 2);

                    /* Retorna el contador en uno para tomar
					 * la siguiente operación */
                    Contador--;

                    /* Cambia la parte anterior por parte que acumula */
                    tmpParteIzq.Tipo = Constantes4_1.ESACUMULA;
                    tmpParteIzq.posAcumula = NuevaPieza.PosResultado;
                }
                Contador++;
            } while (Partes[Contador].Tipo != Constantes4_1.ESPARCIERRA);
        }

        /* Divide la expresión en partes, yendo de caracter en caracter */
        private void CrearPartes(string Expresion) {
            Partes.Clear();

            /* Hace espacio para las 26 variables que
			 * puede manejar el evaluador */
            Valores = Enumerable.Repeat(0.0, 26).ToList();

            StringBuilder Numero = new();
            for (int Pos = 0; Pos < Expresion.Length; Pos++) {
                char Letra = Expresion[Pos];
                switch (Letra) {
                    case '.':
                    case '0':
                    case '1':
                    case '2':
                    case '3':
                    case '4':
                    case '5':
                    case '6':
                    case '7':
                    case '8':
                    case '9':   /* Si es un digito o un punto 
								 * va acumulando el número */
                        Numero.Append(Letra); break;
                    case '+':
                    case '-':
                    case '*':
                    case '/':
                    case '^':
                        /* Si es un operador matemático entonces verifica
						 * si hay un número que se ha acumulado */
                        if (Numero.Length > 0) {
                            Valores.Add(double.Parse(Numero.ToString(), CultureInfo.InvariantCulture));
                            Partes.Add(new ParteEvl4_1(Constantes4_1.ESNUMERO, Valores.Count - 1));
                            Numero.Clear();
                        }
                        /* Agregar el operador matemático */
                        Partes.Add(new ParteEvl4_1(Letra));
                        break;

                    case '(':   /* Es paréntesis que abre */
                        Partes.Add(new ParteEvl4_1(Constantes4_1.ESPARABRE, 0));
                        break;

                    case ')':
                        /* Si es un paréntesis que cierra entonces verifica
						 * si hay un número que se ha acumulado */
                        if (Numero.Length > 0) {
                            Valores.Add(double.Parse(Numero.ToString(), CultureInfo.InvariantCulture));
                            Partes.Add(new ParteEvl4_1(Constantes4_1.ESNUMERO, Valores.Count - 1));
                            Numero.Clear();
                        }

                        /* Si sólo había un número o variable
						 * dentro del paréntesis le agrega + 0
						 * (por ejemplo:  sen(x) o 3*(2) ) */
                        if (Partes[Partes.Count - 2].Tipo == Constantes4_1.ESPARABRE) {
                            Partes.Add(new ParteEvl4_1(Constantes4_1.ESOPERADOR, 0));
                            Valores.Add(0);
                            Partes.Add(new ParteEvl4_1(Constantes4_1.ESNUMERO, Valores.Count - 1));
                        }

                        /* Adiciona el paréntesis que cierra */
                        Partes.Add(new ParteEvl4_1(Constantes4_1.ESPARCIERRA, 0));
                        break;
                    case 'A':   /* Seno */
                    case 'B':   /* Coseno */
                    case 'C':   /* Tangente */
                    case 'D':   /* Valor absoluto */
                    case 'E':   /* Arcoseno */
                    case 'F':   /* Arcocoseno */
                    case 'G':   /* Arcotangente */
                    case 'H':   /* Logaritmo natural */
                    case 'I':   /* Exponencial */
                    case 'J':   /* Raíz cuadrada */
                        Partes.Add(new ParteEvl4_1(Constantes4_1.ESFUNCION, Letra - 'A'));
                        break;
                    default:
                        Partes.Add(new ParteEvl4_1(Constantes4_1.ESVARIABLE, Letra - 'a'));
                        break;
                }
            }
        }
    }
}
