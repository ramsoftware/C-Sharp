﻿/* Evaluador de expresiones versión 4.1 (diciembre de 2025)
 * Autor: Rafael Alberto Moreno Parra
 * Correo: ramsoftware@gmail.com ;  enginelife@hotmail.com
 * URL: http://darwin.50webs.com 
 * GitHub: https://github.com/ramsoftware
 * */

namespace Chequear {
    public class PiezaEvl4_1 {
        /* Posición donde se almacena el valor que genera
		 * la pieza al evaluarse */
        public int PosResultado;

        /* Código de la función 0:seno, 1:coseno, 2:tangente,
		 * 3: valor absoluto, 4: arcoseno, 5: arcocoseno,
		 * 6: arcotangente, 7: logaritmo natural, 8: valor tope,
		 * 9: exponencial, 10: raíz cuadrada */
        public int Funcion;

        /* Posición donde se almacena la primera parte de la pieza */
        public int pA;

        /* 0 suma 1 resta 2 multiplicación 3 división 4 potencia */
        public int Operador;

        /* Posición donde se almacena la segunda parte de la pieza */
        public int pB;
    }
}
