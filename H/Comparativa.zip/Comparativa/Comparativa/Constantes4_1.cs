﻿/* Evaluador de expresiones versión 4.1 (diciembre de 2025)
 * Autor: Rafael Alberto Moreno Parra
 * Correo: ramsoftware@gmail.com ;  enginelife@hotmail.com
 * URL: http://darwin.50webs.com 
 * GitHub: https://github.com/ramsoftware
 * */

namespace Comparativa {
    public static class Constantes4_1 {
        /* Constantes de los diferentes tipos 
		 * de datos que tendrán las partes y piezas */
        public const int ESFUNCION = 1;
        public const int ESPARABRE = 2;
        public const int ESPARCIERRA = 3;
        public const int ESOPERADOR = 4;
        public const int ESNUMERO = 5;
        public const int ESVARIABLE = 6;
        public const int ESACUMULA = 7;

        public const int POTENCIA = 4;
        public const int DIVIDE = 3;
        public const int MULTIPLICA = 2;
        public const int RESTA = 1;
        public const int SUMA = 0;

        public const string SENO = "A";
        public const string COSENO = "B";
        public const string TANGENTE = "C";
        public const string VALORABSOLUTO = "D";
        public const string ARCOSENO = "E";
        public const string ARCOCOSENO = "F";
        public const string ARCOTANGENTE = "G";
        public const string LOGARITMONATURAL = "H";
        public const string EXPONENCIAL = "I";
        public const string RAIZCUADRADA = "J";

        public const int NO_FUNCION_COD = -1;
        public const int SENO_COD = 0;
        public const int COSENO_COD = 1;
        public const int TANGENTE_COD = 2;
        public const int VALORABSOLUTO_COD = 3;
        public const int ARCOSENO_COD = 4;
        public const int ARCOCOSENO_COD = 5;
        public const int ARCOTANGENTE_COD = 6;
        public const int LOGARITMONATURAL_COD = 7;
        public const int EXPONENCIAL_COD = 8;
        public const int RAIZCUADRADA_COD = 9;
    }
}