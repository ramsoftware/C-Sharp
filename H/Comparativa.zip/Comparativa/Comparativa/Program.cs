﻿using System.Diagnostics;

//Comparar los dos evaluadores
namespace Comparativa {
    internal class Program {

        const int ANCHO_ANALISIS = 10; // ancho de la columna "Análisis"
        const int ANCHO_EVALUA = 10; // ancho de la columna "Evalúa"

        static void Main(string[] args) {
            long TAnalisisEval4_1 = 0, TEvaluaEval4_1 = 0;
            long TAnalisisEval4 = 0, TEvaluaEval4 = 0;
            long TAnalisisArbol = 0, TEvaluaArbol = 0;

            EvalArbolBin arbol = new();
            Evaluador4 eval4 = new();
            Evaluador4_1 eval4_1 = new();
            EcuacionAzar ecu = new();

            //Toma el tiempo
            Stopwatch temporizador = new();

            //Parámetros
            int TotalEcuaciones = 700;
            int VecesEvalua = 3000;
            int Tamano = 400;

            //Valores de X al azar
            double[] valX = new double[VecesEvalua];
            Random azar = new();

            for (int cont = 1; cont <= TotalEcuaciones; cont++) {
                //Ecuación al azar
                string Ecuacion = ecu.Ecuacion(Tamano);

                //Valores de X al azar
                for (int xvalor = 0; xvalor < valX.Length; xvalor++) {
                    valX[xvalor] = azar.NextDouble() - azar.NextDouble();
                }

                //Analiza la expresión con el árbol binario
                temporizador.Reset();
                temporizador.Start();
                arbol.Analizar(Ecuacion);
                temporizador.Stop();
                TAnalisisArbol += temporizador.ElapsedTicks;

                //Analiza la expresión con el evaluador 4.0
                temporizador.Reset();
                temporizador.Start();
                eval4.Analizar(Ecuacion);
                temporizador.Stop();
                TAnalisisEval4 += temporizador.ElapsedTicks;

                //Analiza la expresión con el evaluador 4.1
                temporizador.Reset();
                temporizador.Start();
                eval4_1.Analizar(Ecuacion);
                temporizador.Stop();
                TAnalisisEval4_1 += temporizador.ElapsedTicks;

                //Evalúa la expresión con el árbol binario
                temporizador.Reset();
                temporizador.Start();
                double ResArbol = 0;
                for (int xvalor = 0; xvalor < valX.Length; xvalor++) {
                    arbol.DarValorVariable('x', valX[xvalor]);
                    ResArbol += arbol.Evaluar();
                }
                temporizador.Stop();
                TEvaluaArbol += temporizador.ElapsedTicks;

                //Evalúa la expresión con el evaluador 4.0
                temporizador.Reset();
                temporizador.Start();
                double ResEval4 = 0;
                for (int xvalor = 0; xvalor < valX.Length; xvalor++) {
                    eval4.DarValorVariable('x', valX[xvalor]);
                    ResEval4 += eval4.Evaluar();
                }
                temporizador.Stop();
                TEvaluaEval4 += temporizador.ElapsedTicks;

                //Evalúa la expresión con el evaluador 4.0
                temporizador.Reset();
                temporizador.Start();
                double ResEval4_1 = 0;
                for (int xvalor = 0; xvalor < valX.Length; xvalor++) {
                    eval4_1.DarValorVariable('x', valX[xvalor]);
                    ResEval4_1 += eval4_1.Evaluar();
                }
                temporizador.Stop();
                TEvaluaEval4_1 += temporizador.ElapsedTicks;

                //Chequea si hay una diferencia entre ambos evaluadores
                if (Math.Abs(ResArbol - ResEval4) > 0.01 || Math.Abs(ResArbol - ResEval4_1) > 0.01) {
                    Console.WriteLine(Ecuacion);
                    Console.WriteLine("Arbol:   " + ResArbol);
                    Console.WriteLine("Eval4:   " + ResEval4);
                    Console.WriteLine("Eval4_1: " + ResEval4_1);
                    break;
                }
            }

            Console.WriteLine("Tamaño ecuación: " + Tamano);
            Console.WriteLine("Total ecuaciones: " + TotalEcuaciones);
            Console.WriteLine("Veces evalúa: " + VecesEvalua);
            Console.WriteLine("\r\n[Eval4_1  ] Análisis: {0," + ANCHO_ANALISIS + "}    Evalúa: {1," + ANCHO_EVALUA + "}",
                TAnalisisEval4_1, TEvaluaEval4_1);
            Console.WriteLine("\r\n[Eval4    ] Análisis: {0," + ANCHO_ANALISIS + "}    Evalúa: {1," + ANCHO_EVALUA + "}",
                TAnalisisEval4, TEvaluaEval4);
            Console.WriteLine("\r\n[Árbol    ] Análisis: {0," + ANCHO_ANALISIS + "}    Evalúa: {1," + ANCHO_EVALUA + "}",
                TAnalisisArbol, TEvaluaArbol);
            Console.WriteLine("FIN");
        }
    }
}
