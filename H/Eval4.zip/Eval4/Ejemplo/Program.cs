﻿namespace Ejemplo {
    internal class Program {
        static void Main() {
            //Instancia el evaluador
            Evaluador4 evaluador = new();

            //Ejemplo 1: Una expresión simple 
            string Ecuacion = "8*5+1-7/4+2^3";
            evaluador.Analizar(Ecuacion);
            double valorY = evaluador.Evaluar();
            Console.WriteLine("Ejemplo 1: " + valorY);

            //Ejemplo 2: Una expresión simple con números reales 
            Ecuacion = "7.318+5.0045-9.071^2*8.04961";
            evaluador.Analizar(Ecuacion);
            valorY = evaluador.Evaluar();
            Console.WriteLine("Ejemplo 2: " + valorY);

            //Ejemplo 3: Una expresión con paréntesis 
            Ecuacion = "5*(3+2.5)";
            Ecuacion += "-7/(8.03*2-5^3)";
            Ecuacion += "+4.1*(3-(5.8*2.3))";
            evaluador.Analizar(Ecuacion);
            valorY = evaluador.Evaluar();
            Console.WriteLine("Ejemplo 3: " + valorY);

            //Ejemplo 4: Una expresión con funciones 
            Ecuacion = "sen(4.90+2.34)-cos(1.89)";
            Ecuacion += "*tan(3)/abs(4-12)+asn(0.12)";
            Ecuacion += "-acs(0-0.4)+atn(0.03)*log(1.3)";
            Ecuacion += "+sqr(3.4)+exp(2.8)-sqr(9)";
            evaluador.Analizar(Ecuacion);
            valorY = evaluador.Evaluar();
            Console.WriteLine("Ejemplo 4: " + valorY);

            //Ejemplo 5: Una expresión con uso de variables
            //(deben estar en minúsculas)
            Ecuacion = "3*x+2*y";
            evaluador.Analizar(Ecuacion);

            //Le da valor a las variables
            evaluador.DarValorVariable('x', 1.8);
            evaluador.DarValorVariable('y', 3.5);
            valorY = evaluador.Evaluar();
            Console.WriteLine("Ejemplo 5: " + valorY);

            //Una expresión con uso de variables
            Console.WriteLine("\r\n\r\n===== MULTIPLES VALORES =====");

            Random Azar = new();
            Ecuacion = "3*cos(2*x+4)-5*sen(4*y-7)";
            evaluador.Analizar(Ecuacion);

            //Después de ser analizada, se le dan los 
            //valores a las variables, esto hace que
            //el evaluador sea muy rápido
            for (int cont = 1; cont <= 20; cont++) {
                evaluador.DarValorVariable('x', Azar.NextDouble());
                evaluador.DarValorVariable('y', Azar.NextDouble());
                valorY = evaluador.Evaluar();
                Console.WriteLine(valorY);
            }

            Console.WriteLine("\r\n\r\n===== VALIDANDO SINTAXIS =====");
            string[] expAlg = new string[] {
                "2q-(*3)", //0
				"7-2(5-6)", //1
				"3..1", //2
				"3.*1", //3
				"3+5.w-8", //4
				"2-5.(4+1)*3", //5
				"2-(5.)*3", //6
				"2-(4+.1)-7", //7
				"5-*3", //8
				"2-(4+)-7", //9
				"7-a2-6", //10
				"7-a.4*3", //11
				"7-qw*9", //12
				"2-u(7-3)", //13
				"7-(.8+4)-6", //14
				"(+3-5)*7", //15
				"4+()*2", //16
				"(3-5)8", //17
				"(3-5).+2", //18
				"2-(7*3)k+7", //19
				"(4-3)(2+1)", //20
				"*3+5", //21
				"3*5*", //22
				"9*4)+(2-6", //23
				"((2+4)", //24
				"2.71*3.56.01", //25
                "3-cei(6)"}; //13

            for (int num = 0; num < expAlg.Length; num++) {
                Console.WriteLine("\r\nExpr " + num + ": " + expAlg[num]);
                int Sintaxis = evaluador.Analizar(expAlg[num]);
                if (Sintaxis >= 0) {
                    Console.WriteLine(evaluador.MensajeError(Sintaxis));
                }
            }
        }
    }
}
