﻿/* Evaluador de expresiones versión 4.1 (diciembre de 2025)
 * Autor: Rafael Alberto Moreno Parra
 * Correo: ramsoftware@gmail.com ;  enginelife@hotmail.com
 * URL: http://darwin.50webs.com 
 * GitHub: https://github.com/ramsoftware
 * */
namespace Ejemplo {
    internal class Program {
        static void Main() {
            Evaluador4_1 Evalua4_1 = new();

            Console.WriteLine("\r\n\r\n===== VALIDANDO SINTAXIS =====");
            string[] expAlg = new string[] {
                "2+8..4-3",
				"7-2(3+.y-6)",
				"7-3**8+9",
				"34.1-8+(9-)*2",
				"89-t5+1.31",
                "4/p.12+9",
                "2+hu-3.4",
                "9-(*2+4)",
                "9.02-7*()+4",
                "/3*7",
                "9-61/",
                "9+3))-((2+9",
                "(7-8)(3+1+(3*4)",
                "9.03.2+8.0121",
                "0.4-cos(3*x+2)/(2*x)-tan(7/0.8*x+3)+9.012/x^2+3*x-7.02*x"
            };

            for (int num = 0; num < expAlg.Length; num++) {
                Console.WriteLine("\r\nExpr " + num + ": " + expAlg[num]);

                if (Evalua4_1.Analizar(expAlg[num])) {
                    Console.WriteLine("Sintaxis correcta");
                }
                else {
                    List<string> Errores = Evalua4_1.objSintaxis.ObtenerMensajesErrores();
                    for (int i = 0; i < Errores.Count; i++) {
                        Console.WriteLine("Error: " + Errores[i]);
                    }
                }
            }

            //Ejemplo 1: Una expresión simple 
            string Ecuacion = "3+(4)-(5)+(6)-(7)";
            Evalua4_1.Analizar(Ecuacion);
            double valorY = Evalua4_1.Evaluar();
            Console.WriteLine("Ejemplo 1: " + valorY);

            //Ejemplo 2: Una expresión simple con números reales 
            Ecuacion = "7.318/5.0045-9.071^2*8.04961";
            Evalua4_1.Analizar(Ecuacion);
            valorY = Evalua4_1.Evaluar();
            Console.WriteLine("Ejemplo 2: " + valorY);

            //Ejemplo 3: Una expresión con paréntesis 
            Ecuacion = "(3+2)-7";
            Evalua4_1.Analizar(Ecuacion);
            valorY = Evalua4_1.Evaluar();
            Console.WriteLine("Ejemplo 3: " + valorY);

            //Ejemplo 4: Una expresión con funciones 
            Ecuacion = "sen(4.90+2.34)-cos(1.89)";
            Ecuacion += "*tan(3)/abs(4-12)+asn(0.12)";
            Ecuacion += "-acs(0-0.4)+atn(0.03)*log(1.3)";
            Ecuacion += "+sqr(3.4)+exp(2/8)-sqr(9)";
            Evalua4_1.Analizar(Ecuacion);
            valorY = Evalua4_1.Evaluar();
            Console.WriteLine("Ejemplo 4: " + valorY);

            //Ejemplo 5: Una expresión con uso de variables
            //(deben estar en minúsculas)
            Ecuacion = "3*x+2*y";
            Evalua4_1.Analizar(Ecuacion);

            //Le da valor a las variables
            Evalua4_1.DarValorVariable('x', 1.8);
            Evalua4_1.DarValorVariable('y', 3.5);
            valorY = Evalua4_1.Evaluar();
            Console.WriteLine("Ejemplo 5: " + valorY);

            //Una expresión con uso de variables
            Console.WriteLine("\r\n\r\n===== MULTIPLES VALORES =====");

            Ecuacion = "3*cos(2*x+4)-5*sen(4*y-7)";
            Evalua4_1.Analizar(Ecuacion);

            //Después de ser analizada, se le dan los 
            //valores a las variables, esto hace que
            //el evaluador sea muy rápido
            Random Azar = new();
            for (int cont = 1; cont <= 20; cont++) {
                double X = Azar.NextDouble();
                double Y = Azar.NextDouble();
                Evalua4_1.DarValorVariable('x', X);
                Evalua4_1.DarValorVariable('y', Y);
                valorY = Evalua4_1.Evaluar();
                Console.WriteLine(valorY);
            }
        }
    }
}
