﻿using System.Text;
using System.Text.RegularExpressions;

/* Evaluador de expresiones versión 4.1 (diciembre de 2025)
 * Autor: Rafael Alberto Moreno Parra
 * Correo: ramsoftware@gmail.com ;  enginelife@hotmail.com
 * URL: http://darwin.50webs.com 
 * GitHub: https://github.com/ramsoftware
 * */

namespace Ejemplo {
    public class Sintaxis4_1 {
        /* HashSet estático para caracteres válidos (se crea una sola vez) */
        private static readonly HashSet<char> CaracteresValidos =
            [.. "abcdefghijklmnopqrstuvwxyz0123456789.+-*/^()"];

        /* Diccionario para reemplazos de funciones en expresión analizada */
        private static readonly Dictionary<string, string> ReemplazosFunciones = new()
        {
            {"sen", Constantes4_1.SENO}, {"cos", Constantes4_1.COSENO}, {"tan", Constantes4_1.TANGENTE},
            {"abs", Constantes4_1.VALORABSOLUTO}, {"asn", Constantes4_1.ARCOSENO}, {"acs", Constantes4_1.ARCOCOSENO},
            {"atn", Constantes4_1.ARCOTANGENTE}, {"log", Constantes4_1.LOGARITMONATURAL}, {"exp", Constantes4_1.EXPONENCIAL},
            {"sqr", Constantes4_1.RAIZCUADRADA}
        };

        /* Diccionario estático para mensajes de error */
        private static readonly Dictionary<int, string> MensajesError = new()
        {
            {0, "0. Es correcta"},
            {1, "1. Doble punto seguido"},
            {2, "2. Punto y sigue una letra"},
            {3, "3. Dos operadores estén seguidos"},
            {4, "4. Operador seguido de paréntesis que cierra"},
            {5, "5. Letra seguida de número"},
            {6, "6. Letra seguida de punto"},
            {7, "7. Letra seguida de otra letra"},
            {8, "8. Paréntesis que abre y sigue operador"},
            {9, "9. Paréntesis que abre y luego cierra"},
            {10, "10. Inicia con operador"},
            {11, "11. Finaliza con operador"},
            {12, "12. No hay correspondencia entre paréntesis"},
            {13, "13. Paréntesis desbalanceados"},
            {14, "14. Dos o más puntos en número real"}
        };

        /* HashSet estático para operadores (más rápido que switch) */
        private static readonly HashSet<char> Operadores = new() { '+', '-', '*', '/', '^' };

        /* Arreglo de mensajes de error */
        private int[] TipoError = new int[15];

        /* Expresión convertida y validada */
        public string ExpresionConvertida { get; private set; } = string.Empty;

        /* Convierte y chequea la expresión */
        public bool ChequeaSintaxis(string ExpresionOriginal) {
            /* Paso 1: Convierte la expresión */
            Convierte(ExpresionOriginal);

            /* Inicializa el arreglo de errores */
            Array.Fill(TipoError, 0);

            /* Paso 2: Chequea sintaxis */
            ValidaCaracteresSeguidos(ExpresionConvertida);
            ValidaInicioYFinDeLaExpresion(ExpresionConvertida);
            ValidaParentesisDesbalanceados(ExpresionConvertida);
            ValidaPuntosEnNumeroReal(ExpresionConvertida);

            /* Si una sola celda es 1, hay error */
            for (int Cont = 0; Cont < TipoError.Length; Cont++) {
                if (TipoError[Cont] == 1) {
                    return false;
                }
            }
            return true;
        }

        public List<string> ObtenerMensajesErrores() {
            List<string> mensajes = new();
            for (int i = 1; i < TipoError.Length; i++) {
                if (TipoError[i] == 1) {
                    mensajes.Add(MensajeError(i));
                }
            }
            return mensajes;
        }

        /* Paso 1: Convertir la expresión para poder analizarla */
        private void Convierte(string ExpresionOriginal) {
            /* Primero a minúsculas */
            string Minusculas = ExpresionOriginal.ToLower();

            /* Sólo los caracteres válidos (optimizado con HashSet estático) */
            StringBuilder ConLetrasValidas = new("(");
            foreach (char c in Minusculas) {
                if (CaracteresValidos.Contains(c))
                    ConLetrasValidas.Append(c);
            }
            ConLetrasValidas.Append(')');

            /* Reemplazos de funciones usando diccionario */
            foreach (var reemplazo in ReemplazosFunciones) {
                ConLetrasValidas.Replace(reemplazo.Key, reemplazo.Value);
            }

            /* Agrega +0) donde exista )) porque es 
			 * necesario para crear las piezas */
            ConLetrasValidas.Replace("))", ")+0)");

            /* Convierte de (- a (0- para dar apoyo al menos unario */
            ConLetrasValidas.Replace("(-", "(0-");

            /* Convierte de )( a )*( */
            ConLetrasValidas.Replace(")(", ")*(");

            /* Convierte de punto operador a punto cero operador */
            ConLetrasValidas.Replace(".+", ".0+");
            ConLetrasValidas.Replace(".-", ".0-");
            ConLetrasValidas.Replace(".*", ".0*");
            ConLetrasValidas.Replace("./", ".0/");
            ConLetrasValidas.Replace(".^", ".0^");

            /* Convierte de operador punto a operador cero punto */
            ConLetrasValidas.Replace("+.", "+0.");
            ConLetrasValidas.Replace("-.", "-0.");
            ConLetrasValidas.Replace("*.", "*0.");
            ConLetrasValidas.Replace("/.", "/0.");
            ConLetrasValidas.Replace("^.", "^0.");

            /* Convierte de .( a .0*( */
            ConLetrasValidas.Replace(".(", ".0*(");

            /* Convierte de ). a )*0. */
            ConLetrasValidas.Replace(").", ")*0.");

            /* Convierte de .) a .0) */
            ConLetrasValidas.Replace(".)", ".0)");

            /* Convierte de (. a (0. */
            ConLetrasValidas.Replace("(.", "(0.");

            /* Convierte a cadena para hacer uso del regex */
            ExpresionConvertida = ConLetrasValidas.ToString();

            /* Convierte número letra en número * letra */
            ExpresionConvertida = Regex.Replace(ExpresionConvertida, @"(\d)([a-z])", "$1*$2");

            /* Convierte número( en número*( */
            ExpresionConvertida = Regex.Replace(ExpresionConvertida, @"(\d)\(", "$1*(");

            /* Convierte )numero en )*numero */
            ExpresionConvertida = Regex.Replace(ExpresionConvertida, @"\)(\d+)", @")*$1");

            /* Convierte de )letra en )*letra */
            ExpresionConvertida = Regex.Replace(ExpresionConvertida, @"\)([a-zA-Z])", @")*$1");

            /* Convierte de letra minúscula( a letra minúscula*( */
            ExpresionConvertida = Regex.Replace(ExpresionConvertida, @"([a-z])\(", @"$1*(");
        }

        /* Retorna mensaje de error sintáctico */
        private string MensajeError(int CodigoError) =>
            MensajesError.TryGetValue(CodigoError, out string? mensaje)
                ? mensaje
                : "Error desconocido";


        /* Retorna si el Caracter es un operador matemático */
        private static bool EsUnOperador(char Caracter) => Operadores.Contains(Caracter);

        /* Valida casos de dos caracteres seguidos */
        private void ValidaCaracteresSeguidos(string Expresion) {
            for (int Cont = 0; Cont < Expresion.Length - 1; Cont++) {
                char carA = Expresion[Cont];
                char carB = Expresion[Cont + 1];

                if (carA == '.' && carB == '.') TipoError[1] = 1;
                if (carA == '.' && char.IsLower(carB)) TipoError[2] = 1;
                if (EsUnOperador(carA) && EsUnOperador(carB)) TipoError[3] = 1;
                if (EsUnOperador(carA) && carB == ')') TipoError[4] = 1;
                if (char.IsLower(carA) && char.IsDigit(carB)) TipoError[5] = 1;
                if (char.IsLower(carA) && carB == '.') TipoError[6] = 1;
                if (char.IsLower(carA) && char.IsLower(carB)) TipoError[7] = 1;
                if (carA == '(' && EsUnOperador(carB)) TipoError[8] = 1;
                if (carA == '(' && carB == ')') TipoError[9] = 1;
            }
        }

        /* Valida el inicio y fin de la expresión */
        private void ValidaInicioYFinDeLaExpresion(string Expresion) {
            if (EsUnOperador(Expresion[1])) {
                TipoError[10] = 1;
            }
            if (EsUnOperador(Expresion[Expresion.Length - 2])) {
                TipoError[11] = 1;
            }
        }

        /* Valida si hay paréntesis desbalanceados */
        private void ValidaParentesisDesbalanceados(string Expresion) {
            int Balance = 0;
            for (int Cont = 0; Cont < Expresion.Length; Cont++) {
                if (Expresion[Cont] == '(') Balance++;
                if (Expresion[Cont] == ')') Balance--;
                if (Balance < 0) {
                    TipoError[12] = 1;
                    return;
                }
            }
            if (Balance != 0) {
                TipoError[13] = 1;
            }
        }

        /* Validar los puntos decimales de un número real */
        private void ValidaPuntosEnNumeroReal(string Expresion) {
            int TotalPuntos = 0;
            for (int Cont = 0; Cont < Expresion.Length; Cont++) {
                if (EsUnOperador(Expresion[Cont])) TotalPuntos = 0;
                if (Expresion[Cont] == '.') TotalPuntos++;
                if (TotalPuntos > 1) {
                    TipoError[14] = 1;
                    return;
                }
            }
        }
    }
}