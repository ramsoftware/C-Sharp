﻿/* Evaluador de expresiones versión 4.1 (diciembre de 2025)
 * Autor: Rafael Alberto Moreno Parra
 * Correo: ramsoftware@gmail.com ;  enginelife@hotmail.com
 * URL: http://darwin.50webs.com 
 * GitHub: https://github.com/ramsoftware
 * */

namespace Ejemplo {
    /* Partes en que se divide la expresión
       Toma una expresión, por ejemplo:
       1.68 + sen( 3 / x ) * ( 2.92 - 9 )
       y la divide en partes así:
       [1.68] [+] [sen(] [3] [/] [x] [)] [*] [(] [2.92] [-] [9] [)]
       Cada parte puede tener un número, un operador, una función,
       un paréntesis que abre o un paréntesis que cierra.
       En esta versión 4.1, las constantes, piezas y variables guardan
       sus valores en la lista Valores.
       En partes, se almacena la posición en Valores */
    public class ParteEvl4_1 {
        /* Acumulador, función, paréntesis que abre,
		 * paréntesis que cierra, operador, 
		 * número, variable */
        public int Tipo;

        /* Código de la función 0:seno, 1:coseno, 2:tangente,
		 * 3: valor absoluto, 4: arcoseno, 5: arcocoseno,
		 * 6: arcotangente, 7: logaritmo natural, 8: exponencial
		 * 9: raíz cuadrada */
        public int Funcion;

        /* + suma - resta * multiplicación / división ^ potencia */
        public int Operador;

        /* Posición en lista de valores del número literal
		 * por ejemplo: 3.141592 */
        public int posNumero;

        /* Posición en lista de valores del 
		 * valor de la variable algebraica */
        public int posVariable;

        /* Posición en lista de valores del valor de la pieza.
		 * Por ejemplo:
		   3 + 2 / 5  se convierte así:
		   |3| |+| |2| |/| |5| 
		   |3| |+| |A|  A es un identificador de acumulador */
        public int posAcumula;

        // Diccionario estático para mapeo de operadores
        private static readonly Dictionary<char, int> OperadorMap = new()
        {
            {'+', 0}, {'-', 1}, {'*', 2}, {'/', 3}, {'^', 4}
        };

        public ParteEvl4_1(int TipoParte, int Valor) {
            Tipo = TipoParte;
            if (TipoParte == Constantes4_1.ESFUNCION) Funcion = Valor;
            else if (TipoParte == Constantes4_1.ESNUMERO) posNumero = Valor;
            else if (TipoParte == Constantes4_1.ESVARIABLE) posVariable = Valor;
            else if (TipoParte == Constantes4_1.ESPARABRE) Funcion = -1;
        }

        public ParteEvl4_1(char Operador) {
            Tipo = Constantes4_1.ESOPERADOR;
            this.Operador = OperadorMap[Operador];
        }
    }
}
